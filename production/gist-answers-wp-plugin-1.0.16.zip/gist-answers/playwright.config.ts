import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright configuration for the Gist Answers end-to-end suite.
 *
 * Point E2E_URL at a WordPress site with the plugin active, and set
 * E2E_USER / E2E_PASSWORD to an administrator's credentials. The defaults
 * match a stock `vip dev-env` site.
 *
 * The specs that need a connected site run against the mock Gist API in
 * tests/e2e/mu-plugins (and are skipped on sites without it). They share that
 * site's state, so the specs run one at a time.
 */
export const STORAGE_STATE = '.playwright/state.json';

export default defineConfig({
    testDir: './tests/e2e/specs',
    outputDir: '.playwright/results',
    forbidOnly: !!process.env.CI,
    retries: process.env.CI ? 2 : 0,
    fullyParallel: false,
    workers: 1,
    reporter: 'list',

    use: {
        baseURL: process.env.E2E_URL ?? 'http://localhost/',
        ignoreHTTPSErrors: true,
        trace: 'retain-on-failure',
        video: process.env.CI ? 'off' : 'retain-on-failure',
    },

    projects: [
        {
            name: 'setup',
            testMatch: /setup\.ts/,
        },
        {
            name: 'chromium',
            use: { ...devices['Desktop Chrome'], storageState: STORAGE_STATE },
            dependencies: ['setup'],
        },
    ],
});
