<?php
/**
 * Tests for the Gutenberg blocks, the block inserter previews, and the classic sidebar widget.
 *
 * @package GistAnswers
 */

use GistAnswers\API\Credentials;
use GistAnswers\Model\GistSite;
use GistAnswers\Plugin\CommonMain;
use GistAnswers\Plugin\SidebarWidget;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for the Gutenberg blocks, the block inserter previews, and the classic sidebar widget.
 */
final class BlocksTest extends TestCase {

	/**
	 * Link the site to a publisher with one answer widget and two question widgets.
	 *
	 * @return void
	 */
	private function link_publisher_with_widgets(): void {

		$this->connect();

		$this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				get_bloginfo( 'name' ),
				'example.org',
				array(
					'widgets' => array(
						'chat-widgets'         => array( 'chat-widget-1' => array( 'targetUrl' => 'https://example.org/answers/' ) ),
						'question-bar-widgets' => array(
							'question-bar-widget-b' => array( 'name' => 'Sidebar' ),
							'question-bar-widget-a' => array( 'name' => 'Home Page' ),
						),
					),
				)
			)
		);
	}

	/**
	 * Tests that both blocks are registered, with their names, category, and attributes.
	 *
	 * @return void
	 */
	public function testBlocksAreRegistered(): void {

		$registry = WP_Block_Type_Registry::get_instance();

		foreach ( array(
			'gist-answers/question' => 'Gist Question Widget',
			'gist-answers/answer'   => 'Gist Answer Widget',
		) as $name => $title ) {

			$block = $registry->get_registered( $name );

			$this->assertInstanceOf( WP_Block_Type::class, $block, $name );
			$this->assertSame( $title, $block->title );
			$this->assertSame( 'gist-answers', $block->category );
			$this->assertArrayHasKey( 'widgetId', $block->attributes );
			$this->assertArrayHasKey( 'preview', $block->attributes );
			$this->assertFalse( $block->attributes['preview']['default'] );
			$this->assertTrue( $block->example['attributes']['preview'] ?? false, 'the inserter preview uses the preview attribute' );
			$this->assertIsCallable( $block->render_callback );
		}
	}

	/**
	 * Tests that the question block comes before the answer block in the inserter (which follows registration order).
	 *
	 * @return void
	 */
	public function testQuestionBlockIsListedFirst(): void {

		$names = array_keys( WP_Block_Type_Registry::get_instance()->get_all_registered() );

		$this->assertLessThan( array_search( 'gist-answers/answer', $names, true ), array_search( 'gist-answers/question', $names, true ) );
	}

	/**
	 * Tests that the inserter previews are sized to their designs.
	 *
	 * @return void
	 */
	public function testPreviewViewportWidths(): void {

		$registry = WP_Block_Type_Registry::get_instance();

		$this->assertSame( 248, $registry->get_registered( 'gist-answers/question' )->example['viewportWidth'] );
		$this->assertSame( 234, $registry->get_registered( 'gist-answers/answer' )->example['viewportWidth'] );
	}

	/**
	 * Tests that the Gist Answers block category is added.
	 *
	 * @return void
	 */
	public function testBlockCategoryIsAdded(): void {

		$categories = apply_filters( 'block_categories_all', array(), null );

		$this->assertContains( 'gist-answers', array_column( $categories, 'slug' ) );
	}

	/**
	 * Tests the question block's widget dropdown: a placeholder, then the question widgets alphabetically.
	 *
	 * @return void
	 */
	public function testQuestionBlockWidgetOptions(): void {

		$this->link_publisher_with_widgets();

		$this->assertSame(
			array(
				array(
					'label' => 'Select a widget ...',
					'value' => '',
				),
				array(
					'label' => 'Home Page',
					'value' => 'question-bar-widget-a',
				),
				array(
					'label' => 'Sidebar',
					'value' => 'question-bar-widget-b',
				),
			),
			CommonMain::get_widget_options_for( 'gist-answers/question' )
		);
	}

	/**
	 * Tests the answer block's widget dropdown, which defaults to auto-detecting the widget for the page.
	 *
	 * @return void
	 */
	public function testAnswerBlockWidgetOptions(): void {

		$this->link_publisher_with_widgets();

		$options = CommonMain::get_widget_options_for( 'answer' );

		$this->assertSame( 'Auto-detect (recommended)', $options[0]['label'] );
		$this->assertSame( '', $options[0]['value'] );
		$this->assertSame( 'chat-widget-1', $options[1]['value'] );
		$this->assertSame( '/answers', $options[1]['label'] );
	}

	/**
	 * Tests the widget dropdown when there are no widgets, or for an unknown block.
	 *
	 * @return void
	 */
	public function testWidgetOptionsWithoutWidgets(): void {

		$none = array(
			array(
				'label' => 'No widgets available',
				'value' => '',
			),
		);

		$this->assertSame( $none, CommonMain::get_widget_options_for( 'gist-answers/question' ) );
		$this->assertSame( $none, CommonMain::get_widget_options_for( 'core/paragraph' ) );
	}

	/**
	 * Tests the placeholders shown for the blocks in the editor (which renders blocks over REST).
	 *
	 * @return void
	 */
	public function testEditorPlaceholders(): void {

		$question = self::call_static( CommonMain::class, 'get_placeholder_html', 'question' );
		$answer   = self::call_static( CommonMain::class, 'get_placeholder_html', 'answer' );
		$unknown  = self::call_static( CommonMain::class, 'get_placeholder_html', 'carousel' );

		$this->assertStringContainsString( 'Gist Question Widget (placeholder)', $question );
		$this->assertStringContainsString( 'gist-answers-admin-placeholder-for-question', $question );
		$this->assertStringContainsString( 'Gist Answer Widget (placeholder)', $answer );
		$this->assertStringContainsString( 'Gist Widget (placeholder)', $unknown );
		$this->assertStringContainsString( 'gist-answers-admin-placeholder-for-default', $unknown );
	}

	/**
	 * Tests the block inserter's hover previews.
	 *
	 * @return void
	 */
	public function testInserterPreviews(): void {

		$question = self::call_static( CommonMain::class, 'get_placeholder_html', 'question', true );
		$answer   = self::call_static( CommonMain::class, 'get_placeholder_html', 'answer', true );

		$this->assertStringContainsString( 'gist-answers-block-preview-for-question', $question );
		$this->assertStringContainsString( 'Ask AI anything', $question );
		$this->assertStringNotContainsString( 'gist-answers-block-preview-answer-line', $question );
		$this->assertStringContainsString( 'preview-sparkle.svg', $question );
		$this->assertStringContainsString( 'preview-arrow-right.svg', $question );

		$this->assertStringContainsString( 'Ask a follow up', $answer );
		$this->assertSame( 6, substr_count( $answer, 'gist-answers-block-preview-answer-line' ) );
		$this->assertStringNotContainsString( '(placeholder)', $answer );
	}

	/**
	 * Tests that loading the block editor refreshes the stored publisher data in the background (from WP-Cron), so new
	 * widgets appear in the blocks' dropdowns without the editor waiting on the API.
	 *
	 * @return void
	 */
	public function testPublisherDataIsRefreshedInTheBackgroundWhenTheEditorLoads(): void {

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), 'example.org' ) );

		$this->assertSame( array( '' ), array_column( CommonMain::get_widget_options_for( 'question' ), 'value' ) );

		MockGistApi::set_publishers(
			array(
				MockGistApi::publisher(
					'pub-own',
					get_bloginfo( 'name' ),
					'example.org',
					array( 'widgets' => array( 'question-bar-widgets' => array( 'question-bar-widget-new' => array( 'name' => 'New Widget' ) ) ) )
				),
			)
		);

		self::reset_plugin_state();
		MockGistApi::$requests = array();
		wp_clear_scheduled_hook( Credentials::PUBLISHER_REFRESH_CRON_HOOK );

		do_action( 'enqueue_block_editor_assets' );

		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publishers(/[^/]+)?' ), 'the editor doesn\'t wait on the API' );
		$this->assertNotFalse( wp_next_scheduled( Credentials::PUBLISHER_REFRESH_CRON_HOOK ) );

		wp_clear_scheduled_hook( Credentials::PUBLISHER_REFRESH_CRON_HOOK );
		do_action( Credentials::PUBLISHER_REFRESH_CRON_HOOK );
		GistSite::forget();

		$this->assertContains( 'question-bar-widget-new', array_column( CommonMain::get_widget_options_for( 'question' ), 'value' ) );

		do_action( 'enqueue_block_editor_assets' );

		$this->assertFalse( wp_next_scheduled( Credentials::PUBLISHER_REFRESH_CRON_HOOK ), 'not scheduled again while the data is fresh' );
	}

	/**
	 * Tests the support contact link.
	 *
	 * @return void
	 */
	public function testSupportContactLink(): void {

		$this->assertSame( 'support@gist.ai', CommonMain::get_api_contact_email() );
		$this->assertSame( '<a href="mailto:support@gist.ai">support@gist.ai</a>', CommonMain::get_api_contact_mailto_link() );
	}

	/**
	 * Tests that only the question sidebar widget is registered.
	 *
	 * @return void
	 */
	public function testOnlyTheQuestionSidebarWidgetIsRegistered(): void {

		global $wp_widget_factory;

		$ids = array_map( fn ( $widget ) => $widget->id_base, $wp_widget_factory->widgets );

		$this->assertContains( 'gist_answers_question_widget', $ids );
		$this->assertNotContains( 'gist_answers_answer_widget', $ids );
	}

	/**
	 * Tests that a sidebar widget can only be made for a known type.
	 *
	 * @return void
	 */
	public function testSidebarWidgetRequiresAKnownType(): void {

		$this->expectException( InvalidArgumentException::class );

		new SidebarWidget( 'carousel' );
	}

	/**
	 * Tests the sidebar widget's output.
	 *
	 * @return void
	 */
	public function testSidebarWidgetRendersTheWidget(): void {

		$this->link_publisher_with_widgets();

		$widget = new SidebarWidget( 'question' );

		ob_start();
		$widget->widget(
			array(
				'before_widget' => '<section class="widget">',
				'after_widget'  => '</section>',
			),
			array( 'widgetId' => 'question-bar-widget-a' )
		);
		$output = ob_get_clean();

		$this->assertSame( '<section class="widget"><div class="gist-widget-mock"></div></section>', $output );
	}

	/**
	 * Tests the sidebar widget's settings form and saving.
	 *
	 * @return void
	 */
	public function testSidebarWidgetForm(): void {

		$this->link_publisher_with_widgets();

		$widget = new SidebarWidget( 'question' );
		$widget->_set( 3 );

		ob_start();
		$widget->form( array( 'widgetId' => 'question-bar-widget-b' ) );
		$form = ob_get_clean();

		$this->assertStringContainsString( 'Home Page', $form );
		$this->assertMatchesRegularExpression( '#value="question-bar-widget-b"\s+selected#', $form );

		$this->assertSame( array( 'widgetId' => 'question-bar-widget-a' ), $widget->update( array( 'widgetId' => ' <b>question-bar-widget-a</b> ' ), array() ) );
	}
}
