<?php
/**
 * Class for testing Gist Answers API endpoints.
 *
 * @package GistAnswers
 */

use GistAnswers\API\Credentials;
use GistAnswers\API\Endpoint;
use GistAnswers\API\Get\Categories;
use GistAnswers\API\Get\PublisherGroups;
use GistAnswers\API\Get\Publishers;
use GistAnswers\API\Post\Embed;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

use PHPUnit\Framework\Attributes\Depends;

/**
 * Class for testing Gist Answers API endpoints.
 *
 * These are the only tests that call the live Gist API, so the mock API is removed for them. They still run in the
 * base test case's rolled-back transaction, so the real API token they store never leaks into later tests.
 */
final class EndpointsTest extends TestCase {

	/**
	 * Gist API token for authenticating API requests.
	 *
	 * @var string
	 */
	private string $gist_api_token = '';

	/**
	 * Publisher group ID for testing API endpoints.
	 *
	 * @var string
	 */
	private static string $publisher_group_id = '';

	/**
	 * Publisher group channel ID for testing API endpoints.
	 *
	 * @var string
	 */
	private static string $publisher_group_channel_id = '';

	/**
	 * Publisher ID for testing API endpoints.
	 *
	 * @var string
	 */
	private static string $publisher_id = '';

	/**
	 * Publisher site ID for testing API endpoints.
	 *
	 * @var string
	 */
	private static string $publisher_site_id = '';

	/**
	 * Publisher channel ID for testing API endpoints.
	 *
	 * @var string
	 */
	private static string $publisher_channel_id = '';

	/**
	 * Publisher widget ID for testing API endpoints.
	 *
	 * @var string
	 */
	private static string $publisher_widget_id = '';

	/**
	 * Set up the test environment.
	 *
	 * @return void
	 */
	protected function setUp(): void {

		parent::setUp();

		remove_filter( 'pre_http_request', array( MockGistApi::class, 'handle' ), 10 );

		$this->gist_api_token = (string) getenv( 'GIST_API_TOKEN' );

		// Each test's writes are rolled back, so the live token is stored for every test that needs it (rather than
		// left behind by an earlier test).
		if ( ! empty( $this->gist_api_token ) ) {
			Credentials::store_api_token( $this->gist_api_token );
		}
	}

	/**
	 * Skip the current test when no Gist API token is available.
	 *
	 * @return void
	 */
	private function skip_without_api_token(): void {
		if ( empty( $this->gist_api_token ) ) {
			$this->markTestSkipped( 'Set GIST_API_TOKEN to run tests against the live Gist API.' );
		}
	}

	/**
	 * Tests that the Sodium encryption process works correctly.
	 *
	 * @return void
	 */
	public function testCanEncryptSodium(): void {

		$original_text = bin2hex( random_bytes( 48 ) );

		$encrypted_data = Credentials::encrypt( $original_text, Credentials::CIPHER_SODIUM );
		$decrypted_text = Credentials::decrypt( $encrypted_data );

		$this->assertEquals( $original_text, $decrypted_text );
	}

	/**
	 * Tests that the OpenSSL GCM encryption process works correctly.
	 *
	 * @return void
	 */
	public function testCanEncryptOpenSslGcm(): void {

		$original_text = bin2hex( random_bytes( 48 ) );

		$encrypted_data = Credentials::encrypt( $original_text, Credentials::CIPHER_OPENSSL_GCM );
		$decrypted_text = Credentials::decrypt( $encrypted_data );

		$this->assertEquals( $original_text, $decrypted_text );
	}

	/**
	 * Tests that the OpenSSL CBC encryption process works correctly.
	 *
	 * @return void
	 */
	public function testCanEncryptOpenSslCbc(): void {

		$original_text = bin2hex( random_bytes( 48 ) );

		$encrypted_data = Credentials::encrypt( $original_text, Credentials::CIPHER_OPENSSL_CBC );
		$decrypted_text = Credentials::decrypt( $encrypted_data );

		$this->assertEquals( $original_text, $decrypted_text );
	}

	/**
	 * Tests that decryption fails (returns an empty string) when the ciphertext has been tampered with.
	 *
	 * @return void
	 */
	public function testDecryptRejectsTamperedCiphertext(): void {

		foreach ( array( Credentials::CIPHER_SODIUM, Credentials::CIPHER_OPENSSL_GCM, Credentials::CIPHER_OPENSSL_CBC ) as $cipher ) {

			$payload = Credentials::encrypt( bin2hex( random_bytes( 24 ) ), $cipher );

			$cipher_text = base64_decode( $payload['value'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decoding the test payload.

			$cipher_text[0] = chr( ord( $cipher_text[0] ) ^ 0x01 );

			$payload['value'] = base64_encode( $cipher_text ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Re-encoding the tampered test payload.

			$this->assertSame( '', Credentials::decrypt( $payload ), $cipher );
		}
	}

	/**
	 * Tests that OpenSSL CBC decryption fails when the HMAC doesn't match.
	 *
	 * @return void
	 */
	public function testDecryptRejectsMacMismatch(): void {

		$payload = Credentials::encrypt( bin2hex( random_bytes( 24 ) ), Credentials::CIPHER_OPENSSL_CBC );

		$payload['mac'] = base64_encode( random_bytes( 32 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Building an invalid test payload.

		$this->assertSame( '', Credentials::decrypt( $payload ) );
	}

	/**
	 * Tests that decryption fails when the payload isn't valid base64.
	 *
	 * @return void
	 */
	public function testDecryptRejectsInvalidBase64(): void {

		foreach ( array( Credentials::CIPHER_SODIUM, Credentials::CIPHER_OPENSSL_GCM, Credentials::CIPHER_OPENSSL_CBC ) as $cipher ) {

			$payload = Credentials::encrypt( bin2hex( random_bytes( 24 ) ), $cipher );

			$payload['value'] = '!!! not base64 !!!';

			$this->assertSame( '', Credentials::decrypt( $payload ), $cipher );
		}
	}

	/**
	 * Tests that decryption fails for an unknown cipher or an incomplete payload.
	 *
	 * @return void
	 */
	public function testDecryptRejectsUnknownCipherAndIncompletePayloads(): void {

		$payload = Credentials::encrypt( bin2hex( random_bytes( 24 ) ), Credentials::CIPHER_SODIUM );

		$this->assertSame( '', Credentials::decrypt( array_merge( $payload, array( 'cipher' => 'rot13' ) ) ) );
		$this->assertSame( '', Credentials::decrypt( array_diff_key( $payload, array( 'value' => true ) ) ) );
		$this->assertSame( '', Credentials::decrypt( array() ) );
	}

	/**
	 * Test that an API token can be stored and retrieved correctly.
	 *
	 * @return void
	 */
	public function testCanStoreAndRetrieveApiToken(): void {
		$this->skip_without_api_token();

		Credentials::store_api_token( $this->gist_api_token );

		$retrieved_token = Credentials::get_api_token();

		$this->assertEquals( $this->gist_api_token, $retrieved_token );
	}

	/**
	 * Test that an API token can be deleted correctly.
	 *
	 * @return void
	 */
	public function testCanDeleteStoredApiToken(): void {
		$this->skip_without_api_token();

		Credentials::store_api_token( $this->gist_api_token );
		Credentials::delete_api_token();

		$retrieved_token = Credentials::get_api_token();

		$this->assertEmpty( $retrieved_token );
	}

	/**
	 * Tests that the provided API token is valid for testing.
	 *
	 * @return void
	 */
	public function testApiKeyIsValid(): void {
		$this->skip_without_api_token();

		$is_valid = Endpoint::validate_api_token( $this->gist_api_token );

		$this->assertTrue( $is_valid );
	}

	/**
	 * Tests that an embed ticket can be retrieved.
	 *
	 * @return void
	 */
	public function testCanRetrieveEmbedTicket(): void {
		$this->skip_without_api_token();

		$request = new Embed(
			array(
				'api_token' => $this->gist_api_token,
			)
		);

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'ticket', $response->data );
		$this->assertNotEmpty( $response->data->ticket );
	}

	/**
	 * Test that the publisher group for the API token can be retrieved correctly.
	 *
	 * @return void
	 */
	public function testCanGetPublisherGroups(): void {
		$this->skip_without_api_token();

		Credentials::store_api_token( $this->gist_api_token );

		$request = new PublisherGroups();

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'id', $response->data );
		$this->assertNotEmpty( $response->data->id );

		self::$publisher_group_id = $response->data->id;
	}

	/**
	 * Test that a single publisher group can be retrieved by its ID.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublisherGroups' )]
	public function testCanGetPublisherGroup(): void {
		$this->skip_without_api_token();

		$request = new PublisherGroups( self::$publisher_group_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'id', $response->data );
		$this->assertNotEmpty( $response->data->id );
	}

	/**
	 * Tests that the channels for a publisher group can be retrieved correctly.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublisherGroups' )]
	public function testCanGetPublisherGroupChannels(): void {
		$this->skip_without_api_token();

		$request = new PublisherGroups\Channels( self::$publisher_group_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertIsArray( $response->data );
		$this->assertArrayHasKey( 0, $response->data );
		$this->assertNotEmpty( $response->data[0] );
		$this->assertInstanceOf( 'stdClass', $response->data[0] );
		$this->assertObjectHasProperty( 'id', $response->data[0] );
		$this->assertNotEmpty( $response->data[0]->id );

		self::$publisher_group_channel_id = $response->data[0]->id;
	}

	/**
	 * Tests that the publishers for the API token can be retrieved correctly.
	 *
	 * @return void
	 */
	public function testCanGetPublishers(): void {
		$this->skip_without_api_token();

		$request = new Publishers();

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'publishers', $response->data );
		$this->assertIsArray( $response->data->publishers );
		$this->assertArrayHasKey( 0, $response->data->publishers );
		$this->assertNotEmpty( $response->data->publishers[0] );
		$this->assertInstanceOf( 'stdClass', $response->data->publishers[0] );
		$this->assertObjectHasProperty( 'id', $response->data->publishers[0] );
		$this->assertNotEmpty( $response->data->publishers[0]->id );

		[ self::$publisher_id, self::$publisher_widget_id ] = $this->getFirstPublisherWithWidgets( $response->data->publishers );
	}

	/**
	 * Retrieves the first publisher which has widgets associated with it.
	 *
	 * @param array<object> $publishers Array of publisher objects.
	 *
	 * @return array<string> The ID of the first publisher with widgets and the ID of its first widget (or, if none has
	 *                       any, the ID of the first publisher and an empty widget ID).
	 */
	private function getFirstPublisherWithWidgets( array $publishers ): array {

		foreach ( $publishers as $publisher ) {

			$widgets = is_object( $publisher->config ?? null ) ? ( $publisher->config->widgets ?? null ) : null;

			if ( ! is_object( $widgets ) ) {
				continue;
			}

			foreach ( array( 'chat-widgets', 'question-bar-widgets', 'search-widgets' ) as $group ) {

				$group_widgets = is_object( $widgets->{$group} ?? null ) ? get_object_vars( $widgets->{$group} ) : array();

				if ( ! empty( $group_widgets ) ) {
					return array( strval( $publisher->id ), strval( array_key_first( $group_widgets ) ) );
				}
			}
		}

		return array( strval( $publishers[0]->id ), '' );
	}

	/**
	 * Skip the test if no publisher in the account has a widget.
	 *
	 * @return void
	 */
	private function skip_without_publisher_widget(): void {
		if ( '' === self::$publisher_widget_id ) {
			$this->markTestSkipped( 'No publisher in the live Gist API account has a widget.' );
		}
	}

	/**
	 * Tests that a single publisher can be retrieved by its ID.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublishers' )]
	public function testCanGetPublisher(): void {
		$this->skip_without_api_token();

		$request = new Publishers( self::$publisher_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'id', $response->data );
		$this->assertNotEmpty( $response->data->id );
	}

	/**
	 * Tests that the sites associated with a publisher can be retrieved.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublishers' )]
	public function testCanGetPublisherSites(): void {
		$this->skip_without_api_token();

		$request = new Publishers\Sites( self::$publisher_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertIsArray( $response->data );
		$this->assertArrayHasKey( 0, $response->data );
		$this->assertNotEmpty( $response->data[0] );
		$this->assertInstanceOf( 'stdClass', $response->data[0] );
		$this->assertObjectHasProperty( 'id', $response->data[0] );
		$this->assertNotEmpty( $response->data[0]->id );

		self::$publisher_site_id = $response->data[0]->id;
	}

	/**
	 * Tests that a single site associated with a publisher can be retrieved by its ID.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublisherSites' )]
	public function testCanGetPublisherSite(): void {
		$this->skip_without_api_token();

		$request = new Publishers\Sites( self::$publisher_id, self::$publisher_site_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'id', $response->data );
		$this->assertNotEmpty( $response->data->id );
	}

	/**
	 * Tests that the widgets associated with a publisher can be retrieved.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublishers' )]
	public function testCanGetPublisherWidgets(): void {
		$this->skip_without_api_token();

		$request = new Publishers\Widgets( self::$publisher_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'chat-widgets', $response->data );
		$this->assertNotEmpty( $response->data->{'chat-widgets'} );
		$this->assertInstanceOf( 'stdClass', $response->data->{'chat-widgets'} );
		$this->assertObjectHasProperty( 'search-widgets', $response->data );
		$this->assertNotEmpty( $response->data->{'search-widgets'} );
		$this->assertInstanceOf( 'stdClass', $response->data->{'search-widgets'} );
	}

	/**
	 * Tests that the search widgets associated with a publisher can be retrieved.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublishers' )]
	public function testCanGetPublisherSearchWidgets(): void {
		$this->skip_without_api_token();

		$request = new Publishers\Widgets\Search( self::$publisher_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertNotEmpty( get_object_vars( $response->data ) );
		$this->assertNotEmpty( array_key_first( get_object_vars( $response->data ) ) );
		$this->assertInstanceOf( 'stdClass', $response->data->{ array_key_first( get_object_vars( $response->data ) ) } );
	}

	/**
	 * Tests that the chat widgets associated with a publisher can be retrieved.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublishers' )]
	public function testCanGetPublisherChatWidgets(): void {
		$this->skip_without_api_token();

		$request = new Publishers\Widgets\Chat( self::$publisher_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertNotEmpty( get_object_vars( $response->data ) );
		$this->assertNotEmpty( array_key_first( get_object_vars( $response->data ) ) );
		$this->assertInstanceOf( 'stdClass', $response->data->{ array_key_first( get_object_vars( $response->data ) ) } );
	}

	/**
	 * Tests that the default widget settings associated with a publisher can be retrieved.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublishers' )]
	public function testCanGetPublisherWidgetDefaultConfigs(): void {
		$this->skip_without_api_token();

		$request = new Publishers\Widgets\Defaults( self::$publisher_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'defaultSettings', $response->data );
		$this->assertNotEmpty( $response->data->defaultSettings );
		$this->assertInstanceOf( 'stdClass', $response->data->defaultSettings );
	}

	/**
	 * Tests that a specific widget associated with a publisher can be retrieved by its ID.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublishers' )]
	public function testCanGetPublisherWidget(): void {
		$this->skip_without_api_token();
		$this->skip_without_publisher_widget();

		$request = new Publishers\Widgets( self::$publisher_id, self::$publisher_widget_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'widget_id', $response->data );
		$this->assertNotEmpty( $response->data->widget_id );
		$this->assertObjectHasProperty( 'widget', $response->data );
		$this->assertNotEmpty( $response->data->widget );
		$this->assertInstanceOf( 'stdClass', $response->data->widget );
	}

	/**
	 * Tests that the HTML for a specific widget associated with a publisher can be retrieved.
	 *
	 * @return void
	 */
	#[Depends( 'testCanGetPublishers' )]
	public function testCanGetPublisherWidgetHtml(): void {
		$this->skip_without_api_token();
		$this->skip_without_publisher_widget();

		$request = new Publishers\Widgets\HTML( self::$publisher_id, self::$publisher_widget_id );

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertInstanceOf( 'stdClass', $response->data );
		$this->assertObjectHasProperty( 'widget_id', $response->data );
		$this->assertNotEmpty( $response->data->widget_id );
	}

	/**
	 * Tests that the list of categories can be retrieved.
	 *
	 * @return void
	 */
	public function testCanGetCategories(): void {
		$this->skip_without_api_token();

		$request = new Categories();

		$response = $request->response();

		$this->assertNotEmpty( $response );
		$this->assertInstanceOf( 'stdClass', $response );
		$this->assertObjectHasProperty( 'data', $response );
		$this->assertNotEmpty( $response->data );
		$this->assertIsArray( $response->data );
	}
}
