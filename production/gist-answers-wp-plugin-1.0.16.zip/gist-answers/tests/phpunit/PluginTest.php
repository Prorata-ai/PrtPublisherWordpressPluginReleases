<?php
/**
 * Class for testing the Gist Answers plugin functionality.
 *
 * @package GistAnswers
 */

use GistAnswers\Admin\AdminMain;
use GistAnswers\Plugin\Activate;
use GistAnswers\Plugin\CommonMain;
use GistAnswers\Plugin\Deactivate;
use GistAnswers\Plugin\Uninstall;

use PHPUnit\Framework\TestCase;

/**
 * Class for testing the Gist Answers plugin functionality.
 */
final class PluginTest extends TestCase {

	private const NOT_FOUND_TOKEN = '__GIST_ANSWERS_OPTION_NOT_FOUND__';

	/**
	 * Tests that the plugin can activate successfully.
	 *
	 * @return void
	 */
	public function testPluginCanActivate(): void {

		Activate::activate();

		if ( is_multisite() ) {
			$option_value = get_site_option( CommonMain::ACTIVATION_FLAG, self::NOT_FOUND_TOKEN );
		} else {
			$option_value = get_option( CommonMain::ACTIVATION_FLAG, self::NOT_FOUND_TOKEN );
		}

		$this->assertTrue( $option_value );
	}

	/**
	 * Tests that the plugin can deactivate successfully.
	 *
	 * @return void
	 */
	public function testPluginCanDeactivate(): void {

		wp_schedule_single_event( time() + 60, AdminMain::INGEST_CRON_HOOK );

		Deactivate::deactivate();

		$this->assertFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 'the ingestion event is unscheduled' );

		if ( is_multisite() ) {
			$option_value = get_site_option( CommonMain::ACTIVATION_FLAG, self::NOT_FOUND_TOKEN );
		} else {
			$option_value = get_option( CommonMain::ACTIVATION_FLAG, self::NOT_FOUND_TOKEN );
		}

		// WordPress stores `false` as '' and multisite network-option reads return
		// the stored value, so only assert that the flag exists and is falsy.
		$this->assertNotSame( self::NOT_FOUND_TOKEN, $option_value );
		$this->assertEmpty( $option_value );
	}

	/**
	 * Tests that the plugin can uninstall successfully.
	 *
	 * @return void
	 */
	public function testPluginCanUninstall(): void {

		Uninstall::uninstall();

		if ( is_multisite() ) {
			$option_value = get_site_option( CommonMain::ACTIVATION_FLAG, self::NOT_FOUND_TOKEN );
		} else {
			$option_value = get_option( CommonMain::ACTIVATION_FLAG, self::NOT_FOUND_TOKEN );
		}

		$this->assertEquals( self::NOT_FOUND_TOKEN, $option_value );
	}

	/**
	 * Confirms there is no direct access to any `build-assets` files.
	 *
	 * @return void
	 */
	public function testNotDirectlyAccessingBuildAssets(): void {

		$exclude_filenames = array(
			'PluginTest.php',
		);

		// Third-party and generated test output; none of it is plugin code.
		$exclude_directories = array(
			'node_modules',
			'.playwright',
		);

		$files = new RecursiveIteratorIterator(
			new RecursiveCallbackFilterIterator(
				new RecursiveDirectoryIterator( GIST_ANSWERS_PLUGIN_DIR, RecursiveDirectoryIterator::SKIP_DOTS ),
				fn( $file ) => ! ( $file->isDir() && in_array( $file->getFilename(), $exclude_directories, true ) )
			)
		);

		foreach ( $files as $file ) {
			if ( $file->isFile() ) {

				if ( in_array( $file->getFilename(), $exclude_filenames, true ) ) {
					continue;
				}

				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- This is development code only and will not be used in the public plugin.
				$content = file_get_contents( $file->getPathname() );
				$content = is_string( $content ) ? strtolower( $content ) : '';

				$this->assertStringNotContainsString( 'build-assets', $content );
			}
		}
	}

	/**
	 * Tests that the required form templates exist for the plugin.
	 *
	 * @return void
	 */
	public function testRequiredFormTemplatesExist(): void {

		$required_templates = CommonMain::get_required_form_templates();

		foreach ( $required_templates as $template ) {
			$this->assertFileExists( GIST_ANSWERS_PLUGIN_DIR . 'templates/forms/' . $template . '.php' );
		}
	}

	/**
	 * Tests that there are no extraneous form templates in the plugin.
	 *
	 * @return void
	 */
	public function testNoExtraneousFormTemplatesExist(): void {

		$required_templates = CommonMain::get_required_form_templates();

		$all_templates = glob( GIST_ANSWERS_PLUGIN_DIR . 'templates/forms/*.php' );

		foreach ( $all_templates as $template_path ) {
			$template = basename( $template_path, '.php' );
			$this->assertContains( $template, $required_templates );
		}
	}

	/**
	 * Tests that the required partial templates exist for the plugin.
	 *
	 * @return void
	 */
	public function testRequiredPartialTemplatesExist(): void {

		$required_templates = CommonMain::get_required_partial_templates();

		foreach ( $required_templates as $template ) {
			$this->assertFileExists( GIST_ANSWERS_PLUGIN_DIR . 'templates/partials/' . $template . '.php' );
		}
	}

	/**
	 * Tests that there are no extraneous partial templates in the plugin.
	 *
	 * @return void
	 */
	public function testNoExtraneousPartialTemplatesExist(): void {

		$required_templates = CommonMain::get_required_partial_templates();

		$all_templates = glob( GIST_ANSWERS_PLUGIN_DIR . 'templates/partials/*.php' );

		foreach ( $all_templates as $template_path ) {
			$template = basename( $template_path, '.php' );
			$this->assertContains( $template, $required_templates );
		}
	}

	/**
	 * Tests that the plugin `vendor` folder exists.
	 *
	 * @return void
	 */
	public function testVendorFolderExists(): void {
		$this->assertDirectoryExists( GIST_ANSWERS_PLUGIN_DIR . 'vendor' );
	}
}
