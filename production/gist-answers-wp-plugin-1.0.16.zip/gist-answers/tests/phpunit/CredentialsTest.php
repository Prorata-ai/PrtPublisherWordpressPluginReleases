<?php
/**
 * Tests for the API token, publisher, and activation-matching logic in Credentials.
 *
 * @package GistAnswers
 */

use GistAnswers\API\Credentials;
use GistAnswers\API\Get\Categories;
use GistAnswers\Model\GistSite;
use GistAnswers\Plugin\Utilities;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for the API token, publisher, and activation-matching logic in Credentials.
 */
final class CredentialsTest extends TestCase {

	/**
	 * The test site's publisher, as the API returns it (its domain and name match the test site's).
	 *
	 * @return array<mixed> The publisher.
	 */
	private function own_publisher(): array {
		return MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), wp_parse_url( home_url(), PHP_URL_HOST ) );
	}

	/**
	 * Tests that a stored token can be read back, and reports the database as its source.
	 *
	 * @return void
	 */
	public function testStoredTokenIsReadFromTheDatabase(): void {

		$this->assertTrue( Credentials::store_api_token( '  ' . self::TOKEN . '  ' ) );

		$this->assertSame( self::TOKEN, Credentials::get_api_token() );
		$this->assertSame( 'database', Credentials::get_api_token_source() );
		$this->assertTrue( Credentials::has_stored_api_token() );
	}

	/**
	 * Tests that the token is stored encrypted (never in plain text) in the right table.
	 *
	 * @return void
	 */
	public function testTokenIsStoredEncrypted(): void {

		Credentials::store_api_token( self::TOKEN );

		$stored = is_multisite() ? get_site_option( 'gist_answers_api_token' ) : get_option( 'gist_answers_api_token' );

		$this->assertIsArray( $stored );
		$this->assertArrayHasKey( 'cipher', $stored );
		$this->assertStringNotContainsString( self::TOKEN, wp_json_encode( $stored ) );
	}

	/**
	 * Tests that an empty token isn't stored.
	 *
	 * @return void
	 */
	public function testEmptyTokenIsNotStored(): void {

		$this->assertFalse( Credentials::store_api_token( '   ' ) );
		$this->assertSame( '', Credentials::get_api_token() );
	}

	/**
	 * Tests that deleting the token removes it and the cached token check.
	 *
	 * @return void
	 */
	public function testDeletingTheTokenRemovesItAndItsCachedCheck(): void {

		$this->connect();

		Credentials::delete_api_token();

		$this->assertSame( '', Credentials::get_api_token() );
		$this->assertFalse( is_multisite() ? get_site_transient( 'gist_answers_api_token_is_valid' ) : get_transient( 'gist_answers_api_token_is_valid' ) );
	}

	/**
	 * Tests that a token in the environment takes precedence over the stored one.
	 *
	 * @return void
	 */
	public function testEnvironmentTokenTakesPrecedence(): void {

		Credentials::store_api_token( self::TOKEN );

		putenv( 'GIST_ANSWERS_API_KEY=sk_from_the_environment' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.runtime_configuration_putenv -- Sets up the environment token source under test; removed in the finally block.

		try {
			$this->assertSame( 'sk_from_the_environment', Credentials::get_api_token() );
			$this->assertSame( 'environment', Credentials::get_api_token_source() );
			$this->assertTrue( Credentials::has_stored_api_token() );
		} finally {
			putenv( 'GIST_ANSWERS_API_KEY' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.runtime_configuration_putenv -- Removes the environment token set up above.
		}
	}

	/**
	 * Tests that a cached successful token check is used without calling the API.
	 *
	 * @return void
	 */
	public function testCachedTokenCheckSkipsTheApi(): void {

		$this->connect();

		$this->assertTrue( Credentials::has_valid_api_token() );
		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publisher_groups' ) );
	}

	/**
	 * Tests that the token is checked against the API once, and the result cached for minutes (not seconds).
	 *
	 * @return void
	 */
	public function testTokenCheckIsCachedAfterValidating(): void {

		Credentials::store_api_token( self::TOKEN );

		$this->assertTrue( Credentials::has_valid_api_token() );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups' ) );

		$timeout_option = is_multisite() ? get_site_option( '_site_transient_timeout_gist_answers_api_token_is_valid' ) : get_option( '_transient_timeout_gist_answers_api_token_is_valid' );

		$this->assertGreaterThanOrEqual( time() + 4 * MINUTE_IN_SECONDS, intval( $timeout_option ) );

		self::reset_plugin_state();

		$this->assertTrue( Credentials::has_valid_api_token() );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups' ) );
	}

	/**
	 * Tests that the token is sent to the API in the X-API-Token header when it's checked.
	 *
	 * @return void
	 */
	public function testTokenIsSentWhenChecked(): void {

		Credentials::store_api_token( self::TOKEN );

		Credentials::has_valid_api_token();

		$this->assertSame( self::TOKEN, MockGistApi::requests( 'GET', 'publisher_groups' )[0]->headers['X-API-Token'] ?? null );
	}

	/**
	 * Tests that without a token, the token check fails without contacting the API.
	 *
	 * @return void
	 */
	public function testTokenCheckWithoutATokenDoesNotCallTheApi(): void {

		$this->assertSame( '', Credentials::get_api_token() );
		$this->assertFalse( Credentials::has_valid_api_token() );
		$this->assertCount( 0, MockGistApi::requests() );
	}

	/**
	 * Tests that a failed token check is remembered briefly, so that the API isn't called on every request.
	 *
	 * @return void
	 */
	public function testFailedTokenCheckBacksOff(): void {

		Credentials::store_api_token( self::TOKEN );

		MockGistApi::unreachable( 'GET', 'publisher_groups' );

		$this->assertFalse( Credentials::has_valid_api_token() );

		self::reset_plugin_state();

		$this->assertFalse( Credentials::has_valid_api_token() );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups' ) );
	}

	/**
	 * Tests that storing a new token ends the back-off, so a corrected token is checked straight away.
	 *
	 * @return void
	 */
	public function testStoringATokenEndsTheBackOff(): void {

		Credentials::store_api_token( 'sk_wrong' );

		MockGistApi::on( 'GET', 'publisher_groups', 401, array( 'error' => 'Unauthorized' ) );

		$this->assertFalse( Credentials::has_valid_api_token() );

		MockGistApi::reset();
		self::reset_plugin_state();

		Credentials::store_api_token( self::TOKEN );

		$this->assertTrue( Credentials::has_valid_api_token() );
	}

	/**
	 * Expire the cached successful token check, as if PRIMARY_TRANSIENT_DURATION had passed.
	 *
	 * @return void
	 */
	private function expire_token_check(): void {

		if ( is_multisite() ) {
			delete_site_transient( 'gist_answers_api_token_is_valid' );
		} else {
			delete_transient( 'gist_answers_api_token_is_valid' );
		}

		self::reset_plugin_state();
	}

	/**
	 * Tests that on the front end, a token check that fails only because the API can't be reached falls back on the
	 * last successful check (and isn't repeated straight away), rather than leaving the site disconnected.
	 *
	 * @return void
	 */
	public function testFrontEndTokenCheckUsesTheLastResultWhileTheApiIsUnreachable(): void {

		Credentials::store_api_token( self::TOKEN );

		$this->assertTrue( Credentials::has_valid_api_token() );

		$this->expire_token_check();
		MockGistApi::unreachable( 'GET', 'publisher_groups' );

		$this->assertTrue( Credentials::has_valid_api_token() );
		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publisher_groups' ) );

		self::reset_plugin_state();

		$this->assertTrue( Credentials::has_valid_api_token() );
		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publisher_groups' ), 'backs off' );
	}

	/**
	 * Tests that the API rejecting the token makes it invalid straight away, whatever the last check found.
	 *
	 * @return void
	 */
	public function testRejectedTokenIsInvalidStraightAway(): void {

		Credentials::store_api_token( self::TOKEN );

		$this->assertTrue( Credentials::has_valid_api_token() );

		$this->expire_token_check();
		MockGistApi::on( 'GET', 'publisher_groups', 401, array( 'error' => 'Unauthorized' ) );

		$this->assertFalse( Credentials::has_valid_api_token() );

		self::reset_plugin_state();

		$this->assertFalse( Credentials::has_valid_api_token() );
	}

	/**
	 * Tests that while one front-end request is checking the token, the others use the last result rather than
	 * calling the API too.
	 *
	 * @return void
	 */
	public function testOnlyOneFrontEndRequestChecksTheToken(): void {

		Credentials::store_api_token( self::TOKEN );

		$this->assertTrue( Credentials::has_valid_api_token() );

		$this->expire_token_check();

		$this->assertTrue( Utilities::acquire_lock( 'gist_answers_api_token_check_lock', 30, true ), 'another request is checking it' );

		$this->assertTrue( Credentials::has_valid_api_token() );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups' ) );
	}

	/**
	 * Tests that a successful publishers response that isn't a list of publishers doesn't unlink the site.
	 *
	 * @return void
	 */
	public function testMalformedPublishersListKeepsTheStoredPublisher(): void {

		$this->connect();
		$this->link_publisher( $this->own_publisher() );

		$malformed = array(
			'invalid JSON' => '{"publishers": [',
			'wrong type'   => array( 'publishers' => 'none' ),
			'no envelope'  => array( $this->own_publisher() ),
		);

		foreach ( $malformed as $case => $body ) {

			self::reset_plugin_state();
			Credentials::clear_publishers_list_cache();
			MockGistApi::on( 'GET', 'publishers(/[^/]+)?', 200, $body );

			$this->assertSame( 'pub-own', Credentials::update_publisher()->id ?? null, $case );
		}
	}

	/**
	 * Tests that publisher data with fields of the wrong type is stored safely, without breaking the page (the
	 * reported `targetUrl` array case).
	 *
	 * @return void
	 */
	public function testMalformedPublisherConfigIsTolerated(): void {

		$this->connect();

		$publisher = $this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				get_bloginfo( 'name' ),
				wp_parse_url( home_url(), PHP_URL_HOST ),
				array(
					'dev'     => array( 'dev.example' => true ),
					'widgets' => array(
						'chat-widgets'         => array(
							'chat-widget-1' => array(
								'targetUrl' => array( 'https://example.org/answers/' ),
								'created'   => array( 'yesterday' ),
							),
						),
						'question-bar-widgets' => array(
							'question-bar-widget-1' => array(
								'name'       => array( 'Home' ),
								'answerPage' => array( 'chatWidgetId' => array( 'chat-widget-1' ) ),
							),
						),
					),
				)
			)
		);

		$this->assertSame( 'pub-own', $publisher->id );
		$this->assertSame( '', $publisher->widgets->chat_widgets[0]->target );
		$this->assertSame( '', $publisher->widgets->search_widgets[0]->name );
		$this->assertSame( '', $publisher->widgets->search_widgets[0]->target );
	}

	/**
	 * Tests that only an API rejection of the token (401 or 403) invalidates the cached token check.
	 *
	 * @return void
	 */
	public function testOnlyAuthFailuresInvalidateTheCachedTokenCheck(): void {

		$this->connect();

		MockGistApi::on( 'GET', 'categories', 500, array( 'error' => 'Internal error' ) );
		new Categories();

		$this->assertNotFalse( is_multisite() ? get_site_transient( 'gist_answers_api_token_is_valid' ) : get_transient( 'gist_answers_api_token_is_valid' ) );

		MockGistApi::on( 'GET', 'categories', 401, array( 'error' => 'Unauthorized' ) );
		new Categories();

		$this->assertFalse( is_multisite() ? get_site_transient( 'gist_answers_api_token_is_valid' ) : get_transient( 'gist_answers_api_token_is_valid' ) );
	}

	/**
	 * Tests that a site is linked to its publisher when the domains match and the names match closely enough.
	 *
	 * @return void
	 */
	public function testPublisherIsMatchedByDomainAndName(): void {

		$this->connect();

		MockGistApi::set_publishers(
			array(
				MockGistApi::publisher( 'pub-other', 'Another Site', 'another.example' ),
				$this->own_publisher(),
			)
		);

		$this->assertSame( 'pub-own', Credentials::update_publisher()->id ?? null );
		$this->assertTrue( Credentials::has_stored_publisher() );
	}

	/**
	 * Tests that a publisher on the same domain isn't linked automatically if its name is too different.
	 *
	 * @return void
	 */
	public function testPublisherWithADifferentNameIsNotMatched(): void {

		$this->connect();

		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-own', 'A Completely Different Name', wp_parse_url( home_url(), PHP_URL_HOST ) ) ) );

		$this->assertEmpty( (array) Credentials::update_publisher() );
	}

	/**
	 * Tests that disabled publishers are never linked.
	 *
	 * @return void
	 */
	public function testDisabledPublisherIsNotMatched(): void {

		$this->connect();

		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), wp_parse_url( home_url(), PHP_URL_HOST ), array(), false ) ) );

		$this->assertEmpty( (array) Credentials::update_publisher() );
	}

	/**
	 * Tests that a preferred publisher is linked even if its domain and name don't match.
	 *
	 * @return void
	 */
	public function testPreferredPublisherIsLinked(): void {

		$this->connect();

		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-chosen', 'Chosen Site', 'chosen.example' ) ) );

		$this->assertSame( 'pub-chosen', Credentials::update_publisher( 0, 'pub-chosen' )->id ?? null );
	}

	/**
	 * Tests that the stored publisher is kept (not unlinked) if the publishers list can't be fetched.
	 *
	 * @return void
	 */
	public function testStoredPublisherIsKeptWhenTheApiFails(): void {

		$this->connect();
		$this->link_publisher( $this->own_publisher() );

		self::reset_plugin_state();
		MockGistApi::unreachable( 'GET', 'publishers(/[^/]+)?' );

		$this->assertSame( 'pub-own', Credentials::update_publisher()->id ?? null );
		$this->assertSame( 'pub-own', Credentials::get_publisher()->id ?? null );
	}

	/**
	 * Tests that refreshing a linked site fetches only its own publisher, not every publisher in the account.
	 *
	 * @return void
	 */
	public function testLinkedPublisherIsFetchedByItself(): void {

		$this->connect();
		$this->link_publisher( $this->own_publisher() );

		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-own', 'Renamed', wp_parse_url( home_url(), PHP_URL_HOST ) ), MockGistApi::publisher( 'pub-other', 'Other', 'other.example' ) ) );

		self::reset_plugin_state();
		MockGistApi::$requests = array();

		$this->assertSame( 'Renamed', Credentials::update_publisher()->name ?? null );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-own' ) );
		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publishers' ), 'the unbounded list isn\'t requested' );
	}

	/**
	 * Tests that a linked publisher that has been deleted or disabled is unlinked, as long as the API could say so,
	 * and that the account is then searched for another match.
	 *
	 * @return void
	 */
	public function testDeletedOrDisabledPublisherIsUnlinked(): void {

		$this->connect();

		foreach ( array( 'deleted', 'disabled' ) as $case ) {

			$this->link_publisher( $this->own_publisher() );

			MockGistApi::set_publishers( 'deleted' === $case ? array() : array( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), wp_parse_url( home_url(), PHP_URL_HOST ), array(), false ) ) );

			self::reset_plugin_state();
			MockGistApi::$requests = array();

			$this->assertEmpty( (array) Credentials::update_publisher(), $case );
			$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers' ), "$case: the account is searched for another match" );

			MockGistApi::set_publishers( array( $this->own_publisher(), MockGistApi::publisher( 'pub-new', get_bloginfo( 'name' ), wp_parse_url( home_url(), PHP_URL_HOST ) ) ) );
		}

		self::reset_plugin_state();
		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-new', get_bloginfo( 'name' ), wp_parse_url( home_url(), PHP_URL_HOST ) ) ) );

		$this->assertSame( 'pub-new', Credentials::update_publisher()->id ?? null, 'another matching publisher is linked instead' );
	}

	/**
	 * Tests that once a publisher can't be fetched, publisher data isn't refreshed again for a minute (on any site in
	 * the network), so an outage costs one failed lookup rather than one per refresh or per site; and that storing a
	 * new token ends that.
	 *
	 * @return void
	 */
	public function testFailedPublisherFetchesAreNotRepeated(): void {

		$this->connect();
		$this->link_publisher( $this->own_publisher() );

		$blog_ids = array( 0 );

		if ( is_multisite() ) {
			$blog_ids[] = self::factory()->blog->create( array( 'path' => '/site-a/' ) );
			$this->link_publisher( MockGistApi::publisher( 'pub-a', 'Site A', 'site-a.example' ), $blog_ids[1] );
		}

		MockGistApi::on( 'GET', 'publishers(/[^/]+)?', 503, array( 'error' => 'Unavailable' ) );
		MockGistApi::$requests = array();

		for ( $i = 0; $i < 5; $i++ ) {
			foreach ( $blog_ids as $blog_id ) {
				self::reset_plugin_state();
				Credentials::refresh_publisher_data( $blog_id );
			}
		}

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers(/[^/]+)?' ) );
		$this->assertSame( 'pub-own', Credentials::get_publisher()->id ?? null, 'the stored publisher is kept' );

		Credentials::store_api_token( 'new-token' );
		self::reset_plugin_state();
		Credentials::refresh_publisher_data();

		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publishers(/[^/]+)?' ), 'a new token tries again' );
	}

	/**
	 * Tests that an unlinked site's failed search of the publishers list isn't repeated in the same request, even once
	 * the backoff has been cleared.
	 *
	 * @return void
	 */
	public function testFailedPublishersListIsNotRefetchedInTheSameRequest(): void {

		$this->connect();

		MockGistApi::on( 'GET', 'publishers', 503, array( 'error' => 'Unavailable' ) );

		for ( $i = 0; $i < 5; $i++ ) {
			delete_transient( 'gist_answers_publisher_fetch_failed' );
			delete_site_transient( 'gist_answers_publisher_fetch_failed' );
			Credentials::update_publisher();
		}

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers' ) );
	}

	/**
	 * Tests that an unlinked site only searches the API for a matching publisher every few minutes.
	 *
	 * @return void
	 */
	public function testUnlinkedSiteLooksUpPublishersOnlyOccasionally(): void {

		$this->connect();

		Credentials::get_publisher();

		self::reset_plugin_state();

		Credentials::get_publisher();

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers' ) );
	}

	/**
	 * Tests the publisher data stored for a linked site.
	 *
	 * @return void
	 */
	public function testStoredPublisherData(): void {

		$this->connect();

		$data = $this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				get_bloginfo( 'name' ),
				'example.org',
				array( 'dev' => 'https://staging.example.org, dev.example.org' )
			)
		);

		$this->assertSame( 'pub-own', $data->id );
		$this->assertSame( 'example.org', $data->domain );
		$this->assertSame( array( 'staging.example.org', 'dev.example.org' ), $data->dev_domains );
		$this->assertSame( 'cat-news', $data->category_id );
	}

	/**
	 * Tests that answer (chat) widgets and question widgets (under `question-bar-widgets` and the older
	 * `search-widgets`) are all read from the publisher's config.
	 *
	 * @return void
	 */
	public function testWidgetsAreReadFromThePublisherConfig(): void {

		$this->connect();

		$this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				get_bloginfo( 'name' ),
				'example.org',
				array(
					'widgets' => array(
						'chat-widgets'         => array(
							'chat-widget-1' => array(
								'targetUrl' => 'https://example.org/gistanswers/',
								'created'   => '2026-10-01T00:00:00Z',
							),
						),
						'question-bar-widgets' => array(
							'question-bar-widget-1' => array(
								'name'       => 'Home Page',
								'answerPage' => array( 'chatWidgetId' => 'chat-widget-1' ),
							),
						),
						'search-widgets'       => array(
							'search-widget-1' => array( 'name' => 'Legacy Widget' ),
						),
						'lastPublished'        => array( 'timestamp' => '2026-10-01T00:00:00Z' ),
					),
				)
			)
		);

		$gist_site = GistSite::get();

		$chat_widgets   = $gist_site->get_chat_widgets();
		$search_widgets = $gist_site->get_search_widgets();

		$this->assertCount( 1, $chat_widgets );
		$this->assertSame( 'chat-widget-1', $chat_widgets[0]->get_id() );
		$this->assertSame( '/gistanswers', $chat_widgets[0]->get_name() );

		$this->assertSame( array( 'Home Page', 'Legacy Widget' ), array_map( fn ( $widget ) => $widget->get_name(), $search_widgets ) );
		$this->assertTrue( $gist_site->search_widget_id_is_valid( 'question-bar-widget-1' ) );
		$this->assertTrue( $gist_site->chat_widget_id_is_valid( 'chat-widget-1' ) );
		$this->assertFalse( $gist_site->search_widget_id_is_valid( 'chat-widget-1' ) );
	}

	/**
	 * Tests that malformed widget groups are ignored rather than causing errors.
	 *
	 * @return void
	 */
	public function testMalformedWidgetGroupsAreIgnored(): void {

		$this->connect();

		$this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				get_bloginfo( 'name' ),
				'example.org',
				array(
					'widgets' => array(
						'chat-widgets'         => array(),
						'question-bar-widgets' => 'not-an-object',
					),
				)
			)
		);

		$this->assertSame( array(), GistSite::get()->get_chat_widgets() );
		$this->assertSame( array(), GistSite::get()->get_search_widgets() );
	}

	/**
	 * Activation matching scenarios: the site's URL, the publishers, and the expected match.
	 *
	 * @return array<array<mixed>> The scenarios.
	 */
	public static function activationScenarios(): array {
		return array(
			'exact domain'                         => array( 'https://www.example.org/', array( array( 'pub-1', 'Test Blog', 'example.org', array() ) ), 'pub-1', false, '' ),
			'home page URL'                        => array( 'https://example.org', array( array( 'pub-1', 'Test Blog', 'other.example', array( 'home_page_url' => 'https://example.org/' ) ) ), 'pub-1', false, '' ),
			'alias'                                => array( 'https://example.org', array( array( 'pub-1', 'Test Blog', 'other.example', array( 'aliases' => array( 'https://www.example.org' ) ) ) ), 'pub-1', false, '' ),
			'dev domain'                           => array( 'https://qa.example.org', array( array( 'pub-1', 'Test Blog', 'other.example', array( 'dev' => 'qa.example.org' ) ) ), 'pub-1', false, '' ),
			'pre-production to production'         => array( 'https://staging.example.org', array( array( 'pub-1', 'Test Blog', 'example.org', array() ) ), '', true, 'pub-1' ),
			'pre-production, path'                 => array( 'https://example.org/dev', array( array( 'pub-1', 'Test Blog', 'example.org', array() ) ), '', true, 'pub-1' ),
			'pre-production, no production'        => array( 'https://staging.unknown.example', array( array( 'pub-1', 'Test Blog', 'example.org', array() ) ), '', true, '' ),
			'no match'                             => array( 'https://unknown.example', array( array( 'pub-1', 'Test Blog', 'example.org', array() ) ), '', false, '' ),
			'domain matches but name is different' => array( 'https://example.org', array( array( 'pub-1', 'Something Else Entirely', 'example.org', array() ) ), '', false, '' ),
			'subdirectory site vs the root domain' => array( 'https://example.org/site2', array( array( 'pub-1', 'Test Blog', 'example.org', array() ) ), '', false, '' ),
		);
	}

	/**
	 * Tests how sites are matched to publishers when they're activated.
	 *
	 * @param string $site_url               The site's home URL.
	 * @param array  $publishers             The publishers (ID, name, domain, and extra config).
	 * @param string $match_id               The expected matching publisher ID.
	 * @param bool   $is_preproduction       Whether the site should look like a pre-production site.
	 * @param string $production_match_id    The expected matching production publisher ID.
	 *
	 * @return void
	 */
	#[\PHPUnit\Framework\Attributes\DataProvider( 'activationScenarios' )]
	public function testActivationMatching( string $site_url, array $publishers, string $match_id, bool $is_preproduction, string $production_match_id ): void {

		$this->connect();

		MockGistApi::set_publishers( array_map( fn ( $p ) => MockGistApi::publisher( $p[0], $p[1], $p[2], $p[3] ), $publishers ) );

		add_filter( 'home_url', fn () => $site_url );

		$matches = Credentials::get_activation_matches();

		$this->assertSame( $match_id, $matches->match_id, 'match_id' );
		$this->assertSame( $is_preproduction, $matches->is_preproduction, 'is_preproduction' );
		$this->assertSame( $production_match_id, $matches->production_match_id, 'production_match_id' );
		$this->assertSame( $site_url, $matches->site_url );
	}

	/**
	 * Tests that activation matching lists every enabled publisher, alphabetically, for the dropdown, when sharing is
	 * allowed (for network administrators).
	 *
	 * @return void
	 */
	public function testActivationMatchingListsEnabledPublishersAlphabetically(): void {

		$this->connect();

		MockGistApi::set_publishers(
			array(
				MockGistApi::publisher( 'pub-z', 'zebra News', 'zebra.example' ),
				MockGistApi::publisher( 'pub-off', 'Disabled', 'off.example', array(), false ),
				MockGistApi::publisher( 'pub-a', 'Aardvark Times', 'aardvark.example' ),
			)
		);

		$publishers = Credentials::get_activation_matches( 0, true )->publishers;

		$this->assertSame( array( 'pub-a', 'pub-z' ), array_map( fn ( $p ) => $p->id, $publishers ) );
		$this->assertSame( array( 'Aardvark Times', 'zebra News' ), array_map( fn ( $p ) => $p->name, $publishers ) );
	}

	/**
	 * Tests that, without sharing, activation matching only lists the publishers that match the site.
	 *
	 * @return void
	 */
	public function testActivationMatchingWithoutSharingListsOnlyMatchingPublishers(): void {

		$this->connect();

		MockGistApi::set_publishers(
			array(
				MockGistApi::publisher( 'pub-match', get_bloginfo( 'name' ), 'example.org' ),
				MockGistApi::publisher( 'pub-production', get_bloginfo( 'name' ), 'example.org' ),
				MockGistApi::publisher( 'pub-other', 'Aardvark Times', 'aardvark.example' ),
			)
		);

		add_filter( 'home_url', fn () => 'https://example.org' );

		$this->assertSame( array( 'pub-match', 'pub-production' ), array_map( fn ( $p ) => $p->id, Credentials::get_activation_matches()->publishers ) );
		$this->assertCount( 3, Credentials::get_activation_matches( 0, true )->publishers );
	}

	/**
	 * Tests that, without sharing, a publisher that another site in the network is linked to is only matched and
	 * listed when one of its own domains is the site's domain, not when it only looks like the site's production site.
	 *
	 * @return void
	 */
	public function testActivationMatchingSkipsPublishersLinkedToOtherSites(): void {

		$this->require_multisite();
		$this->connect();

		$other_site = self::factory()->blog->create( array( 'path' => '/other/' ) );

		$publisher = MockGistApi::publisher( 'pub-taken', get_bloginfo( 'name' ), 'example.org', array( 'dev' => 'dev.example.org' ) );

		$this->link_publisher( $publisher, $other_site );
		self::reset_plugin_state();

		$home_url = 'https://staging.example.org';

		add_filter(
			'home_url',
			function () use ( &$home_url ) {
				return $home_url;
			}
		);

		$matches = Credentials::get_activation_matches();

		$this->assertSame( '', $matches->production_match_id );
		$this->assertSame( array(), $matches->publishers );

		$this->assertSame( 'pub-taken', Credentials::get_activation_matches( 0, true )->production_match_id, 'a network administrator can share it' );

		foreach ( array( 'https://example.org', 'https://dev.example.org' ) as $home_url ) {

			$matches = Credentials::get_activation_matches();

			$this->assertSame( 'pub-taken', $matches->match_id, $home_url );
			$this->assertSame( array( 'pub-taken' ), array_map( fn ( $publisher ) => $publisher->id, $matches->publishers ), $home_url );
		}
	}

	/**
	 * Tests that the network's map of linked publishers is rebuilt if it's missing (as after an upgrade), and that a
	 * deleted site's publisher is forgotten.
	 *
	 * @return void
	 */
	public function testPublisherLinksAreRebuiltAndForgotten(): void {

		$this->require_multisite();
		$this->connect();

		$other_site = self::factory()->blog->create( array( 'path' => '/other/' ) );

		$this->link_publisher( MockGistApi::publisher( 'pub-other', 'Other', 'other.example' ), $other_site );

		$this->assertSame( array( 'pub-other' ), self::call_static( Credentials::class, 'get_publisher_ids_linked_to_other_sites', get_current_blog_id() ) );
		$this->assertSame( array(), self::call_static( Credentials::class, 'get_publisher_ids_linked_to_other_sites', $other_site ), 'a site\'s own publisher isn\'t counted' );

		delete_site_option( 'gist_answers_publisher_links' );

		$this->assertSame( array( 'pub-other' ), self::call_static( Credentials::class, 'get_publisher_ids_linked_to_other_sites', get_current_blog_id() ) );

		// As when the site is deleted (without dropping its tables, which the test's transaction can't roll back).
		do_action( 'wp_uninitialize_site', get_site( $other_site ) );

		$this->assertSame( array(), self::call_static( Credentials::class, 'get_publisher_ids_linked_to_other_sites', get_current_blog_id() ) );
	}

	/**
	 * Tests that a sites' stored publishers are added to a missing map of linked publishers a batch at a time, that a
	 * production match can't be shared until it's complete, and that the WP-Cron event completes it.
	 *
	 * @return void
	 */
	public function testPublisherLinksAreRebuiltInBatches(): void {

		$this->require_multisite();
		$this->connect();

		$site_a = self::factory()->blog->create( array( 'path' => '/site-a/' ) );
		$site_b = self::factory()->blog->create( array( 'path' => '/site-b/' ) );

		$this->link_publisher( MockGistApi::publisher( 'pub-a', 'Site A', 'a.example' ), $site_a );
		$this->link_publisher( MockGistApi::publisher( 'pub-b', 'Site B', 'b.example' ), $site_b );

		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-free', get_bloginfo( 'name' ), 'example.org' ) ) );
		self::reset_plugin_state();
		self::set_static( Credentials::class, 'publisher_links_rebuild_batch_size', 1 );

		delete_site_option( 'gist_answers_publisher_links' );
		wp_clear_scheduled_hook( Credentials::PUBLISHER_LINKS_REBUILD_CRON_HOOK );

		add_filter( 'home_url', fn () => 'https://staging.example.org' );

		$this->assertSame( array(), Credentials::get_activation_matches()->publishers, 'a production match isn\'t shared while the map is incomplete' );
		$this->assertFalse( self::call_static( Credentials::class, 'publisher_links_are_complete' ) );
		$this->assertNotFalse( wp_next_scheduled( Credentials::PUBLISHER_LINKS_REBUILD_CRON_HOOK ) );

		wp_clear_scheduled_hook( Credentials::PUBLISHER_LINKS_REBUILD_CRON_HOOK );
		do_action( Credentials::PUBLISHER_LINKS_REBUILD_CRON_HOOK );

		$this->assertTrue( self::call_static( Credentials::class, 'publisher_links_are_complete' ) );
		$this->assertFalse( wp_next_scheduled( Credentials::PUBLISHER_LINKS_REBUILD_CRON_HOOK ), 'not scheduled again once complete' );
		$this->assertSame(
			array(
				$site_a => 'pub-a',
				$site_b => 'pub-b',
			),
			get_site_option( 'gist_answers_publisher_links' )
		);

		$this->assertSame( array( 'pub-free' ), array_map( fn ( $publisher ) => $publisher->id, Credentials::get_activation_matches()->publishers ) );
	}

	/**
	 * Tests that a site that no longer exists (e.g., one deleted while the plugin wasn't loaded) is dropped from the
	 * map of linked publishers.
	 *
	 * @return void
	 */
	public function testPublisherLinksOfMissingSitesAreForgotten(): void {

		$this->require_multisite();
		$this->connect();

		$other_site = self::factory()->blog->create( array( 'path' => '/other/' ) );

		$this->link_publisher( MockGistApi::publisher( 'pub-other', 'Other', 'other.example' ), $other_site );

		$links = get_site_option( 'gist_answers_publisher_links' );

		$links[ $other_site + 1000 ] = 'pub-gone';

		update_site_option( 'gist_answers_publisher_links', $links );

		$this->assertSame( array( 'pub-other' ), self::call_static( Credentials::class, 'get_publisher_ids_linked_to_other_sites', get_current_blog_id() ) );
		$this->assertSame( array( $other_site => 'pub-other' ), get_site_option( 'gist_answers_publisher_links' ) );
	}

	/**
	 * Tests that, without sharing, a publisher whose domain is the site's domain is listed even if its name doesn't
	 * match the site's, but isn't linked without asking.
	 *
	 * @return void
	 */
	public function testActivationMatchingListsDomainMatchesWhateverTheirName(): void {

		$this->connect();

		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-domain', 'Aardvark Times', 'example.org' ) ) );

		add_filter( 'home_url', fn () => 'https://example.org' );

		$matches = Credentials::get_activation_matches();

		$this->assertSame( '', $matches->match_id );
		$this->assertSame( array( 'pub-domain' ), array_map( fn ( $publisher ) => $publisher->id, $matches->publishers ) );
	}

	/**
	 * Tests that the publisher group (account) is fetched and stored when none is stored.
	 *
	 * @return void
	 */
	public function testPublisherGroupIsFetchedAndStored(): void {

		$this->connect();

		$this->assertSame( 'pg-test', Credentials::get_publisher_group()->id ?? null );
		$this->assertSame( 'pg-test', Credentials::get_publisher_group_id() );

		self::reset_plugin_state();
		Credentials::get_publisher_group();

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups' ) );
	}

	/**
	 * Tests that a failed publisher group request isn't stored, and isn't repeated on every request.
	 *
	 * @return void
	 */
	public function testFailedPublisherGroupRequestBacksOff(): void {

		$this->connect();

		MockGistApi::on( 'GET', 'publisher_groups', 500, array( 'error' => 'Unavailable' ) );

		$this->assertSame( '', Credentials::get_publisher_group_id() );

		self::reset_plugin_state();

		$this->assertSame( '', Credentials::get_publisher_group_id() );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups' ), 'not requested again while backing off' );
		$this->assertFalse( get_option( 'gist_answers_publisher_group' ), 'nothing is stored' );

		delete_transient( 'gist_answers_publisher_group_failed' );
		MockGistApi::on( 'GET', 'publisher_groups', 200, MockGistApi::publisher_group() );

		$this->assertSame( 'pg-test', Credentials::get_publisher_group_id() );
	}

	/**
	 * Tests that the admin screens refresh the publisher data at most once a minute.
	 *
	 * @return void
	 */
	public function testPublisherDataIsRefreshedAtMostOnceAMinute(): void {

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), 'example.org' ) );

		self::reset_plugin_state();
		MockGistApi::$requests = array();

		Credentials::refresh_publisher_data_if_stale();
		self::reset_plugin_state();
		Credentials::refresh_publisher_data_if_stale();

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-own' ), 'the linked publisher is fetched by itself' );
		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publishers' ), 'not the whole account' );
		$this->assertTrue( Credentials::publisher_data_is_fresh() );

		self::reset_plugin_state();
		Credentials::refresh_publisher_data();

		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publishers/pub-own' ), 'an explicit refresh always runs' );
	}

	/**
	 * Tests that a corrupted Sodium payload (a nonce of the wrong length, or no ciphertext) decrypts to an empty
	 * string, rather than throwing.
	 *
	 * @return void
	 */
	public function testCorruptedSodiumPayloadDecryptsToNothing(): void {

		if ( ! function_exists( 'sodium_crypto_secretbox' ) ) {
			$this->markTestSkipped( 'Requires Sodium.' );
		}

		$payload = Credentials::encrypt( 'sk_test', Credentials::CIPHER_SODIUM );

		$this->assertSame( 'sk_test', Credentials::decrypt( $payload ) );

		$this->assertSame( '', Credentials::decrypt( array_merge( $payload, array( 'nonce' => base64_encode( 'short' ) ) ) ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Building a corrupted payload.
		$this->assertSame( '', Credentials::decrypt( array_merge( $payload, array( 'value' => base64_encode( 'x' ) ) ) ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Building a corrupted payload.
	}

	/**
	 * Tests that a token encrypted with version 1 of the OpenSSL schemes (bound to the main site's home URL) still
	 * decrypts on the other sites of a network, and is re-encrypted without the URL when it's read.
	 *
	 * @return void
	 */
	public function testVersionOneTokenDecryptsOnEverySiteAndIsUpgraded(): void {

		if ( ! function_exists( 'openssl_encrypt' ) ) {
			$this->markTestSkipped( 'Requires OpenSSL.' );
		}

		$key = self::call_static( Credentials::class, 'get_encryption_key', 32, null, 1 );
		$iv  = random_bytes( 12 );
		$tag = '';

		$cipher_text = openssl_encrypt( 'sk_version_one', 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, home_url() . '|gist_answers|gist_answers_api_token|v1' );

		// phpcs:disable WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Building a version 1 payload.
		$payload = array(
			'version' => 1,
			'cipher'  => Credentials::CIPHER_OPENSSL_GCM,
			'iv'      => base64_encode( $iv ),
			'tag'     => base64_encode( $tag ),
			'value'   => base64_encode( $cipher_text ),
		);
		// phpcs:enable WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode

		if ( is_multisite() ) {
			update_site_option( 'gist_answers_api_token', $payload );
			switch_to_blog( self::factory()->blog->create( array( 'path' => '/elsewhere/' ) ) );
		} else {
			update_option( 'gist_answers_api_token', $payload );
		}

		$this->assertSame( 'sk_version_one', Credentials::get_api_token() );

		$stored = is_multisite() ? get_site_option( 'gist_answers_api_token' ) : get_option( 'gist_answers_api_token' );

		$this->assertSame( 2, $stored['version'], 're-encrypted with the current version' );

		add_filter( 'home_url', fn () => 'https://moved.example' );

		$this->assertSame( 'sk_version_one', Credentials::get_api_token(), 'no longer depends on the home URL' );

		if ( is_multisite() ) {
			restore_current_blog();
		}
	}

	/**
	 * Tests that categories are fetched and stored, keyed by ID.
	 *
	 * @return void
	 */
	public function testCategoriesAreStored(): void {

		$this->connect();

		MockGistApi::on(
			'GET',
			'categories',
			200,
			array(
				array(
					'id'   => 'cat-1',
					'name' => 'News',
				),
				array(
					'id'   => 'cat-2',
					'name' => 'Sports',
				),
				array( 'name' => 'Missing ID' ),
			)
		);

		$this->assertSame(
			array(
				'cat-1' => 'News',
				'cat-2' => 'Sports',
			),
			Credentials::update_categories()
		);
	}
}
