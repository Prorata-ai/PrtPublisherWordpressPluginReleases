<?php
/**
 * Tests for the site model and the connection wizard states built from it.
 *
 * @package GistAnswers
 */

use GistAnswers\Admin\ConnectionWizard;
use GistAnswers\API\Credentials;
use GistAnswers\Model\GistSite;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for the site model and the connection wizard states built from it.
 */
final class GistSiteTest extends TestCase {

	/**
	 * Build connection data for the wizard, overriding the defaults (a valid token from the database, no publisher).
	 *
	 * @param array<string, mixed> $overrides The connection data to override.
	 *
	 * @return object The connection data.
	 */
	private static function connection_data( array $overrides = array() ): object {
		return (object) array_merge(
			array(
				'has_stored_api_token' => true,
				'has_valid_api_token'  => true,
				'api_token_code'       => 200,
				'api_token_error'      => '',
				'has_stored_publisher' => false,
				'has_valid_publisher'  => false,
				'api_token_source'     => 'database',
			),
			$overrides
		);
	}

	/**
	 * Tests the WordPress details of the site.
	 *
	 * @return void
	 */
	public function testWordPressDetails(): void {

		$site = GistSite::get();

		$this->assertSame( 'example.org', $site->get_domain() );
		$this->assertSame( 'Test Blog', $site->get_display_name() );
		$this->assertSame( 'testblog', $site->get_searchable_name() );
		$this->assertSame( home_url(), $site->get_home_url() );
		$this->assertSame( admin_url(), $site->get_admin_url() );
		$this->assertStringStartsWith( admin_url(), $site->get_gist_url() );
		$this->assertStringContainsString( 'gist-answers', $site->get_gist_url() );
		$this->assertStringEndsWith( 'public/images/globe.png', $site->get_icon_url() );
		$this->assertSame( is_multisite() ? get_current_blog_id() : 0, $site->get_blog_id() );
	}

	/**
	 * Tests that sites are cached until forgotten.
	 *
	 * @return void
	 */
	public function testSitesAreCachedUntilForgotten(): void {

		$site = GistSite::get();

		$this->assertSame( $site, GistSite::get() );

		GistSite::forget();

		$this->assertNotSame( $site, GistSite::get() );
	}

	/**
	 * Tests a site without an API token.
	 *
	 * @return void
	 */
	public function testDisconnectedSite(): void {

		$site = GistSite::get();

		$this->assertFalse( $site->has_stored_api_token() );
		$this->assertFalse( $site->has_valid_api_token() );
		$this->assertFalse( $site->has_valid_publisher() );
		$this->assertFalse( $site->is_connected() );
		$this->assertSame( '', $site->get_publisher_id() );
		$this->assertSame( 0, $site->get_widgets_count() );
		$this->assertSame( array(), MockGistApi::requests(), 'nothing is requested without a token' );
	}

	/**
	 * Tests a site with a valid token that hasn't been activated.
	 *
	 * @return void
	 */
	public function testConnectedButNotActivatedSite(): void {

		$this->connect();

		$site = GistSite::get();

		$this->assertTrue( $site->has_stored_api_token() );
		$this->assertTrue( $site->has_valid_api_token() );
		$this->assertFalse( $site->has_valid_publisher() );
		$this->assertFalse( $site->is_connected() );
		$this->assertSame( 'Test Partner', $site->get_publisher_group()->name );
	}

	/**
	 * Tests an activated site, and its widgets (sorted by name, with validity checks by type).
	 *
	 * @return void
	 */
	public function testActivatedSite(): void {

		$this->connect();

		$this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				'Test Blog',
				'example.org',
				array(
					'widgets' => array(
						'chat-widgets'         => array( 'chat-widget-1' => array( 'name' => 'Answers' ) ),
						'question-bar-widgets' => array(
							'question-bar-widget-z' => array( 'name' => 'Zebra' ),
							'question-bar-widget-a' => array( 'name' => 'Aardvark' ),
						),
					),
				)
			)
		);

		$site = GistSite::get();

		$this->assertTrue( $site->is_connected() );
		$this->assertSame( 'pub-own', $site->get_publisher_id() );
		$this->assertTrue( $site->has_stored_publisher() );
		$this->assertSame( 3, $site->get_widgets_count() );
		$this->assertSame( array( 'question-bar-widget-a', 'question-bar-widget-z' ), array_map( fn ( $widget ) => $widget->get_id(), $site->get_search_widgets() ) );

		$this->assertTrue( $site->chat_widget_id_is_valid( 'chat-widget-1' ) );
		$this->assertFalse( $site->chat_widget_id_is_valid( 'question-bar-widget-a' ) );
		$this->assertTrue( $site->search_widget_id_is_valid( 'question-bar-widget-a' ) );
		$this->assertFalse( $site->search_widget_id_is_valid( 'chat-widget-1' ) );
		$this->assertFalse( $site->search_widget_id_is_valid( '' ) );
	}

	/**
	 * Tests the categories: internal ones are hidden, they're sorted by name, and "Other" is the default.
	 *
	 * @return void
	 */
	public function testCategories(): void {

		$this->connect();

		MockGistApi::on(
			'GET',
			'categories',
			200,
			array(
				array(
					'id'   => 'cat-tech',
					'name' => 'Technology',
				),
				array(
					'id'   => 'cat-internal',
					'name' => 'ProRata Internal',
				),
				array(
					'id'   => 'cat-hidden',
					'name' => 'hidden_category',
				),
				array(
					'id'   => 'cat-other',
					'name' => 'Other',
				),
				array(
					'id'   => 'cat-art',
					'name' => 'Art',
				),
			)
		);

		$site = GistSite::get();

		$this->assertSame( array(), $site->get_categories(), 'categories are only gathered on request' );

		$site->reload_categories();

		$this->assertSame(
			array(
				'cat-art'   => 'Art',
				'cat-other' => 'Other',
				'cat-tech'  => 'Technology',
			),
			$site->get_categories()
		);
		$this->assertSame( 'cat-other', $site->get_default_category_id() );
		$this->assertSame( 'Technology', $site->look_up_category_name( 'cat-tech' ) );
		$this->assertSame( '', $site->look_up_category_name( 'cat-internal' ) );
		$this->assertTrue( $site->category_id_is_valid( 'cat-art' ) );
		$this->assertFalse( $site->category_id_is_valid( 'cat-hidden' ) );
	}

	/**
	 * Tests that the first category is the default when there's no "Other" category.
	 *
	 * @return void
	 */
	public function testDefaultCategoryWithoutOther(): void {

		$this->connect();

		MockGistApi::on(
			'GET',
			'categories',
			200,
			array(
				array(
					'id'   => 'cat-tech',
					'name' => 'Technology',
				),
				array(
					'id'   => 'cat-art',
					'name' => 'Art',
				),
			)
		);

		$site = GistSite::get();
		$site->reload_categories();

		$this->assertSame( 'cat-art', $site->get_default_category_id() );
	}

	/**
	 * Tests that activation errors are shown once.
	 *
	 * @return void
	 */
	public function testActivationErrorsAreShownOnce(): void {

		$this->assertEquals( (object) array(), GistSite::get_site_activation_errors() );

		GistSite::store_site_activation_errors( array( (object) array( 'message' => 'Name taken' ) ), (object) array( 'blog_id' => 7 ) );

		$errors = GistSite::get_site_activation_errors();

		$this->assertSame( 'Name taken', $errors->errors[0]->message );
		$this->assertSame( 7, $errors->data->blog_id );
		$this->assertEquals( (object) array(), GistSite::get_site_activation_errors() );
	}

	/**
	 * Tests that a subsite's model reads that subsite's details and publisher.
	 *
	 * @return void
	 */
	public function testSubsiteDetails(): void {

		$this->require_multisite();

		$this->connect();

		$blog_id = self::factory()->blog->create(
			array(
				'domain' => 'sub.example.org',
				'title'  => 'Sub Site',
			)
		);

		$this->link_publisher( MockGistApi::publisher( 'pub-sub', 'Sub Site', 'sub.example.org' ), $blog_id );

		$current_blog_id = get_current_blog_id();

		$site = GistSite::get( $blog_id );

		$this->assertSame( $blog_id, $site->get_blog_id() );
		$this->assertSame( 'sub.example.org', $site->get_domain() );
		$this->assertSame( 'Sub Site', $site->get_display_name() );
		$this->assertSame( 'pub-sub', $site->get_publisher_id() );
		$this->assertSame( $current_blog_id, get_current_blog_id(), 'the current site is restored' );
		$this->assertFalse( GistSite::get()->has_valid_publisher(), 'the main site is not linked' );
	}

	/**
	 * Tests the wizard for a connected and activated site, which hides it unless the site was just connected.
	 *
	 * @return void
	 */
	public function testWizardForActivatedSite(): void {

		$data = self::connection_data( array( 'has_valid_publisher' => true ) );

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 0 );

		$this->assertSame( 'connected', $wizard->status );
		$this->assertFalse( $wizard->show_wizard );
		$this->assertTrue( $wizard->can_hide_wizard );
		$this->assertFalse( $wizard->hide_connection_form );

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 1 );

		$this->assertTrue( $wizard->show_wizard, 'the success state is shown right after connecting' );
	}

	/**
	 * Tests the wizard for a site with a valid token and no publisher.
	 *
	 * @return void
	 */
	public function testWizardForUnactivatedSite(): void {

		$data = self::connection_data();

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'submenu', 0 );

		$this->assertSame( 'warning', $wizard->status );
		$this->assertStringContainsString( 'has not been activated', $wizard->message );
		$this->assertTrue( $wizard->hide_connection_form );

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 0 );

		$this->assertSame( 'connected', $wizard->status );
		$this->assertFalse( $wizard->show_wizard );
	}

	/**
	 * Tests the wizard after an invalid token was entered.
	 *
	 * @return void
	 */
	public function testWizardForRejectedToken(): void {

		$wizard = ConnectionWizard::get_wizard_content_data_from( self::connection_data( array( 'has_valid_api_token' => false ) ), 'single', -1 );

		$this->assertSame( 'error', $wizard->status );
		$this->assertStringContainsString( 'not valid', $wizard->message );
		$this->assertFalse( $wizard->hide_connection_form );
	}

	/**
	 * Tests the wizard for a stored token the API no longer accepts, which depends on where the token comes from.
	 *
	 * @param string $source        The token source.
	 * @param string $message       Part of the expected message.
	 * @param bool   $form_is_shown Whether the token form is shown.
	 *
	 * @return void
	 */
	#[\PHPUnit\Framework\Attributes\DataProvider( 'expiredTokenSources' )]
	public function testWizardForExpiredToken( string $source, string $message, bool $form_is_shown ): void {

		if ( 'database' === $source ) {
			$this->require_single_site();
		}

		$data = self::connection_data(
			array(
				'has_valid_api_token' => false,
				'api_token_code'      => 401,
				'api_token_source'    => $source,
			)
		);

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 0 );

		$this->assertSame( 'error', $wizard->status );
		$this->assertStringContainsString( $message, $wizard->message );
		$this->assertSame( ! $form_is_shown, $wizard->hide_connection_form );
	}

	/**
	 * Token sources, with the message and form visibility for an expired token from each.
	 *
	 * @return array<string, array<mixed>>
	 */
	public static function expiredTokenSources(): array {
		return array(
			'VIP'         => array( 'vip', 'provided by WordPress VIP', false ),
			'environment' => array( 'environment', 'server environment', false ),
			'constant'    => array( 'constant', 'WordPress configuration', false ),
			'database'    => array( 'database', 'enter your new token below', true ),
		);
	}

	/**
	 * Tests the wizard for an expired token on a subsite, which points to the network admin.
	 *
	 * @return void
	 */
	public function testWizardForExpiredTokenOnSubsite(): void {

		$this->require_multisite();

		$data = self::connection_data(
			array(
				'has_valid_api_token' => false,
				'api_token_code'      => 401,
			)
		);

		$this->log_in_as( 'administrator' );

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 0 );

		$this->assertStringContainsString( 'contact your network administrator', $wizard->message );
		$this->assertTrue( $wizard->hide_connection_form );

		$this->log_in_as_super_admin();

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 0 );

		$this->assertStringContainsString( 'Network Dashboard', $wizard->message );

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'network', 0 );

		$this->assertStringContainsString( 'enter your new token below', $wizard->message );
		$this->assertFalse( $wizard->hide_connection_form );
	}

	/**
	 * Tests the wizard when the API server can't be reached or fails, including its status code and error.
	 *
	 * @return void
	 */
	public function testWizardForUnreachableServer(): void {

		$wizard = ConnectionWizard::get_wizard_content_data_from( self::connection_data( array( 'api_token_code' => 999 ) ), 'single', 0 );

		$this->assertSame( 'warning', $wizard->status );
		$this->assertSame( 'The Gist API server is currently unreachable. Please try again later.', $wizard->message );
		$this->assertTrue( $wizard->hide_connection_form );

		$data = self::connection_data(
			array(
				'api_token_code'  => 503,
				'api_token_error' => 'Down for maintenance.',
			)
		);

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 0 );

		$this->assertStringEndsWith( '(Status code: 503. Down for maintenance.)', $wizard->message );
	}

	/**
	 * Tests the wizard for an incomplete VIP configuration.
	 *
	 * @return void
	 */
	public function testWizardForIncompleteVipConfig(): void {

		$data = self::connection_data(
			array(
				'has_stored_api_token' => false,
				'has_valid_api_token'  => false,
				'api_token_source'     => 'vip',
			)
		);

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 0 );

		$this->assertSame( 'warning', $wizard->status );
		$this->assertStringContainsString( 'managed by WordPress VIP', $wizard->message );
		$this->assertTrue( $wizard->hide_connection_form );
	}

	/**
	 * Tests the wizard on a subsite without a token, which can't be entered there.
	 *
	 * @return void
	 */
	public function testWizardForSubsiteWithoutToken(): void {

		$this->require_multisite();

		$data = self::connection_data(
			array(
				'has_stored_api_token' => false,
				'has_valid_api_token'  => false,
			)
		);

		$this->log_in_as( 'administrator' );

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'single', 0 );

		$this->assertSame( 'Please contact your network administrator to add your API token.', $wizard->message );
		$this->assertTrue( $wizard->hide_connection_form );

		$wizard = ConnectionWizard::get_wizard_content_data_from( $data, 'network', 0 );

		$this->assertSame( '', $wizard->message );
		$this->assertFalse( $wizard->hide_connection_form );
	}

	/**
	 * Tests the wizard built from a real site whose stored token the API rejects.
	 *
	 * @return void
	 */
	public function testWizardFromSiteWithRejectedToken(): void {

		Credentials::store_api_token( self::TOKEN );

		MockGistApi::on( 'GET', 'publisher_groups', 401, array( 'error' => 'Unauthorized' ) );

		$wizard = ConnectionWizard::get_wizard_content_data_for( GistSite::get(), 'single' );

		$this->assertSame( 'error', $wizard->status );
		$this->assertStringContainsString( 'no longer valid', $wizard->message );
		$this->assertSame( 401, $wizard->server_code );
		$this->assertSame( 'database', $wizard->api_token_source );
	}

	/**
	 * Tests the wizard built from a real activated site.
	 *
	 * @return void
	 */
	public function testWizardFromActivatedSite(): void {

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-own', 'Test Blog', 'example.org' ) );

		$wizard = ConnectionWizard::get_wizard_content_data_for( GistSite::get(), 'single' );

		$this->assertSame( 'connected', $wizard->status );
		$this->assertFalse( $wizard->show_wizard );
		$this->assertSame( 200, $wizard->server_code );
	}
}
