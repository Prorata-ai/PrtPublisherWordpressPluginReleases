<?php
/**
 * Tests for the helper classes: Utilities (beyond UtilitiesTest), GistURLs, and AnswerPages.
 *
 * @package GistAnswers
 */

use GistAnswers\Plugin\AnswerPages;
use GistAnswers\Plugin\GistURLs;
use GistAnswers\Plugin\Utilities;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for the helper classes: Utilities (beyond UtilitiesTest), GistURLs, and AnswerPages.
 */
final class HelpersTest extends TestCase {

	/**
	 * Tests that domains match ignoring scheme, `www.`, case, ports, and trailing slashes, but not paths.
	 *
	 * @return void
	 */
	public function testDomainsMatch(): void {

		$this->assertTrue( Utilities::do_domains_match( 'https://www.Example.com/', 'example.com' ) );
		$this->assertTrue( Utilities::do_domains_match( 'http://example.com:8080', 'https://example.com?x=1' ) );
		$this->assertFalse( Utilities::do_domains_match( 'example.com/blog', 'example.com' ) );
		$this->assertFalse( Utilities::do_domains_match( 'example.com', 'example.org' ) );
		$this->assertFalse( Utilities::do_domains_match( '', '' ), 'empty domains never match' );
	}

	/**
	 * Tests extracting hosts and domains from URLs.
	 *
	 * @return void
	 */
	public function testHostExtraction(): void {

		$this->assertSame( 'example.com', Utilities::extract_host_from_url( 'https://Example.COM/path' ) );
		$this->assertSame( 'example.com', Utilities::extract_host_from_url( 'example.com' ) );
		$this->assertSame( 'www.example.com', Utilities::get_domain_from_url( 'HTTPS://WWW.EXAMPLE.COM' ) );
	}

	/**
	 * Tests extracting a shortcode and its attributes from post content.
	 *
	 * @return void
	 */
	public function testShortcodeExtraction(): void {

		$content = 'Intro [gist_answers_render_widget type="answer" widgetId=\'chat-1\' echo] outro';

		$data = Utilities::extract_shortcode_data_from( $content, strpos( $content, '[' ) );

		$this->assertSame( 'gist_answers_render_widget', $data->shortcode );
		$this->assertSame( 'answer', $data->params['type'] );
		$this->assertSame( 'chat-1', $data->params['widgetid'] );

		$unclosed = Utilities::extract_shortcode_data_from( 'Intro [gist_answers_render_widget type="answer"', 6 );

		$this->assertSame( '', $unclosed->shortcode );
		$this->assertSame( array(), $unclosed->params );
	}

	/**
	 * Tests plucking from arrays, public properties, and getters, dropping missing and empty values.
	 *
	 * @return void
	 */
	public function testSafeListPluck(): void {

		$with_getter = new class() {

			/**
			 * Get the ID.
			 *
			 * @return string The ID.
			 */
			public function get_id(): string {
				return 'from-getter';
			}
		};

		$list = array(
			array( 'id' => 'from-array' ),
			(object) array( 'id' => 'from-property' ),
			$with_getter,
			array( 'name' => 'no id' ),
			(object) array( 'id' => '' ),
			'not a list item',
		);

		$this->assertSame( array( 'from-array', 'from-property', 'from-getter' ), array_values( Utilities::safe_list_pluck( $list, 'id' ) ) );
	}

	/**
	 * Tests extracting a script's source from a widget snippet.
	 *
	 * @return void
	 */
	public function testScriptTagSource(): void {

		$this->assertSame( 'https://widgets.example.test/widget.js', Utilities::get_script_tag_src( '<script type="module" src="https://widgets.example.test/widget.js"></script>' ) ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Test input for the snippet parser.
		$this->assertSame( 'https://a.test/b.js', Utilities::get_script_tag_src( "<script src='https://a.test/b.js' async></script>" ) ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Test input for the snippet parser.
		$this->assertSame( '', Utilities::get_script_tag_src( '<script>inline()</script>' ) );
		$this->assertSame( '', Utilities::get_script_tag_src( '' ) );
	}

	/**
	 * Tests the build environment: a source copy (still holding the placeholder) reports itself as a local
	 * development build, and a release copy reports the environment it was built for.
	 *
	 * @return void
	 */
	public function testBuildEnvironment(): void {

		$expected = str_contains( GIST_ANSWERS_BUILD_ENVIRONMENT, '.BUILD_ENVIRONMENT.' ) ? 'local-dev' : GIST_ANSWERS_BUILD_ENVIRONMENT;

		$this->assertSame( $expected, Utilities::get_build_environment_slug() );
	}

	/**
	 * Tests reading the UUID from an embed ticket.
	 *
	 * @return void
	 */
	public function testEmbedTicketUuid(): void {

		$this->assertSame( 'uuid-1234', Utilities::get_embed_token_uuid( MockGistApi::embed_ticket( 'uuid-1234' ) ) );
		$this->assertSame( '', Utilities::get_embed_token_uuid( 'not-a-jwt' ) );
		$this->assertSame( '', Utilities::get_embed_token_uuid( 'a.!!!.c' ) );
		$this->assertSame( '', Utilities::get_embed_token_uuid( 'a.' . rtrim( base64_encode( '{"id":1}' ), '=' ) . '.c' ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Building a test JWT.
	}

	/**
	 * Tests that the token hash is a short-lived grant, tied to the embed UUID, the user, and the site's publisher.
	 *
	 * @return void
	 */
	public function testTokenHashIsABoundShortLivedGrant(): void {

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), 'example.org' ) );

		$this->assertSame( '', Utilities::get_token_hash_from_embed_uuid( 'uuid-1234' ), 'no grant without a logged-in user' );

		$user_id = $this->log_in_as();

		$hash = Utilities::get_token_hash_from_embed_uuid( 'uuid-1234' );

		$this->assertMatchesRegularExpression( '/^\d+\.[0-9a-f]{64}$/', $hash );
		$this->assertTrue( Utilities::token_hash_is_valid( $hash, 'uuid-1234' ) );
		$this->assertFalse( Utilities::token_hash_is_valid( $hash, 'uuid-5678' ), 'another embed UUID' );
		$this->assertSame( '', Utilities::get_token_hash_from_embed_uuid( '' ), 'an empty UUID has no usable hash' );

		[ $expires, $hmac ] = explode( '.', $hash );

		$this->assertEqualsWithDelta( time() + 30 * MINUTE_IN_SECONDS, intval( $expires ), 5 );
		$this->assertFalse( Utilities::token_hash_is_valid( ( intval( $expires ) + 60 ) . '.' . $hmac, 'uuid-1234' ), 'a changed expiry' );
		$this->assertFalse( Utilities::token_hash_is_valid( Utilities::get_token_hash_from_embed_uuid( 'uuid-1234', 0, time() - 1 ), 'uuid-1234' ), 'an expired grant' );
		$this->assertFalse( Utilities::token_hash_is_valid( Utilities::get_token_hash_from_embed_uuid( 'uuid-1234', 0, time() + DAY_IN_SECONDS ), 'uuid-1234' ), 'a grant longer than any issued' );
		$this->assertFalse( Utilities::token_hash_is_valid( 'wrong', 'uuid-1234' ) );

		$this->log_in_as();

		$this->assertFalse( Utilities::token_hash_is_valid( $hash, 'uuid-1234' ), 'another user' );

		wp_set_current_user( $user_id );

		$this->link_publisher( MockGistApi::publisher( 'pub-other', get_bloginfo( 'name' ), 'example.org' ) );

		$this->assertFalse( Utilities::token_hash_is_valid( $hash, 'uuid-1234' ), 'another publisher' );
	}

	/**
	 * Tests that the token hash for a CMS iframe comes from its embed ticket, and ends no later than the ticket does.
	 *
	 * @return void
	 */
	public function testTokenHashFromIframeUrl(): void {

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), 'example.org' ) );
		$this->log_in_as();

		$hash = Utilities::get_token_hash_from_iframe_url( 'https://cms.test/pages/answers?embed=' . rawurlencode( MockGistApi::embed_ticket( 'uuid-1234' ) ) );

		$this->assertTrue( Utilities::token_hash_is_valid( $hash, 'uuid-1234' ) );
		$this->assertSame( '', Utilities::get_token_hash_from_iframe_url( 'https://cms.test/pages/answers' ) );

		$encode = fn ( $data ) => rtrim( strtr( base64_encode( wp_json_encode( $data ) ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Building a test JWT.

		$ticket = $encode( array( 'alg' => 'none' ) ) . '.' . $encode(
			array(
				'uuid' => 'uuid-1234',
				'exp'  => time() + 60,
			)
		) . '.signature';

		$hash = Utilities::get_token_hash_from_iframe_url( 'https://cms.test/pages/answers?embed=' . rawurlencode( $ticket ) );

		$this->assertSame( strval( time() + 60 ), explode( '.', $hash )[0], 'the grant ends when the ticket does' );
	}

	/**
	 * Tests the locks that stop concurrent requests from doing the same work.
	 *
	 * @return void
	 */
	public function testLocks(): void {

		$this->assertTrue( Utilities::acquire_lock( 'gist_answers_test_lock', 30 ) );
		$this->assertFalse( Utilities::acquire_lock( 'gist_answers_test_lock', 30 ), 'already held' );

		if ( is_multisite() ) {
			$this->assertTrue( Utilities::acquire_lock( 'gist_answers_test_lock', 30, true ), 'a network lock is separate' );
			$this->assertFalse( Utilities::acquire_lock( 'gist_answers_test_lock', 30, true ) );
		}

		Utilities::release_lock( 'gist_answers_test_lock' );

		$this->assertTrue( Utilities::acquire_lock( 'gist_answers_test_lock', 30 ), 'released' );
	}

	/**
	 * Tests checking whether a post falls within a tax query.
	 *
	 * @return void
	 */
	public function testPostMatchesTaxQuery(): void {

		$category = self::factory()->category->create( array( 'name' => 'News' ) );
		$in_news  = self::factory()->post->create( array( 'post_category' => array( $category ) ) );
		$elsewise = self::factory()->post->create();

		$tax_query = array(
			array(
				'taxonomy' => 'category',
				'field'    => 'term_id',
				'terms'    => array( $category ),
			),
		);

		$this->assertTrue( Utilities::post_matches_tax_query( $in_news, $tax_query ) );
		$this->assertTrue( Utilities::post_matches_tax_query( get_post( $in_news ), $tax_query ) );
		$this->assertFalse( Utilities::post_matches_tax_query( $elsewise, $tax_query ) );
		$this->assertTrue( Utilities::post_matches_tax_query( $elsewise, array() ), 'an empty tax query matches everything' );
	}

	/**
	 * Tests the CMS iframe names.
	 *
	 * @return void
	 */
	public function testCmsIframeNames(): void {

		foreach ( array( 'answers', 'content-usage', 'revenue', 'website-settings', 'questions', 'widgets', 'widgets-theme', 'widgets-list' ) as $which ) {
			$this->assertTrue( GistURLs::is_valid_cms_iframe( $which ), $which );
		}

		$this->assertFalse( GistURLs::is_valid_cms_iframe( 'settings' ) );
		$this->assertFalse( GistURLs::is_valid_cms_iframe( '' ) );
	}

	/**
	 * Tests the CMS iframe URLs, which carry an embed ticket and the publisher's ID.
	 *
	 * @return void
	 */
	public function testCmsIframeUrls(): void {

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub/own', 'Test Blog', 'example.org' ) );

		$url = GistURLs::get_cms_iframe_url( 'widgets-list' );

		$this->assertStringStartsWith( trailingslashit( GistURLs::get_cms_base_url() ) . 'widgets/site/pub%2Fown/your-widgets?embed=', $url );
		$this->assertSame( Utilities::get_token_hash_from_embed_uuid( 'mock-embed-uuid' ), Utilities::get_token_hash_from_iframe_url( $url ) );

		$embed = MockGistApi::requests( 'POST', '.*embed' );

		$this->assertCount( 1, $embed );
		$this->assertSame( 'pub/own', $embed[0]->body['publisher_id'] ?? null );

		$this->assertSame( '', GistURLs::get_cms_iframe_url( 'nonsense' ) );
	}

	/**
	 * Tests that there's no CMS iframe URL without a publisher, or without an embed ticket.
	 *
	 * @return void
	 */
	public function testCmsIframeUrlsNeedAPublisherAndTicket(): void {

		$this->connect();

		$this->assertSame( '', GistURLs::get_cms_iframe_url( 'answers' ) );
		$this->assertSame( array(), MockGistApi::requests( 'POST', '.*embed' ) );

		$this->link_publisher( MockGistApi::publisher( 'pub-own', 'Test Blog', 'example.org' ) );

		MockGistApi::on( 'POST', '.*embed', 500, array( 'error' => 'Oops' ) );

		$this->assertSame( '', GistURLs::get_cms_iframe_url( 'answers' ) );
	}

	/**
	 * Tests that the base URLs are resolved for this (development) copy.
	 *
	 * @return void
	 */
	public function testBaseUrls(): void {

		$this->assertMatchesRegularExpression( '#^https://[a-z0-9.-]+/#', GistURLs::get_api_base_url() );
		$this->assertMatchesRegularExpression( '#^https://[a-z0-9.-]+/#', GistURLs::get_cms_base_url() );
	}

	/**
	 * Tests finding posts by content: blocks, shortcodes, across post types and statuses, and in batches.
	 *
	 * @return void
	 */
	public function testContentSearch(): void {

		$answer_block   = self::factory()->post->create( array( 'post_content' => '<!-- wp:gist-answers/answer {"widgetId":""} /-->' ) );
		$question_block = self::factory()->post->create(
			array(
				'post_type'    => 'page',
				'post_status'  => 'draft',
				'post_content' => '<!-- wp:gist-answers/question /-->',
			)
		);
		$shortcode      = self::factory()->post->create( array( 'post_content' => '[gist_answers_render_widget type="question"]' ) );
		$plain          = self::factory()->post->create( array( 'post_content' => 'Gist answers are great.' ) );

		$this->assertSame( array( $answer_block ), AnswerPages::get_post_ids_with_gist_answer_block() );
		$this->assertSame( array( $question_block ), AnswerPages::get_post_ids_with_gist_question_block() );
		$this->assertSame( array( $shortcode ), AnswerPages::get_post_ids_with_gist_shortcode() );
		$this->assertNotContains( $plain, AnswerPages::get_post_ids_with_content_substring( 'gist-answers' ) );

		$batch = self::factory()->post->create_many( 105, array( 'post_content' => 'needle-in-content' ) );

		$this->assertSame( $batch, AnswerPages::get_post_ids_with_content_substring( 'needle-in-content' ), 'results past the first batch are included' );
	}

	/**
	 * Tests the detected answer pages: only published pages and posts, sorted by ID, with their details.
	 *
	 * @return void
	 */
	public function testDetectedAnswerPages(): void {

		global $wp_rewrite;

		$wp_rewrite->set_permalink_structure( '/%postname%/' );

		$page   = self::factory()->post->create(
			array(
				'post_type'    => 'page',
				'post_name'    => 'answers',
				'post_title'   => 'Answers',
				'post_content' => '<!-- wp:gist-answers/answer /-->',
			)
		);
		$post   = self::factory()->post->create( array( 'post_content' => '[gist_answers_render_widget type="answer"]' ) );
		$draft  = self::factory()->post->create( array( 'post_status' => 'draft' ) );
		$manual = self::factory()->post->create( array( 'post_content' => 'Hand-placed' ) );

		update_post_meta( $manual, 'gist_answers_answer_widget_manual', '1' );
		update_option( 'gist_answers_answer_widget_post_ids', array( $manual, $page, $draft, $post, $page ) );

		$detected = AnswerPages::get_detected();

		$this->assertSame( array( $page, $post, $manual ), array_column( $detected, 'post_id' ) );

		$this->assertSame( 'page', $detected[0]->post_type );
		$this->assertSame( 'Answers', $detected[0]->post_title );
		$this->assertSame( 'block', $detected[0]->source );
		$this->assertSame( '/answers', $detected[0]->relative_url );
		$this->assertSame( home_url( '/answers/' ), $detected[0]->post_url );
		$this->assertSame( 'shortcode', $detected[1]->source );
		$this->assertSame( 'manual', $detected[2]->source );
	}

	/**
	 * Tests that answer page creation and addition errors are each shown once.
	 *
	 * @return void
	 */
	public function testAnswerPageErrorsAreShownOnce(): void {

		AnswerPages::store_answer_page_creation_errors( array( 'creation failed' ), (object) array( 'title' => 'Answers' ) );
		AnswerPages::store_answer_page_addition_errors( array( 'addition failed' ), (object) array( 'post_id' => 5 ) );

		$creation = AnswerPages::get_answer_page_creation_errors();
		$addition = AnswerPages::get_answer_page_addition_errors();

		$this->assertSame( array( 'creation failed' ), $creation->errors );
		$this->assertSame( 'Answers', $creation->data->title );
		$this->assertSame( array( 'addition failed' ), $addition->errors );
		$this->assertSame( 5, $addition->data->post_id );

		$this->assertEquals( (object) array(), AnswerPages::get_answer_page_creation_errors() );
		$this->assertEquals( (object) array(), AnswerPages::get_answer_page_addition_errors() );
	}
}
