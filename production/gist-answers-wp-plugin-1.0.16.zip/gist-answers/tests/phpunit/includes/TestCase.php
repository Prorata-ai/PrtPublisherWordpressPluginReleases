<?php
/**
 * Base test case for the Gist Answers PHPUnit suite.
 *
 * @package GistAnswers
 */

namespace GistAnswers\Tests;

use GistAnswers\Admin\MenuItems\ToolsOptions;
use GistAnswers\API\Credentials;
use GistAnswers\API\Endpoint;
use GistAnswers\Frontend\FrontendMain;
use GistAnswers\Model\GistSite;
use PHPUnit\Framework\TestCase as PHPUnitTestCase;
use ReflectionClass;
use WP_REST_Request;
use WP_REST_Response;
use WP_UnitTest_Factory;
use WPDieException;

/**
 * Base test case for the Gist Answers PHPUnit suite.
 *
 * Each test runs in a database transaction (rolled back afterwards), with WordPress's hooks restored and caches
 * flushed afterwards, against the mock Gist Answers API, with the plugin's per-request caches reset.
 *
 * (WordPress's own WP_UnitTestCase does much the same, but doesn't support PHPUnit 11, which the plugin uses.)
 */
abstract class TestCase extends PHPUnitTestCase {

	/**
	 * The WordPress hook globals, saved before each test and restored after it.
	 *
	 * @var array<mixed>
	 */
	private array $saved_hooks = array();

	/**
	 * The temporary tables created during the current test, dropped after it.
	 *
	 * @var array<string>
	 */
	private array $temporary_tables = array();

	/**
	 * The WordPress test library's factory for creating users, posts, etc.
	 *
	 * @var WP_UnitTest_Factory|null
	 */
	private static ?WP_UnitTest_Factory $factory = null;

	/**
	 * A valid-looking API token for tests.
	 *
	 * @var string
	 */
	public const TOKEN = 'sk_0123456789abcdef0123456789abcdef';

	/**
	 * Set up each test.
	 *
	 * @return void
	 */
	protected function setUp(): void {

		global $wpdb;

		parent::setUp();

		$this->save_hooks();

		$wpdb->suppress_errors = false;
		$wpdb->show_errors     = true;
		$wpdb->query( 'SET autocommit = 0;' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Test isolation: each test runs in a transaction.
		$wpdb->query( 'START TRANSACTION;' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Test isolation: each test runs in a transaction.

		// Tables created during a test (e.g. for a new site in a network) would end the transaction, so they're made
		// temporary instead, as in WordPress's own test case.
		add_filter( 'query', array( $this, 'make_tables_temporary' ) );

		wp_cache_flush();

		add_filter( 'wp_die_handler', array( $this, 'get_wp_die_handler' ) );
		add_filter( 'wp_die_ajax_handler', array( $this, 'get_wp_die_handler' ) );
		add_filter( 'wp_die_json_handler', array( $this, 'get_wp_die_handler' ) );

		self::reset_plugin_state();

		MockGistApi::install();

		$GLOBALS['wp_rest_server'] = null;
	}

	/**
	 * Tear down each test.
	 *
	 * @return void
	 */
	protected function tearDown(): void {

		global $wpdb;

		$_POST    = array();
		$_GET     = array();
		$_REQUEST = array();

		while ( is_multisite() && ms_is_switched() ) {
			restore_current_blog();
		}

		wp_set_current_user( 0 );

		$wpdb->query( 'ROLLBACK;' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Test isolation: each test runs in a transaction.

		// Turn autocommit back on, so that a test case that doesn't extend this one doesn't run in a transaction that
		// the next test's START TRANSACTION would silently commit.
		$wpdb->query( 'SET autocommit = 1;' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Test isolation: each test runs in a transaction.

		// Temporary tables outlive the transaction, and a later test can create a site with the same ID (e.g. after a
		// test running in its own process reinstalls WordPress, resetting the site IDs), so they're dropped too.
		remove_filter( 'query', array( $this, 'make_tables_temporary' ) );

		foreach ( $this->temporary_tables as $table ) {
			$wpdb->query( "DROP TEMPORARY TABLE IF EXISTS `$table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- The table name comes from WordPress's own CREATE TABLE statement.
		}

		$this->temporary_tables = array();

		wp_cache_flush();

		$this->restore_hooks();

		$GLOBALS['wp_rest_server'] = null;

		parent::tearDown();
	}

	/**
	 * The `query` filter: make CREATE TABLE and DROP TABLE statements use temporary tables.
	 *
	 * @param string $query The SQL query.
	 *
	 * @return string The query.
	 */
	public function make_tables_temporary( string $query ): string {

		$query = trim( $query );

		if ( str_starts_with( $query, 'CREATE TABLE' ) ) {

			if ( preg_match( '/^CREATE TABLE\s+(?:IF NOT EXISTS\s+)?`?([\w$]+)`?/i', $query, $matches ) ) {
				$this->temporary_tables[] = $matches[1];
			}

			return 'CREATE TEMPORARY TABLE' . substr( $query, strlen( 'CREATE TABLE' ) );
		}

		if ( str_starts_with( $query, 'DROP TABLE' ) ) {
			return 'DROP TEMPORARY TABLE' . substr( $query, strlen( 'DROP TABLE' ) );
		}

		return $query;
	}

	/**
	 * The test library's factory for creating users, posts, etc.
	 *
	 * @return WP_UnitTest_Factory The factory.
	 */
	protected static function factory(): WP_UnitTest_Factory {

		if ( null === self::$factory ) {
			self::$factory = new WP_UnitTest_Factory();
		}

		return self::$factory;
	}

	/**
	 * The `wp_die_handler` filter: make wp_die() throw an exception (with the response code) instead of exiting.
	 *
	 * @return callable The handler.
	 */
	public function get_wp_die_handler(): callable {
		return function ( $message, $title = '', $args = array() ) {

			$code = is_array( $args ) ? intval( $args['response'] ?? 0 ) : intval( $args );

			throw new WPDieException( is_string( $message ) ? $message : wp_json_encode( $message ), $code ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Test-only exception, never output.
		};
	}

	/**
	 * Save WordPress's hook globals.
	 *
	 * @return void
	 */
	private function save_hooks(): void {

		foreach ( array( 'wp_actions', 'wp_filters', 'wp_current_filter' ) as $key ) {
			$this->saved_hooks[ $key ] = $GLOBALS[ $key ] ?? array();
		}

		$this->saved_hooks['wp_filter'] = array();

		foreach ( $GLOBALS['wp_filter'] as $hook_name => $hook ) {
			$this->saved_hooks['wp_filter'][ $hook_name ] = clone $hook;
		}
	}

	/**
	 * Restore WordPress's hook globals.
	 *
	 * @return void
	 */
	private function restore_hooks(): void {
		foreach ( $this->saved_hooks as $key => $value ) {
			$GLOBALS[ $key ] = $value; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Restoring WordPress's hooks after a test.
		}
	}

	/**
	 * Reset the plugin's static (per-request) caches, as if each test were a new request.
	 *
	 * @return void
	 */
	public static function reset_plugin_state(): void {

		self::set_static( Credentials::class, 'publishers_list_cache', null );
		self::set_static( Credentials::class, 'publishers_list_failed', false );
		self::set_static( Credentials::class, 'categories_list_cache', array() );
		self::set_static( Credentials::class, 'has_valid_api_token', false );
		self::set_static( Credentials::class, 'api_token_source', 'undefined' );
		self::set_static( Credentials::class, 'publisher_links_rebuild_batch_size', 100 );

		self::set_static( Endpoint::class, 'api_call_count', 0 );
		self::set_static( Endpoint::class, 'last_response', null );
		self::set_static( Endpoint::class, 'front_end_seconds_spent', 0.0 );

		self::set_static( GistSite::class, 'cached_sites', array() );
		self::set_static( GistSite::class, 'cached_site_statuses', null );

		self::set_static( FrontendMain::class, 'chat_widget_js_enqueued', array() );
		self::set_static( FrontendMain::class, 'search_widget_js_enqueued', array() );

		self::set_static( ToolsOptions::class, 'options_loaded', false );
	}

	/**
	 * Set a (possibly private) static property.
	 *
	 * @param string $class_name The class name.
	 * @param string $property   The property name.
	 * @param mixed  $value      The value.
	 *
	 * @return void
	 */
	public static function set_static( string $class_name, string $property, mixed $value ): void {
		( new ReflectionClass( $class_name ) )->getProperty( $property )->setValue( null, $value );
	}

	/**
	 * Get a (possibly private) static property.
	 *
	 * @param string $class_name The class name.
	 * @param string $property   The property name.
	 *
	 * @return mixed The value.
	 */
	public static function get_static( string $class_name, string $property ): mixed {
		return ( new ReflectionClass( $class_name ) )->getProperty( $property )->getValue();
	}

	/**
	 * Call a (possibly private) static method.
	 *
	 * @param string $class_name The class name.
	 * @param string $method     The method name.
	 * @param mixed  ...$args    The arguments.
	 *
	 * @return mixed The return value.
	 */
	public static function call_static( string $class_name, string $method, mixed ...$args ): mixed {
		return ( new ReflectionClass( $class_name ) )->getMethod( $method )->invoke( null, ...$args );
	}

	/**
	 * Call a (possibly private) method of an object.
	 *
	 * @param object $instance The object.
	 * @param string $method   The method name.
	 * @param mixed  ...$args  The arguments.
	 *
	 * @return mixed The return value.
	 */
	public static function call_method( object $instance, string $method, mixed ...$args ): mixed {
		return ( new ReflectionClass( $instance ) )->getMethod( $method )->invoke( $instance, ...$args );
	}

	/**
	 * Store an API token, and mark it as valid (as a successful token check would).
	 *
	 * @param string $token Optional API token. Defaults to TOKEN.
	 *
	 * @return void
	 */
	protected function connect( string $token = self::TOKEN ): void {

		Credentials::store_api_token( $token );

		if ( is_multisite() ) {
			set_site_transient( 'gist_answers_api_token_is_valid', true, HOUR_IN_SECONDS );
		} else {
			set_transient( 'gist_answers_api_token_is_valid', true, HOUR_IN_SECONDS );
		}

		self::set_static( Credentials::class, 'has_valid_api_token', false );
	}

	/**
	 * Link a site to a publisher (the API's publishers list is mocked to contain it).
	 *
	 * @param array<mixed> $publisher The publisher (see MockGistApi::publisher()).
	 * @param int          $blog_id   Optional ID of the blog/site. Defaults to the current site.
	 *
	 * @return object The stored publisher data.
	 */
	protected function link_publisher( array $publisher, int $blog_id = 0 ): object {

		MockGistApi::set_publishers( array( $publisher ) );

		Credentials::clear_publishers_list_cache();

		$data = Credentials::update_publisher( $blog_id, $publisher['id'] );

		GistSite::forget( $blog_id );

		return $data;
	}

	/**
	 * Create a user with the given role on the current site, and make them the current user.
	 *
	 * @param string $role Optional role. Defaults to `administrator`.
	 *
	 * @return int The user ID.
	 */
	protected function log_in_as( string $role = 'administrator' ): int {

		$user_id = self::factory()->user->create( array( 'role' => $role ) );

		wp_set_current_user( $user_id );

		return $user_id;
	}

	/**
	 * Create a super admin (on multisite; an administrator otherwise), and make them the current user.
	 *
	 * @return int The user ID.
	 */
	protected function log_in_as_super_admin(): int {

		$user_id = $this->log_in_as( 'administrator' );

		if ( is_multisite() ) {

			grant_super_admin( $user_id );

			// Set the user again, so that capability-dependent setup (e.g. HTML filtering) sees the super admin.
			wp_set_current_user( 0 );
			wp_set_current_user( $user_id );
		}

		return $user_id;
	}

	/**
	 * Make a request to one of the plugin's REST API routes.
	 *
	 * @param string       $method The HTTP method.
	 * @param string       $route  The route, relative to the plugin's namespace (e.g., `admin/site-statuses`).
	 * @param array<mixed> $params Optional request parameters.
	 *
	 * @return WP_REST_Response The response.
	 */
	protected function rest( string $method, string $route, array $params = array() ): WP_REST_Response {

		$request = new WP_REST_Request( $method, '/gist-answers/v1/' . $route );

		foreach ( $params as $key => $value ) {
			$request->set_param( $key, $value );
		}

		return rest_get_server()->dispatch( $request );
	}

	/**
	 * Run an admin-post handler as a form submission, with a valid nonce.
	 *
	 * @param callable     $handler      The handler.
	 * @param string       $nonce_action The nonce action.
	 * @param string       $nonce_field  The nonce field name.
	 * @param array<mixed> $post         Optional POST data.
	 *
	 * @return string `redirect:<URL>` if the handler redirected, `die:<status>` if it died, or `returned`.
	 */
	protected function admin_post( callable $handler, string $nonce_action, string $nonce_field, array $post = array() ): string {

		$_POST    = array_merge( $post, array( $nonce_field => wp_create_nonce( $nonce_action ) ) );
		$_REQUEST = $_POST; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Simulating the request the handler under test reads.

		add_filter(
			'wp_redirect',
			function ( $location ) { // phpcs:ignore WordPressVIPMinimum.Hooks.AlwaysReturnInFilter.TerminatingInsteadOfReturn -- Throwing stops the handler at its redirect, before the `exit` that follows it, which would end the test run.
				throw new RedirectException( esc_url_raw( $location ) );
			},
			PHP_INT_MAX
		);

		try {
			$handler();
			return 'returned';
		} catch ( RedirectException $e ) {
			return 'redirect:' . $e->getMessage();
		} catch ( WPDieException $e ) {
			return 'die:' . ( $e->getCode() ? $e->getCode() : 'error' );
		}
	}

	/**
	 * Set a network-wide plugin option (a site option on multisite, a regular option otherwise), and make the plugin
	 * reload its developer options.
	 *
	 * @param string $name  The option name.
	 * @param mixed  $value The value.
	 *
	 * @return void
	 */
	protected function set_network_option( string $name, mixed $value ): void {

		if ( is_multisite() ) {
			update_site_option( $name, $value );
		} else {
			update_option( $name, $value );
		}

		self::set_static( ToolsOptions::class, 'options_loaded', false );
	}

	/**
	 * Skip the test unless WordPress is running as a multisite network.
	 *
	 * @return void
	 */
	protected function require_multisite(): void {
		if ( ! is_multisite() ) {
			$this->markTestSkipped( 'Requires multisite (run with WP_MULTISITE=1).' );
		}
	}

	/**
	 * Skip the test unless WordPress is running as a single site.
	 *
	 * @return void
	 */
	protected function require_single_site(): void {
		if ( is_multisite() ) {
			$this->markTestSkipped( 'Requires a single-site install.' );
		}
	}
}
