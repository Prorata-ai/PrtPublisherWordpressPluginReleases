<?php
/**
 * Exception thrown in place of a redirect in the PHPUnit suite.
 *
 * @package GistAnswers
 */

namespace GistAnswers\Tests;

use RuntimeException;

/**
 * Thrown in place of a redirect, so that handlers that redirect and exit can be tested.
 */
final class RedirectException extends RuntimeException {
}
