<?php
/**
 * A mock of the Gist Answers API for the PHPUnit suite.
 *
 * @package GistAnswers
 */

namespace GistAnswers\Tests;

use GistAnswers\Plugin\GistURLs;
use WP_Error;

/**
 * A mock of the Gist Answers API for the PHPUnit suite.
 *
 * Installed through the `pre_http_request` filter, it answers the plugin's requests to the API with canned responses
 * (which tests can override per route), records every request, and blocks any other outbound HTTP request so that
 * no test depends on the network.
 */
final class MockGistApi {

	/**
	 * Routes, most recently added first: each with `method`, `pattern`, and `respond` (a callable or a response).
	 *
	 * @var array<array<mixed>>
	 */
	private static array $routes = array();

	/**
	 * The publishers the API's publishers list returns (see set_publishers()), which can also be fetched by ID.
	 *
	 * @var array<array<mixed>>
	 */
	private static array $publishers = array();

	/**
	 * Every request made to the API since the last reset, oldest first.
	 *
	 * @var array<object>
	 */
	public static array $requests = array();

	/**
	 * Install the mock (for the current test; WordPress restores the hooks after each one) and reset it.
	 *
	 * @return void
	 */
	public static function install(): void {

		self::reset();

		add_filter( 'pre_http_request', array( self::class, 'handle' ), 10, 3 );
	}

	/**
	 * Reset the routes to the defaults, and forget the recorded requests.
	 *
	 * @return void
	 */
	public static function reset(): void {

		self::$routes     = array();
		self::$requests   = array();
		self::$publishers = array();

		self::on( '*', '.*', 404, array( 'error' => 'No mock response for this request' ) );

		self::on( 'GET', 'publisher_groups', 200, self::publisher_group() );
		self::on( 'GET', 'publisher_groups/[^/]+', 200, self::publisher_group() );
		self::on(
			'GET',
			'publisher_groups/[^/]+/messages',
			200,
			array(
				'errors'   => array(),
				'messages' => array(),
			)
		);
		self::on( 'GET', 'publishers', 200, array( 'publishers' => array() ) );
		self::on( 'GET', 'publishers/[^/]+', array( self::class, 'respond_with_publisher' ) );
		self::on( 'GET', 'publishers/[^/]+/sites', 200, array() );
		self::on(
			'GET',
			'categories',
			200,
			array(
				array(
					'id'   => 'cat-news',
					'name' => 'News',
				),
			)
		);
		self::on( 'POST', 'embed', 200, array( 'ticket' => self::embed_ticket( 'mock-embed-uuid' ) ) );
		self::on( 'POST', 'publishers', 200, array( 'publisher' => array( 'id' => 'pub-created' ) ) );
		self::on( 'POST', 'publishers/[^/]+/ingest', 200, array( 'ok' => true ) );
		self::on( 'POST', 'publishers/[^/]+/widgets/chat', 200, array( 'published' => array( 'ok' => true ) ) );
		self::on( 'PUT', 'publishers/[^/]+/crawl', 200, array( 'ok' => true ) );
		self::on( 'DELETE', 'publishers/[^/]+/crawl', 200, array( 'ok' => true ) );
		self::on(
			'GET',
			'publishers/[^/]+/widgets/[^/]+/html',
			200,
			array(
				'header_snippet' => '<script type="module" src="' . GistURLs::get_widget_script_origin() . '/widget.js"></script>', // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- A mock API response, not a script output by the plugin.
				'body_snippet'   => '<div class="gist-widget-mock"></div>',
			)
		);
	}

	/**
	 * Respond to requests matching the given method and path pattern (taking precedence over earlier routes).
	 *
	 * @param string       $method  The HTTP method, or `*` for any.
	 * @param string       $pattern A regular expression (without delimiters or anchors) matching the path below
	 *                              the API base URL, e.g. `publishers/[^/]+/sites`.
	 * @param int|callable $code    The response status code, or a callable that receives the request (an object
	 *                              with `method`, `path`, `query`, `body`, `headers`, `timeout`, and `args`) and
	 *                              returns an array of the status code and body (and, optionally, the response
	 *                              headers).
	 * @param mixed        $body    The response body (encoded as JSON unless it is a string).
	 *
	 * @return void
	 */
	public static function on( string $method, string $pattern, int|callable $code, mixed $body = null ): void {
		array_unshift(
			self::$routes,
			array(
				'method'  => strtoupper( $method ),
				'pattern' => '#^' . $pattern . '$#',
				'respond' => is_callable( $code ) ? $code : fn () => array( $code, $body ),
			)
		);
	}

	/**
	 * Make requests matching the given method and path pattern fail as if the API couldn't be reached.
	 *
	 * @param string $method  The HTTP method, or `*` for any.
	 * @param string $pattern The path pattern (see on()).
	 *
	 * @return void
	 */
	public static function unreachable( string $method, string $pattern ): void {
		self::on( $method, $pattern, fn () => array( 0, new WP_Error( 'http_request_failed', 'cURL error 28: Connection timed out' ) ) );
	}

	/**
	 * Get the recorded requests matching the given method and path pattern.
	 *
	 * @param string $method  The HTTP method, or `*` for any.
	 * @param string $pattern The path pattern (see on()).
	 *
	 * @return array<object> The matching requests, oldest first.
	 */
	public static function requests( string $method = '*', string $pattern = '.*' ): array {
		return array_values(
			array_filter(
				self::$requests,
				fn ( $request ) => ( '*' === $method || strtoupper( $method ) === $request->method ) && preg_match( '#^' . $pattern . '$#', $request->path )
			)
		);
	}

	/**
	 * The `pre_http_request` filter: answer requests to the API, and block any other outbound request.
	 *
	 * @param mixed  $preempt Whether to preempt the request (returned if no route matches).
	 * @param array  $args    The request arguments.
	 * @param string $url     The request URL.
	 *
	 * @return mixed The mocked response, an error for a blocked request, or `$preempt`.
	 */
	public static function handle( mixed $preempt, array $args, string $url ): mixed {

		$base = trailingslashit( GistURLs::get_api_base_url() );

		// Every other request is blocked, including loopback requests: the test install's domain (example.org) is a
		// real host on the internet, so letting them through would make tests depend on the network.
		if ( ! str_starts_with( $url, $base ) ) {
			return new WP_Error( 'http_request_blocked', 'Unexpected outbound request in the test suite: ' . $url );
		}

		$path  = substr( $url, strlen( $base ) );
		$query = array();

		if ( str_contains( $path, '?' ) ) {
			[ $path, $query_string ] = explode( '?', $path, 2 );
			parse_str( $query_string, $query );
		}

		$request = (object) array(
			'method'  => strtoupper( $args['method'] ?? 'GET' ),
			'path'    => rawurldecode( trim( $path, '/' ) ),
			'query'   => $query,
			'body'    => is_string( $args['body'] ?? null ) ? json_decode( $args['body'], true ) : null,
			'headers' => $args['headers'] ?? array(),
			'timeout' => $args['timeout'] ?? null,
			'args'    => $args,
		);

		self::$requests[] = $request;

		foreach ( self::$routes as $route ) {
			if ( ( '*' === $route['method'] || $route['method'] === $request->method ) && preg_match( $route['pattern'], $request->path ) ) {

				$result = ( $route['respond'] )( $request );

				[ $code, $body ] = $result;

				if ( $body instanceof WP_Error ) {
					return $body;
				}

				return array(
					'headers'  => $result[2] ?? array(),
					'body'     => is_string( $body ) ? $body : wp_json_encode( $body ),
					'response' => array(
						'code'    => $code,
						'message' => '',
					),
					'cookies'  => array(),
					'filename' => null,
				);
			}
		}

		return $preempt;
	}

	/**
	 * Build a publisher (website) as the API returns it.
	 *
	 * @param string $id        The publisher ID.
	 * @param string $name      The publisher name.
	 * @param string $domain    The publisher domain.
	 * @param array  $config    Optional additional config (e.g., `aliases`, `dev`, `home_page_url`, `widgets`).
	 * @param bool   $enabled   Optional. Whether the publisher is enabled. Defaults to true.
	 *
	 * @return array<mixed> The publisher.
	 */
	public static function publisher( string $id, string $name, string $domain, array $config = array(), bool $enabled = true ): array {
		return array(
			'id'          => $id,
			'name'        => $name,
			'description' => $name,
			'enabled'     => $enabled,
			'category_id' => 'cat-news',
			'config'      => array_merge( array( 'domain' => $domain ), $config ),
		);
	}

	/**
	 * Make the API's publishers list return the given publishers.
	 *
	 * @param array<array<mixed>> $publishers The publishers (see publisher()).
	 *
	 * @return void
	 */
	public static function set_publishers( array $publishers ): void {

		self::$publishers = $publishers;

		self::on( 'GET', 'publishers', 200, array( 'publishers' => $publishers ) );
	}

	/**
	 * Answer a request for a single publisher with one of those set with set_publishers(), or a 404.
	 *
	 * @param object $request The request (see on()).
	 *
	 * @return array<mixed> The status code and body.
	 */
	public static function respond_with_publisher( object $request ): array {

		$id = substr( $request->path, strlen( 'publishers/' ) );

		foreach ( self::$publishers as $publisher ) {
			if ( ( $publisher['id'] ?? null ) === $id ) {
				return array( 200, $publisher );
			}
		}

		return array( 404, array( 'error' => 'Publisher not found' ) );
	}

	/**
	 * Build a publisher group (account), as the API returns it.
	 *
	 * @return array<mixed> The publisher group.
	 */
	public static function publisher_group(): array {
		return array(
			'id'          => 'pg-test',
			'name'        => 'Test Partner',
			'description' => 'Test Partner',
		);
	}

	/**
	 * Build a CMS embed ticket (a JWT whose payload carries the given UUID).
	 *
	 * @param string $uuid The UUID.
	 *
	 * @return string The ticket.
	 */
	public static function embed_ticket( string $uuid ): string {

		$encode = fn ( $data ) => rtrim( strtr( base64_encode( wp_json_encode( $data ) ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Building a test JWT.

		return $encode( array( 'alg' => 'none' ) ) . '.' . $encode( array( 'uuid' => $uuid ) ) . '.signature';
	}
}
