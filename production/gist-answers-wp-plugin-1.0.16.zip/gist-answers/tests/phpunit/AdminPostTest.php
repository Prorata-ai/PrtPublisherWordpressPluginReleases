<?php
/**
 * Tests for the admin-post handlers: connecting, activating a site, developer options, and the Danger Zone.
 *
 * @package GistAnswers
 */

use GistAnswers\Admin\AdminMain;
use GistAnswers\Admin\MenuItems\ToolsOptions;
use GistAnswers\API\Credentials;
use GistAnswers\Model\GistSite;
use GistAnswers\Plugin\Utilities;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for the admin-post handlers: connecting, activating a site, developer options, and the Danger Zone.
 */
final class AdminPostTest extends TestCase {

	/**
	 * Submit the connect form.
	 *
	 * @param string $token The API token entered.
	 *
	 * @return string The outcome (see TestCase::admin_post()).
	 */
	private function submit_connect( string $token ): string {
		return $this->admin_post( array( new AdminMain(), 'handle_gist_answers_connect' ), 'gist_answers_connect', AdminMain::CONNECT_NONCE, array( 'gist_answers_api_token' => $token ) );
	}

	/**
	 * Submit the site activation form.
	 *
	 * @param array<mixed> $post The form fields.
	 *
	 * @return string The outcome (see TestCase::admin_post()).
	 */
	private function submit_activation( array $post ): string {
		return $this->admin_post( array( new AdminMain(), 'handle_gist_answers_site_activation' ), 'gist_answers_site_activation', AdminMain::SITE_ACTIVATION_NONCE, $post );
	}

	/**
	 * Submit the Danger Zone form.
	 *
	 * @param array<mixed> $post The form fields.
	 *
	 * @return string The outcome (see TestCase::admin_post()).
	 */
	private function submit_danger_zone( array $post ): string {
		return $this->admin_post( array( new AdminMain(), 'handle_gist_answers_save_danger_zone_options' ), 'gist_answers_save_danger_zone_options', AdminMain::SAVE_DANGER_ZONE_OPTIONS_NONCE, $post );
	}

	/**
	 * Tests that a valid token is stored, along with the account, and the admin is sent back connected.
	 *
	 * @return void
	 */
	public function testConnectingStoresAValidToken(): void {

		$this->log_in_as_super_admin();

		$outcome = $this->submit_connect( ' ' . self::TOKEN . ' ' );

		$this->assertStringStartsWith( 'redirect:', $outcome );
		$this->assertStringContainsString( 'connected=1', $outcome );
		$this->assertSame( self::TOKEN, Credentials::get_api_token() );
		$this->assertSame( 'pg-test', Credentials::get_publisher_group()->id ?? null );
	}

	/**
	 * Tests that a token the API rejects isn't stored.
	 *
	 * @return void
	 */
	public function testConnectingRejectsAnInvalidToken(): void {

		$this->log_in_as_super_admin();

		MockGistApi::on( 'GET', 'publisher_groups', 401, array( 'error' => 'Unauthorized' ) );

		$this->assertStringContainsString( 'connected=-1', $this->submit_connect( 'sk_wrong' ) );
		$this->assertSame( '', Credentials::get_api_token() );
	}

	/**
	 * Tests that only administrators (network administrators on multisite) can connect.
	 *
	 * @return void
	 */
	public function testConnectingRequiresTheNetworkCapability(): void {

		$this->log_in_as( is_multisite() ? 'administrator' : 'editor' );

		$this->assertSame( 'die:403', $this->submit_connect( self::TOKEN ) );
		$this->assertSame( '', Credentials::get_api_token() );
	}

	/**
	 * Tests that a submission without a valid nonce is rejected.
	 *
	 * @return void
	 */
	public function testConnectingRequiresANonce(): void {

		$this->log_in_as_super_admin();

		$_POST    = array( 'gist_answers_api_token' => self::TOKEN );
		$_REQUEST = $_POST; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Simulating the request the handler under test reads.

		try {
			( new AdminMain() )->handle_gist_answers_connect();
			$this->fail( 'The handler ran without a nonce.' );
		} catch ( WPDieException $e ) {
			$this->assertSame( '', Credentials::get_api_token() );
		}
	}

	/**
	 * Tests activating a site as a new website.
	 *
	 * @return void
	 */
	public function testActivatingANewWebsite(): void {

		$this->connect();
		$this->log_in_as_super_admin();

		MockGistApi::on( 'POST', 'publishers', 200, array( 'publisher' => array( 'id' => 'pub-new' ) ) );
		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-new', get_bloginfo( 'name' ), 'example.org' ) ) );

		$outcome = $this->submit_activation(
			array(
				'gist_answers_blog_id'         => get_current_blog_id(),
				'gist_answers_activation_mode' => 'new',
			)
		);

		$this->assertStringContainsString( 'activated=1', $outcome );

		$body = MockGistApi::requests( 'POST', 'publishers' )[0]->body;

		$this->assertSame( get_bloginfo( 'name' ), $body['publisher']['name'] );
		$this->assertSame( get_home_url(), $body['publisher']['config']['home_page_url'] );
		$this->assertStringEndsWith( '/wp/v2/posts', $body['site']['url'] );
		$this->assertSame( 'WPV2', $body['site']['type'] );

		$this->assertSame( 'pub-new', Credentials::get_publisher()->id ?? null, 'the new website is linked straight away' );
	}

	/**
	 * Tests that a failed activation stores the error and reports it.
	 *
	 * @return void
	 */
	public function testFailedActivationReportsTheError(): void {

		$this->connect();
		$this->log_in_as_super_admin();

		MockGistApi::on( 'POST', 'publishers', 400, array( 'error' => 'Domain already in use' ) );

		$outcome = $this->submit_activation(
			array(
				'gist_answers_blog_id'         => get_current_blog_id(),
				'gist_answers_activation_mode' => 'new',
			)
		);

		$this->assertStringContainsString( 'activated=-1', $outcome );
		$this->assertStringContainsString( 'Domain already in use', wp_json_encode( GistSite::get_site_activation_errors() ) );
	}

	/**
	 * Tests linking a site to an existing website.
	 *
	 * @return void
	 */
	public function testAssociatingWithAnExistingWebsite(): void {

		$this->connect();
		$this->log_in_as_super_admin();

		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-existing', 'Some Other Name', 'other.example' ) ) );

		$outcome = $this->submit_activation(
			array(
				'gist_answers_blog_id'         => get_current_blog_id(),
				'gist_answers_activation_mode' => 'associate',
				'gist_answers_publisher_id'    => 'pub-existing',
			)
		);

		$this->assertStringContainsString( 'activated=1', $outcome );
		$this->assertSame( 'pub-existing', Credentials::get_publisher()->id ?? null );
		$this->assertCount( 0, MockGistApi::requests( 'POST', 'publishers' ), 'no new website is created' );
	}

	/**
	 * Tests that a site can't be linked to a website the API doesn't list.
	 *
	 * @return void
	 */
	public function testAssociatingWithAnUnknownWebsiteFails(): void {

		$this->connect();
		$this->log_in_as_super_admin();

		$outcome = $this->submit_activation(
			array(
				'gist_answers_blog_id'         => get_current_blog_id(),
				'gist_answers_activation_mode' => 'associate',
				'gist_answers_publisher_id'    => 'pub-not-in-the-account',
			)
		);

		$this->assertStringContainsString( 'activated=-1', $outcome );
		$this->assertEmpty( (array) Credentials::get_publisher() );
	}

	/**
	 * Tests that a non-administrator can't activate a site.
	 *
	 * @return void
	 */
	public function testActivationRequiresAnAdministrator(): void {

		$this->connect();
		$this->log_in_as( 'editor' );

		$this->assertSame(
			'die:403',
			$this->submit_activation(
				array(
					'gist_answers_blog_id'         => get_current_blog_id(),
					'gist_answers_activation_mode' => 'new',
				)
			)
		);
		$this->assertCount( 0, MockGistApi::requests( 'POST', 'publishers' ) );
	}

	/**
	 * Tests that a subsite administrator can't activate another site in the network.
	 *
	 * @return void
	 */
	public function testSubsiteAdministratorCannotActivateAnotherSite(): void {

		$this->require_multisite();

		$this->connect();

		$site_a = self::factory()->blog->create( array( 'path' => '/site-a/' ) );
		$site_b = self::factory()->blog->create( array( 'path' => '/site-b/' ) );

		$user_id = self::factory()->user->create( array( 'role' => 'subscriber' ) );
		add_user_to_blog( $site_a, $user_id, 'administrator' );
		wp_set_current_user( $user_id );

		switch_to_blog( $site_a );

		$this->assertSame(
			'die:403',
			$this->submit_activation(
				array(
					'gist_answers_blog_id'         => $site_b,
					'gist_answers_activation_mode' => 'new',
				)
			)
		);
		$this->assertCount( 0, MockGistApi::requests( 'POST', 'publishers' ) );
	}

	/**
	 * Tests saving the developer options.
	 *
	 * @return void
	 */
	public function testDeveloperOptionsAreSaved(): void {

		$this->log_in_as_super_admin();

		$outcome = $this->admin_post(
			array( new AdminMain(), 'handle_gist_answers_save_developer_options' ),
			'gist_answers_save_developer_options',
			AdminMain::SAVE_DEVELOPER_OPTIONS_NONCE,
			array(
				'gist_answers_log_api_responses'  => 'on',
				'gist_answers_count_api_requests' => 'on',
			)
		);

		$this->assertStringStartsWith( 'redirect:', $outcome );

		self::set_static( ToolsOptions::class, 'options_loaded', false );

		$this->assertTrue( ToolsOptions::should_log_api_responses() );
		$this->assertTrue( ToolsOptions::should_count_api_requests() );
		$this->assertFalse( ToolsOptions::should_log_api_backtraces() );
		$this->assertFalse( ToolsOptions::should_simulate_api_server_error() );
	}

	/**
	 * Tests that only administrators (network administrators on multisite) can save developer options.
	 *
	 * @return void
	 */
	public function testDeveloperOptionsRequireTheNetworkCapability(): void {

		$this->log_in_as( is_multisite() ? 'administrator' : 'editor' );

		$outcome = $this->admin_post(
			array( new AdminMain(), 'handle_gist_answers_save_developer_options' ),
			'gist_answers_save_developer_options',
			AdminMain::SAVE_DEVELOPER_OPTIONS_NONCE,
			array( 'gist_answers_log_api_responses' => 'on' )
		);

		$this->assertSame( 'die:403', $outcome );
	}

	/**
	 * Tests the Danger Zone: deleting the token and options, and trashing only posts that really contain a widget.
	 *
	 * @return void
	 */
	public function testDangerZoneCleansUp(): void {

		$this->connect();
		$this->log_in_as_super_admin();

		update_option( 'gist_answers_some_setting', 'value' );
		set_transient( 'gist_answers_some_transient', 'value', HOUR_IN_SECONDS );

		$with_block     = self::factory()->post->create( array( 'post_content' => '<!-- wp:gist-answers/answer /-->' ) );
		$with_shortcode = self::factory()->post->create( array( 'post_content' => '[gist_answers_render_widget type="question" id="w"]' ) );
		$mentioning     = self::factory()->post->create( array( 'post_content' => '<p>Use the &lt;!-- wp:gist-answers/answer --&gt; block or [gist_answers_render_widget in code.</p>' ) );
		$unrelated      = self::factory()->post->create( array( 'post_content' => 'Nothing to see here.' ) );

		$outcome = $this->submit_danger_zone(
			array(
				'gist_answers_delete_api_key' => 'on',
				'gist_answers_delete_content' => 'on',
				'gist_answers_delete_options' => 'on',
			)
		);

		$this->assertStringStartsWith( 'redirect:', $outcome );
		$this->assertSame( '', Credentials::get_api_token() );
		$this->assertFalse( get_option( 'gist_answers_some_setting' ) );
		$this->assertFalse( get_transient( 'gist_answers_some_transient' ) );

		$this->assertSame( 'trash', get_post_status( $with_block ) );
		$this->assertSame( 'trash', get_post_status( $with_shortcode ) );
		$this->assertSame( 'publish', get_post_status( $mentioning ), 'a post that only mentions a widget is left alone' );
		$this->assertSame( 'publish', get_post_status( $unrelated ) );
	}

	/**
	 * Tests that the Danger Zone deletes the plugin's transients when they're kept in a persistent object cache (as on
	 * WordPress VIP) rather than the options table.
	 *
	 * @return void
	 */
	public function testDangerZoneDeletesTransientsFromTheObjectCache(): void {

		$this->connect();
		$this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				get_bloginfo( 'name' ),
				'example.org',
				array( 'widgets' => array( 'question-bar-widgets' => array( 'question-bar-widget-1' => array( 'name' => 'Home Page' ) ) ) )
			)
		);
		$this->log_in_as_super_admin();

		$was_using_ext_object_cache = wp_using_ext_object_cache( true );

		try {
			set_transient( 'gist_answers_widget_cache_question-bar-widget-1', (object) array( 'body_snippet' => 'cached' ), HOUR_IN_SECONDS );
			set_transient( 'gist_answers_publisher_lookup_attempted', true, HOUR_IN_SECONDS );

			if ( is_multisite() ) {
				set_site_transient( 'gist_answers_api_token_is_valid', true, HOUR_IN_SECONDS );
			} else {
				set_transient( 'gist_answers_api_token_is_valid', true, HOUR_IN_SECONDS );
			}

			$this->submit_danger_zone( array( 'gist_answers_delete_options' => 'on' ) );

			$this->assertFalse( get_transient( 'gist_answers_widget_cache_question-bar-widget-1' ), 'cached widget code' );
			$this->assertFalse( get_transient( 'gist_answers_publisher_lookup_attempted' ) );
			$this->assertFalse( is_multisite() ? get_site_transient( 'gist_answers_api_token_is_valid' ) : get_transient( 'gist_answers_api_token_is_valid' ), 'cached token check' );
		} finally {
			// Passing null would only read the setting, so it's restored as a boolean.
			wp_using_ext_object_cache( (bool) $was_using_ext_object_cache );
		}
	}

	/**
	 * Tests that the Danger Zone removes the plugin's sidebar widgets.
	 *
	 * @return void
	 */
	public function testDangerZoneRemovesSidebarWidgets(): void {

		$this->log_in_as_super_admin();

		update_option(
			'sidebars_widgets',
			array(
				'sidebar-1'           => array( 'gist_answers_question_widget-2', 'search-2' ),
				'array_version'       => 3,
				'wp_inactive_widgets' => array(),
			)
		);
		update_option( 'widget_gist_answers_question_widget', array( 2 => array( 'widget_id' => 'w' ) ) );

		$this->submit_danger_zone( array( 'gist_answers_delete_widgets' => 'on' ) );

		$this->assertSame( array( 'search-2' ), get_option( 'sidebars_widgets' )['sidebar-1'] );
		$this->assertFalse( get_option( 'widget_gist_answers_question_widget' ) );
	}

	/**
	 * Tests that only network administrators can use the Danger Zone.
	 *
	 * @return void
	 */
	public function testDangerZoneRequiresTheNetworkCapability(): void {

		$this->connect();
		$this->log_in_as( is_multisite() ? 'administrator' : 'editor' );

		$this->assertSame( 'die:403', $this->submit_danger_zone( array( 'gist_answers_delete_api_key' => 'on' ) ) );
		$this->assertSame( self::TOKEN, Credentials::get_api_token() );
	}

	/**
	 * Tests that the plugin folder can't be deleted in a development environment (such as this test suite).
	 *
	 * @return void
	 */
	public function testPluginFolderCannotBeDeletedInDevelopment(): void {

		$previous_http_host = $_SERVER['HTTP_HOST'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Saved as is, only to restore it afterwards.

		// A release copy has no dev-utilities.php (which turns on development mode), so there the local development
		// host stands in for it.
		if ( ! ( defined( 'GIST_ANSWERS_DEVELOPMENT_MODE' ) && GIST_ANSWERS_DEVELOPMENT_MODE ) ) {
			$_SERVER['HTTP_HOST'] = 'prorata.test';
		}

		try {
			// The deletion is only attempted once this passes, so a broken guard can't delete the plugin under test.
			$this->assertFalse( Utilities::can_delete_plugin_folder() );

			Utilities::delete_plugin_folder();

			$this->assertFileExists( GIST_ANSWERS_PLUGIN_DIR . 'gist-answers.php' );
		} finally {
			if ( null === $previous_http_host ) {
				unset( $_SERVER['HTTP_HOST'] );
			} else {
				$_SERVER['HTTP_HOST'] = $previous_http_host;
			}
		}
	}
}
