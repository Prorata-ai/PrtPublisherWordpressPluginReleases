<?php
/**
 * Class for testing the Gist Answers plugin utilities.
 *
 * @package GistAnswers
 */

use GistAnswers\Admin\MenuItems;
use GistAnswers\Plugin\Utilities;

use PHPUnit\Framework\TestCase;

/**
 * Class for testing the Gist Answers plugin utilities.
 */
final class UtilitiesTest extends TestCase {

	private const NOT_FOUND_TOKEN = '__GIST_ANSWERS_TRANSLATION_NOT_FOUND__';

	/**
	 * Tests that class names are extracted properly.
	 *
	 * @return void
	 */
	public function testClassNamesExtractProperly(): void {

		[$display_name, $slug] = Utilities::extract_class_name_details( 'GistAnswers\\Plugin\\SomeClassName' );

		$this->assertEquals( 'Some Class Name', $display_name );
		$this->assertEquals( 'some-class-name', $slug );
	}

	/**
	 * Tests that class names are translated properly.
	 *
	 * @return void
	 */
	public function testClassNamesTranslateProperly(): void {

		$menu_items = MenuItems::get_all();

		foreach ( $menu_items as $menu_item ) {
			switch ( $menu_item->type ) {
				case 'menu_subitem':
					$class_name = $menu_item->class_name ?? '';

					$translated_class_name = MenuItems::translate_class_display_name( $class_name, self::NOT_FOUND_TOKEN );

					// Handle one exception.
					$translated_class_name = str_replace( 'Tools & Options', 'Tools Options', $translated_class_name );

					$this->assertEquals( $class_name, $translated_class_name );
			}
		}

		$translation_not_available = MenuItems::translate_class_display_name( 'Some Class Name', self::NOT_FOUND_TOKEN );

		$this->assertEquals( self::NOT_FOUND_TOKEN, $translation_not_available );
	}

	/**
	 * Tests that divider heading names are extracted properly.
	 *
	 * @return void
	 */
	public function testDividerHeadingNamesExtractProperly(): void {

		[$display_name, $slug] = Utilities::extract_divider_heading_name_details( 'Some Divider Heading' );

		$this->assertEquals( 'Some Divider Heading', $display_name );
		$this->assertEquals( 'some-divider-heading', $slug );
	}

	/**
	 * Tests that divider heading names are translated properly.
	 *
	 * @return void
	 */
	public function testDividerHeadingNamesTranslateProperly(): void {

		$menu_items = MenuItems::get_all();

		foreach ( $menu_items as $menu_item ) {
			switch ( $menu_item->type ) {
				case 'divider_heading':
					$divider_heading_name = $menu_item->name ?? '';

					$translated_divider_heading_name = MenuItems::translate_divider_heading_display_name( $divider_heading_name, self::NOT_FOUND_TOKEN );

					$this->assertEquals( $divider_heading_name, $translated_divider_heading_name );
			}
		}

		$translation_not_available = MenuItems::translate_divider_heading_display_name( 'Some Divider Heading', self::NOT_FOUND_TOKEN );

		$this->assertEquals( self::NOT_FOUND_TOKEN, $translation_not_available );
	}

	/**
	 * Tests that a page slug can be extracted from a complex URL.
	 *
	 * @return void
	 */
	public function testCanExtractPageSlugFromUrl(): void {

		$url = 'https://example.com/some/page/slug/?query=string&another=query#fragment';

		$page_slug = Utilities::get_page_slug_from_url( $url );

		$this->assertEquals( 'some/page/slug', $page_slug );
	}

	/**
	 * Tests that a post ID can be extracted from a page slug.
	 *
	 * @return void
	 */
	public function testCanExtractPostIdFromPageSlug(): void {

		$parent_id = wp_insert_post(
			array(
				'post_title'  => 'Gist Answers Test Parent',
				'post_name'   => 'gist-answers-test-parent',
				'post_status' => 'publish',
				'post_type'   => 'page',
			),
		);

		$child_id = wp_insert_post(
			array(
				'post_title'  => 'Gist Answers Test Child',
				'post_name'   => 'gist-answers-test-child',
				'post_status' => 'publish',
				'post_type'   => 'page',
				'post_parent' => $parent_id,
			),
		);

		$this->assertGreaterThan( 0, $parent_id );
		$this->assertGreaterThan( 0, $child_id );

		$this->assertSame( $parent_id, Utilities::get_post_id_from_page_slug( 'gist-answers-test-parent' ) );
		$this->assertSame( $child_id, Utilities::get_post_id_from_page_slug( 'gist-answers-test-parent/gist-answers-test-child' ) );
		$this->assertSame( 0, Utilities::get_post_id_from_page_slug( 'gist-answers-no-such-page' ) );
	}

	/**
	 * Tests that domains are normalized for comparison.
	 *
	 * @return void
	 */
	public function testDomainsNormalizeProperly(): void {

		$this->assertSame( 'example.com', Utilities::normalize_domain( 'https://www.Example.com/' ) );
		$this->assertSame( 'example.com/blog', Utilities::normalize_domain( 'http://example.com:8080/blog/?x=1#top' ) );
		$this->assertSame( 'example.com', Utilities::normalize_domain( 'example.com' ) );
		$this->assertSame( '', Utilities::normalize_domain( '' ) );

		$this->assertTrue( Utilities::do_domains_match( 'https://www.example.com/', 'example.com' ) );
		$this->assertFalse( Utilities::do_domains_match( 'https://example.com/site2', 'example.com' ) );
		$this->assertFalse( Utilities::do_domains_match( '', '' ) );
	}

	/**
	 * Tests that pre-production domains are detected, without matching the words inside other words, or a word that is
	 * (or starts) the domain's own name.
	 *
	 * @return void
	 */
	public function testPreproductionDomainsAreDetected(): void {

		foreach ( array( 'staging.example.com', 'example-staging.com', 'test.example.co.uk', 'staging.example.co.uk', 'preproduction.example.com', 'example-engineering.com', 'testing.example.com', 'dev.example.com', 'example-dev.com', 'example.com/dev', 'dev2.example.com', 'staging.testing.com', 'kitchen-test.com' ) as $domain ) {
			$this->assertTrue( Utilities::is_preproduction_domain( $domain ), $domain );
		}

		foreach ( array( 'example.com', 'contest.com', 'latest-news.com', 'example.dev', 'developer.example.com', 'blog.developer.com', 'news.devonlive.com', 'example.devops.com', 'testing.com', 'dev.to', 'engineering.com', 'www.engineering.com', 'test-kitchen.com', 'engineering-example.com', 'testing.co.uk', 'blog.test.com' ) as $domain ) {
			$this->assertFalse( Utilities::is_preproduction_domain( $domain ), $domain );
		}
	}

	/**
	 * Tests that pre-production domains share their production domain's match key.
	 *
	 * @return void
	 */
	public function testProductionMatchKeysIgnorePreproductionWords(): void {

		$key = Utilities::get_production_match_key( 'https://www.example.com/' );

		foreach ( array( 'staging.example.com', 'example-staging.com', 'dev.example.com', 'example.com/dev' ) as $domain ) {
			$this->assertSame( $key, Utilities::get_production_match_key( $domain ), $domain );
		}

		$this->assertNotSame( $key, Utilities::get_production_match_key( 'staging.other-example.com' ) );

		$this->assertNotSame( Utilities::get_production_match_key( 'kitchen.com' ), Utilities::get_production_match_key( 'test-kitchen.com' ), 'a word starting the name is part of it' );
		$this->assertNotSame( 'com', Utilities::get_production_match_key( 'testing.com' ), 'a word that is the whole name is kept' );
		$this->assertSame( Utilities::get_production_match_key( 'example.co.uk' ), Utilities::get_production_match_key( 'staging.example.co.uk' ) );
	}

	/**
	 * Tests that name match scores ignore case and non-alphanumeric characters.
	 *
	 * @return void
	 */
	public function testNameMatchScoresIgnoreCaseAndPunctuation(): void {

		$this->assertSame( 100, Utilities::get_name_match_score( 'The Daily Post', 'the-daily_post!' ) );
		$this->assertSame( 100, Utilities::get_name_match_score( 'Joe&#8217;s Blog', 'Joes Blog' ) );
		$this->assertSame( 0, Utilities::get_name_match_score( '', 'Anything' ) );
		$this->assertSame( 0, Utilities::get_name_match_score( '!!!', 'Anything' ) );
	}

	/**
	 * Tests that near-matching names score below 100, and closer names score higher.
	 *
	 * @return void
	 */
	public function testNameMatchScoresRankNearMatches(): void {

		$close   = Utilities::get_name_match_score( 'The Daily Post', 'The Daily Posts' );
		$distant = Utilities::get_name_match_score( 'The Daily Post', 'Weekly Gazette' );

		$this->assertLessThan( 100, $close );
		$this->assertGreaterThan( 70, $close );
		$this->assertLessThan( $close, $distant );
		$this->assertSame( $close, Utilities::get_name_match_score( 'The Daily Posts', 'The Daily Post' ) );
	}
}
