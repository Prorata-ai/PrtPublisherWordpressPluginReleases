<?php
/**
 * PHPUnit bootstrap file.
 *
 * Loads the WordPress test library from WP_TESTS_DIR, then loads the plugin as a
 * must-use plugin so the suite runs against a real WordPress install.
 *
 * @package GistAnswers
 */

namespace GistAnswers\Tests;

$gist_answers_tests_dir = getenv( 'WP_TESTS_DIR' );

if ( empty( $gist_answers_tests_dir ) ) {
	$gist_answers_tests_dir = rtrim( sys_get_temp_dir(), '/\\' ) . '/wordpress-tests-lib';
}

// Forward custom PHPUnit Polyfills configuration to the WordPress test bootstrap.
$gist_answers_polyfills_path = getenv( 'WP_TESTS_PHPUNIT_POLYFILLS_PATH' );

if ( false !== $gist_answers_polyfills_path ) {
	define( 'WP_TESTS_PHPUNIT_POLYFILLS_PATH', $gist_answers_polyfills_path );
}

if ( ! file_exists( "{$gist_answers_tests_dir}/includes/functions.php" ) ) {
	echo "Could not find {$gist_answers_tests_dir}/includes/functions.php. Set WP_TESTS_DIR to a WordPress test library checkout." . PHP_EOL; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CLI output.
	exit( 1 );
}

// Load the plugin's Composer dependencies, including yoast/phpunit-polyfills.
require_once __DIR__ . '/../../vendor/autoload.php';

// Give access to tests_add_filter().
require_once $gist_answers_tests_dir . '/includes/functions.php'; // phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable -- The WordPress test library location comes from WP_TESTS_DIR by convention.

tests_add_filter( 'doing_it_wrong_trigger_error', '__return_false' );
tests_add_filter( 'deprecated_function_trigger_error', '__return_false' );
tests_add_filter( 'deprecated_argument_trigger_error', '__return_false' );
tests_add_filter( 'deprecated_file_trigger_error', '__return_false' );
tests_add_filter( 'deprecated_hook_trigger_error', '__return_false' );

tests_add_filter(
	'muplugins_loaded',
	function () {
		require __DIR__ . '/../../gist-answers.php';

		// Under the CLI, the plugin loads its front-end side; also load the admin side, which registers the admin
		// hooks, admin-post handlers, and REST API routes under test.
		new \GistAnswers\Admin\AdminMain();
	}
);

// Start up the WordPress testing environment.
require $gist_answers_tests_dir . '/includes/bootstrap.php'; // phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable -- The WordPress test library location comes from WP_TESTS_DIR by convention.

// Test helpers (they extend the WordPress test library's classes, so they're loaded after it).
require_once __DIR__ . '/includes/RedirectException.php';
require_once __DIR__ . '/includes/MockGistApi.php';
require_once __DIR__ . '/includes/TestCase.php';
