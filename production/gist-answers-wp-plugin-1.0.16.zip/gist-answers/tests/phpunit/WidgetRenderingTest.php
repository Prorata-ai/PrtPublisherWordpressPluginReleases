<?php
/**
 * Tests for rendering Gist widgets: gist_answers_render_widget(), the shortcode, the blocks, and their diagnostics.
 *
 * @package GistAnswers
 */

use GistAnswers\API\Credentials;
use GistAnswers\Model\GistWidget;
use GistAnswers\Plugin\GistURLs;
use GistAnswers\Plugin\Utilities;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for rendering Gist widgets: gist_answers_render_widget(), the shortcode, the blocks, and their diagnostics.
 */
final class WidgetRenderingTest extends TestCase {

	private const QUESTION_WIDGET = 'question-bar-widget-1111-2222-3333-4444';
	private const ANSWER_WIDGET   = 'chat-widget-aaaa-bbbb-cccc-dddd';

	/**
	 * Set up a connected site with one question widget, and one answer widget for the `/answers` page.
	 *
	 * @return void
	 */
	protected function setUp(): void {

		parent::setUp();

		$this->connect();

		$this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				get_bloginfo( 'name' ),
				'example.org',
				array(
					'widgets' => array(
						'chat-widgets'         => array(
							self::ANSWER_WIDGET => array( 'targetUrl' => 'https://example.org/answers/' ),
						),
						'question-bar-widgets' => array(
							self::QUESTION_WIDGET => array(
								'name'       => 'Home Page',
								'answerPage' => array( 'chatWidgetId' => self::ANSWER_WIDGET ),
							),
						),
					),
				)
			)
		);

		MockGistApi::$requests = array();

		$this->set_current_page( '' );
	}

	/**
	 * Set the path of the page being rendered.
	 *
	 * @param string $path The path (e.g., `answers`).
	 *
	 * @return void
	 */
	private function set_current_page( string $path ): void {

		global $wp;

		$wp          = $wp ?? new WP(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Setting up the request for this test.
		$wp->request = $path;
	}

	/**
	 * Render a widget, returning the output.
	 *
	 * @param array<mixed> $args The arguments for gist_answers_render_widget().
	 *
	 * @return string The output.
	 */
	private function render( array $args ): string {
		return strval( gist_answers_render_widget( array_merge( $args, array( 'echo' => false ) ) ) );
	}

	/**
	 * Tests that a question widget renders its markup and enqueues its script.
	 *
	 * @return void
	 */
	public function testQuestionWidgetRenders(): void {

		$output = $this->render(
			array(
				'type' => 'question',
				'id'   => self::QUESTION_WIDGET,
			)
		);

		$this->assertSame( '<div class="gist-widget-mock"></div>', $output );
		$this->assertSame( array( GistURLs::get_widget_script_origin() . '/widget.js' ), self::get_static( GistAnswers\Frontend\FrontendMain::class, 'search_widget_js_enqueued' ) );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-own/widgets/' . self::QUESTION_WIDGET . '/html' ) );
	}

	/**
	 * Tests that the alternative names for each widget type work.
	 *
	 * @return void
	 */
	public function testWidgetTypeAliases(): void {

		foreach ( array( 'search', 'questions', 'QUESTION' ) as $type ) {
			$this->assertSame(
				'<div class="gist-widget-mock"></div>',
				$this->render(
					array(
						'type' => $type,
						'id'   => self::QUESTION_WIDGET,
					)
				),
				$type
			);
		}

		$this->set_current_page( 'answers' );

		foreach ( array( 'chat', 'answers' ) as $type ) {
			$this->assertSame(
				'<div class="gist-widget-mock"></div>',
				$this->render(
					array(
						'type' => $type,
						'id'   => self::ANSWER_WIDGET,
					)
				),
				$type
			);
		}
	}

	/**
	 * Tests that widget code is fetched once, then cached.
	 *
	 * @return void
	 */
	public function testWidgetCodeIsCached(): void {

		$args = array(
			'type' => 'question',
			'id'   => self::QUESTION_WIDGET,
		);

		$this->render( $args );

		self::reset_plugin_state();

		$this->render( $args );

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/.+/html' ) );

		$timeout = intval( get_option( '_transient_timeout_gist_answers_widget_cache_' . self::QUESTION_WIDGET ) );

		$this->assertGreaterThanOrEqual( time() + 4 * MINUTE_IN_SECONDS, $timeout, 'successful responses are cached for minutes' );
	}

	/**
	 * Tests that a failed widget code request renders nothing, and is only cached briefly.
	 *
	 * @return void
	 */
	public function testFailedWidgetCodeIsCachedBriefly(): void {

		MockGistApi::on( 'GET', 'publishers/.+/html', 500, array( 'error' => 'Internal error' ) );

		$output = $this->render(
			array(
				'type' => 'question',
				'id'   => self::QUESTION_WIDGET,
			)
		);

		$this->assertStringStartsWith( '<script>console.error(', $output );
		$this->assertStringContainsString( 'No widget HTML is available', $output );

		$timeout = intval( get_option( '_transient_timeout_gist_answers_widget_cache_' . self::QUESTION_WIDGET ) );

		$this->assertLessThanOrEqual( time() + MINUTE_IN_SECONDS, $timeout );

		self::reset_plugin_state();

		$this->render(
			array(
				'type' => 'question',
				'id'   => self::QUESTION_WIDGET,
			)
		);

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/.+/html' ), 'the failure is cached, so the API is not called again straight away' );
	}

	/**
	 * Tests that an error body returned with a success code isn't treated as widget code.
	 *
	 * @return void
	 */
	public function testErrorBodyIsNotWidgetCode(): void {

		MockGistApi::on( 'GET', 'publishers/.+/html', 200, array( 'error' => 'Widget not found' ) );

		$this->assertSame( array(), get_object_vars( GistWidget::get_widget_code( self::QUESTION_WIDGET ) ) );
	}

	/**
	 * Make the cached code for the question widget due for a refresh, as if WIDGET_CACHE_DURATION had passed.
	 *
	 * @return void
	 */
	private function expire_cached_widget_code(): void {

		$transient_name = GistWidget::get_cache_transient_name( self::QUESTION_WIDGET );

		$entry = get_transient( $transient_name );

		$this->assertIsObject( $entry );

		$entry->fresh_until = time() - 1;

		set_transient( $transient_name, $entry, DAY_IN_SECONDS );
	}

	/**
	 * Tests that malformed widget code from the API is neither cached as widget code nor rendered, and doesn't break
	 * the page (the reported `header_snippet` array case).
	 *
	 * @return void
	 */
	public function testMalformedWidgetCodeIsRejected(): void {

		$malformed = array(
			'header array'     => array(
				'header_snippet' => array( 'not', 'a', 'string' ),
				'body_snippet'   => '<div class="gist-widget-mock"></div>',
			),
			'body object'      => array(
				'header_snippet' => '',
				'body_snippet'   => array( 'html' => '<div></div>' ),
			),
			'missing body'     => array( 'header_snippet' => '' ),
			'oversized body'   => array( 'body_snippet' => str_repeat( 'x', 64 * KB_IN_BYTES + 1 ) ),
			'invalid JSON'     => '{"header_snippet": ',
			'list, not object' => array( 'a', 'b' ),
		);

		foreach ( $malformed as $case => $body ) {

			MockGistApi::on( 'GET', 'publishers/.+/html', 200, $body );

			self::reset_plugin_state();
			delete_transient( GistWidget::get_cache_transient_name( self::QUESTION_WIDGET ) );

			$output = $this->render(
				array(
					'type' => 'question',
					'id'   => self::QUESTION_WIDGET,
				)
			);

			$this->assertStringContainsString( 'No widget HTML is available', $output, $case );
			$this->assertSame( array(), get_object_vars( GistWidget::get_widget_code( self::QUESTION_WIDGET ) ), $case );
		}
	}

	/**
	 * Tests that a malformed or failed refresh keeps the last valid widget code, rather than replacing it.
	 *
	 * @return void
	 */
	public function testFailedRefreshKeepsTheLastValidWidgetCode(): void {

		$this->assertSame( '<div class="gist-widget-mock"></div>', GistWidget::get_widget_code( self::QUESTION_WIDGET )->body_snippet );

		$failures = array(
			'malformed'    => array( 200, array( 'header_snippet' => array() ) ),
			'server error' => array( 503, array( 'error' => 'Unavailable' ) ),
		);

		foreach ( $failures as $case => [ $code, $body ] ) {

			MockGistApi::on( 'GET', 'publishers/.+/html', $code, $body );

			$this->assertSame( '<div class="gist-widget-mock"></div>', GistWidget::refresh_widget_code( self::QUESTION_WIDGET )->body_snippet, $case );

			self::reset_plugin_state();

			$this->assertSame( '<div class="gist-widget-mock"></div>', GistWidget::get_widget_code( self::QUESTION_WIDGET )->body_snippet, $case );
		}
	}

	/**
	 * Tests that once the API rejects the request (the token was revoked, or the widget removed), the last valid
	 * widget code is no longer shown.
	 *
	 * @return void
	 */
	public function testRejectedRefreshDropsTheWidgetCode(): void {

		GistWidget::get_widget_code( self::QUESTION_WIDGET );

		MockGistApi::on( 'GET', 'publishers/.+/html', 401, array( 'error' => 'Unauthorized' ) );

		$this->assertSame( array(), get_object_vars( GistWidget::refresh_widget_code( self::QUESTION_WIDGET ) ) );
		$this->assertSame( array(), get_object_vars( GistWidget::get_widget_code( self::QUESTION_WIDGET ) ) );
	}

	/**
	 * Tests that once cached widget code is due for a refresh, it is still shown, without waiting on the API, and is
	 * refreshed by a WP-Cron event instead (only one of which is scheduled).
	 *
	 * @return void
	 */
	public function testExpiredWidgetCodeIsRefreshedInTheBackground(): void {

		$args = array(
			'type' => 'question',
			'id'   => self::QUESTION_WIDGET,
		);

		$this->render( $args );
		$this->expire_cached_widget_code();

		for ( $i = 0; $i < 3; $i++ ) {

			self::reset_plugin_state();

			$this->assertSame( '<div class="gist-widget-mock"></div>', $this->render( $args ) );
		}

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/.+/html' ), 'no page view waited on the API' );
		$this->assertNotFalse( wp_next_scheduled( GistWidget::WIDGET_REFRESH_CRON_HOOK, array( self::QUESTION_WIDGET ) ) );

		do_action( GistWidget::WIDGET_REFRESH_CRON_HOOK, self::QUESTION_WIDGET );

		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publishers/.+/html' ) );
		$this->assertGreaterThan( time(), get_transient( GistWidget::get_cache_transient_name( self::QUESTION_WIDGET ) )->fresh_until, 'fresh again' );

		do_action( GistWidget::WIDGET_REFRESH_CRON_HOOK, 'chat-widget-not-this-sites' );

		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publishers/.+/html' ), 'only the site\'s own widgets are refreshed' );
	}

	/**
	 * Tests that while another request is fetching a widget's code for the first time, the widget is left out rather
	 * than fetched again (the reported cold-cache stampede).
	 *
	 * @return void
	 */
	public function testConcurrentColdCacheRequestsDoNotCallTheApi(): void {

		$this->assertTrue( Utilities::acquire_lock( 'gist_answers_widget_refresh_' . self::QUESTION_WIDGET, 30 ), 'another request is fetching it' );

		$output = $this->render(
			array(
				'type' => 'question',
				'id'   => self::QUESTION_WIDGET,
			)
		);

		$this->assertStringNotContainsString( 'gist-widget-mock', $output );
		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publishers/.+/html' ) );
	}

	/**
	 * Tests that refreshing the publisher data schedules the code of widgets that aren't cached yet to be fetched in
	 * the background.
	 *
	 * @return void
	 */
	public function testNewWidgetsArePrewarmed(): void {

		GistWidget::get_widget_code( self::QUESTION_WIDGET );

		Credentials::refresh_publisher_data();

		$this->assertNotFalse( wp_next_scheduled( GistWidget::WIDGET_REFRESH_CRON_HOOK, array( self::ANSWER_WIDGET ) ) );
		$this->assertFalse( wp_next_scheduled( GistWidget::WIDGET_REFRESH_CRON_HOOK, array( self::QUESTION_WIDGET ) ), 'already cached' );
	}

	/**
	 * Tests that an unknown question widget ID renders only a console error.
	 *
	 * @return void
	 */
	public function testUnknownQuestionWidgetRendersAConsoleError(): void {

		$output = $this->render(
			array(
				'type' => 'question',
				'id'   => 'question-bar-widget-not-mine',
			)
		);

		$this->assertMatchesRegularExpression( '#^<script>console\.error\(".*"\)</script>$#', $output );
		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publishers/.+/html' ) );
	}

	/**
	 * Tests the errors for a missing or unknown widget type.
	 *
	 * @return void
	 */
	public function testInvalidTypeRendersAConsoleError(): void {

		$this->assertStringContainsString( 'A valid widget type was not provided', $this->render( array( 'type' => 'carousel' ) ) );
		$this->assertStringContainsString( 'A valid widget type was not provided', $this->render( array() ) );
	}

	/**
	 * Tests that an answer widget is found from its target page.
	 *
	 * @return void
	 */
	public function testAnswerWidgetIsFoundByTarget(): void {

		$this->set_current_page( 'answers' );

		$this->assertSame( '<div class="gist-widget-mock"></div>', $this->render( array( 'type' => 'answer' ) ) );
		$this->assertSame(
			'<div class="gist-widget-mock"></div>',
			$this->render(
				array(
					'type'   => 'answer',
					'target' => '/answers/',
				)
			)
		);
		$this->assertSame( array( GistURLs::get_widget_script_origin() . '/widget.js' ), self::get_static( GistAnswers\Frontend\FrontendMain::class, 'chat_widget_js_enqueued' ) );
	}

	/**
	 * Tests that an answer widget on a page it wasn't created for still renders, with a console warning.
	 *
	 * @return void
	 */
	public function testAnswerWidgetOnAnotherPageWarns(): void {

		$this->set_current_page( 'somewhere-else' );

		$output = $this->render(
			array(
				'type' => 'answer',
				'id'   => self::ANSWER_WIDGET,
			)
		);

		$this->assertStringStartsWith( '<div class="gist-widget-mock"></div>', $output );
		$this->assertStringContainsString( '<script>console.warn(', $output );
		$this->assertStringContainsString( 'does not match current page slug', $output );
	}

	/**
	 * Tests that an answer widget with no matching widget for the page renders a console error.
	 *
	 * @return void
	 */
	public function testAnswerWidgetWithNoMatchRendersAConsoleError(): void {

		$this->set_current_page( 'no-answer-page-here' );

		$output = $this->render( array( 'type' => 'answer' ) );

		$this->assertStringStartsWith( '<script>console.error(', $output );
		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publishers/.+/html' ) );
	}

	/**
	 * XSS payloads, in the attributes that reach the console diagnostics.
	 *
	 * @return array<array<mixed>> The payloads.
	 */
	public static function xssPayloads(): array {
		return array(
			'template literal substitution' => array( '${alert(document.domain)}' ),
			'template literal break-out'    => array( 'x`);alert(1);(`' ),
			'script break-out'              => array( '</script><script>alert(1)</script>' ),
			'quote break-out'               => array( '"); alert(1); ("' ),
		);
	}

	/**
	 * Tests that attribute values can't inject script through the console diagnostics.
	 *
	 * @param string $payload The payload.
	 *
	 * @return void
	 */
	#[\PHPUnit\Framework\Attributes\DataProvider( 'xssPayloads' )]
	public function testDiagnosticsCannotInjectScript( string $payload ): void {

		$outputs = array(
			$this->render(
				array(
					'type'   => 'answer',
					'target' => $payload,
				)
			),
			$this->render(
				array(
					'type' => 'question',
					'id'   => $payload . '-a-b-c',
				)
			),
			$this->render( array( 'type' => $payload ) ),
			do_shortcode( '[gist_answers_render_widget type="answer" target="' . esc_attr( $payload ) . '"]' ),
			render_block(
				array(
					'blockName'    => 'gist-answers/question',
					'attrs'        => array( 'widgetId' => $payload . '-a-b-c' ),
					'innerBlocks'  => array(),
					'innerHTML'    => '',
					'innerContent' => array(),
				)
			),
		);

		foreach ( $outputs as $output ) {

			$this->assertSame( 1, substr_count( $output, '<script>' ), $output );
			$this->assertSame( 1, substr_count( $output, '</script>' ), $output );
			$this->assertStringNotContainsString( '`', $output );
			$this->assertStringNotContainsString( '${', $output );

			preg_match( '#^<script>console\.(?:error|warn)\((.*)\)</script>$#s', $output, $matches );

			$this->assertNotEmpty( $matches, $output );
			$this->assertIsString( json_decode( $matches[1] ), 'the message is a single JSON string' );
		}
	}

	/**
	 * Tests that the widget markup from the API is filtered whether it's echoed or returned (as it is for the
	 * shortcode and the blocks), and that scripts are removed from it.
	 *
	 * @return void
	 */
	public function testWidgetMarkupIsFilteredWhetherEchoedOrReturned(): void {

		MockGistApi::on(
			'GET',
			'publishers/.+/html',
			200,
			array(
				'header_snippet' => '<script type="module" src="' . GistURLs::get_widget_script_origin() . '/w.js"></script>', // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- A mock API response, not a script output by the plugin.
				'body_snippet'   => '<gist-search-widget api-key="k" id="w"></gist-search-widget><img src="x" onerror="alert(1)"><script>alert(2)</script>', // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- A mock API response, not a script output by the plugin.
			)
		);

		ob_start();
		$returned = gist_answers_render_widget(
			array(
				'type' => 'question',
				'id'   => self::QUESTION_WIDGET,
			)
		);
		$echoed   = ob_get_clean();

		self::reset_plugin_state();

		$rendered = $this->render(
			array(
				'type' => 'question',
				'id'   => self::QUESTION_WIDGET,
			)
		);

		$this->assertNull( $returned );

		foreach ( array( $echoed, $rendered ) as $output ) {
			$this->assertStringContainsString( '<gist-search-widget api-key="k" id="w"></gist-search-widget>', $output );
			$this->assertStringNotContainsString( '<img', $output );
			$this->assertStringNotContainsString( '<script', $output );
		}
	}

	/**
	 * Tests that a widget whose script isn't loaded from an allowed origin isn't shown, and its script isn't enqueued.
	 *
	 * @return void
	 */
	public function testWidgetScriptMustComeFromAnAllowedOrigin(): void {

		$origin = GistURLs::get_widget_script_origin();
		$host   = wp_parse_url( $origin, PHP_URL_HOST );

		foreach ( array( 'https://evil.example/w.js', "http://$host/w.js", "https://$host.evil.example/w.js", "https://user@$host/w.js", "//$host/w.js" ) as $src ) {

			MockGistApi::on(
				'GET',
				'publishers/.+/html',
				200,
				array(
					'header_snippet' => '<script type="module" src="' . $src . '"></script>', // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- A mock API response, not a script output by the plugin.
					'body_snippet'   => '<div class="gist-widget-mock"></div>',
				)
			);

			self::reset_plugin_state();
			delete_transient( GistAnswers\Model\GistWidget::get_cache_transient_name( self::QUESTION_WIDGET ) );

			$output = $this->render(
				array(
					'type' => 'question',
					'id'   => self::QUESTION_WIDGET,
				)
			);

			$this->assertStringNotContainsString( 'gist-widget-mock', $output, $src );
			$this->assertSame( array(), self::get_static( GistAnswers\Frontend\FrontendMain::class, 'search_widget_js_enqueued' ), $src );
		}

		foreach ( array( "$origin/w.js", 'https://' . strtoupper( $host ) . '/w.js', "$origin/widgets/v2/w.js?ver=3" ) as $src ) {
			$this->assertSame( $src, GistAnswers\Frontend\FrontendMain::get_widget_script_src( '<script type="module" src="' . $src . '"></script>' ), $src ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Test input for the snippet parser.
		}

		add_filter( 'gist_answers_widget_script_origins', fn ( $origins ) => array_merge( $origins, array( 'http://localhost:8080/' ) ) );

		$this->assertSame( 'http://localhost:8080/w.js', GistAnswers\Frontend\FrontendMain::get_widget_script_src( '<script src="http://localhost:8080/w.js"></script>' ), 'the filter adds origins' ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Test input for the snippet parser.
		$this->assertSame( '', GistAnswers\Frontend\FrontendMain::get_widget_script_src( '<script src="http://localhost:8081/w.js"></script>' ), 'the port must match' ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Test input for the snippet parser.
	}

	/**
	 * Tests that only the Gist CDN for the plugin's own build environment is trusted: a production build rejects the
	 * staging and development CDNs, other ports, and paths that climb out of the CDN's folders.
	 *
	 * @return void
	 */
	public function testWidgetScriptOriginIsTheBuildEnvironmentsOnly(): void {

		$cdns = array( 'https://cdn.gist.ai', 'https://cdn.staging.gist.ai', 'https://cdn.development.gist.ai' );

		$accepted = array_filter( $cdns, fn ( $cdn ) => '' !== GistAnswers\Frontend\FrontendMain::get_widget_script_src( '<script src="' . $cdn . '/w.js"></script>' ) ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Test input for the snippet parser.

		$this->assertSame( array( GistURLs::get_widget_script_origin() ), array_values( $accepted ), 'only one environment\'s CDN is trusted' );

		// As in a production build.
		add_filter( 'gist_answers_widget_script_origins', fn () => array( 'https://cdn.gist.ai' ) );

		$rejected = array(
			'https://cdn.staging.gist.ai/w.js',
			'https://cdn.development.gist.ai/w.js',
			'https://cdn.gist.ai:8443/w.js',
			'https://cdn.gist.ai:443@evil.example/w.js',
			'https://cdn.gist.ai/../w.js',
			'https://cdn.gist.ai/a/%2e%2e/w.js',
			'https://cdn.gist.ai/a/..%2fw.js',
			'https://cdn.gist.ai/a\\..\\w.js',
			'https://cdn.gist.ai',
		);

		foreach ( $rejected as $src ) {
			$this->assertSame( '', GistAnswers\Frontend\FrontendMain::get_widget_script_src( '<script src="' . $src . '"></script>' ), $src ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Test input for the snippet parser.
		}

		$this->assertSame( 'https://cdn.gist.ai/w.js', GistAnswers\Frontend\FrontendMain::get_widget_script_src( '<script src="https://cdn.gist.ai/w.js"></script>' ) ); // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Test input for the snippet parser.
	}

	/**
	 * Tests the filters for the render arguments and the rendered HTML.
	 *
	 * @return void
	 */
	public function testRenderFilters(): void {

		add_filter(
			'gist_answers_render_widget',
			fn ( $args ) => array_merge( $args, array( 'id' => self::QUESTION_WIDGET ) )
		);

		add_filter( 'gist_answers_widget_html', fn ( $html ) => '<div class="filtered">' . $html . '</div><script>alert(1)</script>' );

		$this->assertSame( '<div class="filtered"><div class="gist-widget-mock"></div></div>alert(1)', $this->render( array( 'type' => 'question' ) ), 'the filtered HTML is filtered through wp_kses() too' );
	}

	/**
	 * Tests the shortcode: only its own attributes are used, and it always returns its output.
	 *
	 * @return void
	 */
	public function testShortcode(): void {

		$output = do_shortcode( '[gist_answers_render_widget type="question" id="' . self::QUESTION_WIDGET . '" theme="dark" data-x="1" debug echo="true"]' );

		$this->assertSame( '<div class="gist-widget-mock"></div>', $output );
	}

	/**
	 * Tests the question block, with and without a custom class.
	 *
	 * @return void
	 */
	public function testQuestionBlock(): void {

		$block = array(
			'blockName'    => 'gist-answers/question',
			'attrs'        => array( 'widgetId' => self::QUESTION_WIDGET ),
			'innerBlocks'  => array(),
			'innerHTML'    => '',
			'innerContent' => array(),
		);

		$this->assertSame( '<div class="gist-widget-mock"></div>', render_block( $block ) );

		$block['attrs']['className'] = 'my-class" onclick="x';

		$this->assertSame( '<div class="my-class&quot; onclick=&quot;x"><div class="gist-widget-mock"></div></div>', render_block( $block ), 'the class is escaped' );
	}

	/**
	 * Tests the answer block, which finds the widget for the current page when no widget is chosen.
	 *
	 * @return void
	 */
	public function testAnswerBlock(): void {

		$this->set_current_page( 'answers' );

		$output = render_block(
			array(
				'blockName'    => 'gist-answers/answer',
				'attrs'        => array(),
				'innerBlocks'  => array(),
				'innerHTML'    => '',
				'innerContent' => array(),
			)
		);

		$this->assertSame( '<div class="gist-widget-mock"></div>', $output );
	}

	/**
	 * Tests widget ID truncation for console messages.
	 *
	 * @return void
	 */
	public function testWidgetIdTruncation(): void {

		$this->assertSame( 'chat-widget-0e7c...aef8', GistWidget::truncate_widget_id( 'chat-widget-0e7c4e81-f37d-47dd-a7bf-1c89aaf1aef8' ) );
		$this->assertSame( '', GistWidget::truncate_widget_id( 'short-id' ) );
	}

	/**
	 * Tests the argument sanitizers.
	 *
	 * @return void
	 */
	public function testArgumentSanitizers(): void {

		$this->assertSame( 'question', GistWidget::sanitize_args_type( array( 'type' => ' Search ' ) ) );
		$this->assertSame( '', GistWidget::sanitize_args_type( array() ) );

		$this->assertSame( 'chat-widget-1', GistWidget::sanitize_args_id( array( 'id' => '<b>chat-widget-1</b>' ) ) );
		$this->assertSame( 'alert1', GistWidget::sanitize_args_id( array( 'id' => '${alert(1)}' ) ) );

		$this->assertSame( 'help/answers', GistWidget::sanitize_args_target( array( 'target' => '/Help/Answers/' ) ) );
		$this->assertSame( 'answersx', GistWidget::sanitize_args_target( array( 'target' => 'answers` ${x}' ) ), 'characters that can\'t be in a URL path are removed' );

		$this->assertTrue( GistWidget::sanitize_args_echo( array() ) );
		$this->assertFalse( GistWidget::sanitize_args_echo( array( 'echo' => '0' ) ) );

		$this->assertSame( array( 'a' => 1 ), GistWidget::sanitize_args( (object) array( 'a' => 1 ) ) );
		$this->assertSame( array(), GistWidget::sanitize_args( 'not an array' ) );
	}
}
