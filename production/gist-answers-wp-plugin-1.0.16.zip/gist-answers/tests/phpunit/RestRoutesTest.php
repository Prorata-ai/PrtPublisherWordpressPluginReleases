<?php
/**
 * Tests for the plugin's REST API routes: their permissions and behavior.
 *
 * @package GistAnswers
 */

use GistAnswers\Admin\AdminMain;
use GistAnswers\API\Credentials;
use GistAnswers\Plugin\Utilities;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for the plugin's REST API routes: their permissions and behavior.
 */
final class RestRoutesTest extends TestCase {

	/**
	 * The token hash the CMS iframe's embed ticket (with the mock UUID) produces.
	 *
	 * @return string The token hash.
	 */
	private static function valid_token_hash(): string {
		return Utilities::get_token_hash_from_embed_uuid( 'mock-embed-uuid' );
	}

	/**
	 * Connect, and link the current site to a publisher.
	 *
	 * @return void
	 */
	private function connect_and_link(): void {
		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), 'example.org' ) );
	}

	/**
	 * Every route, with parameters valid for the current site.
	 *
	 * @return array<array<mixed>> The routes (method, route, parameters).
	 */
	private static function every_route(): array {
		return array(
			array( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) ),
			array( 'GET', 'admin/publisher-matches', array( 'blog_id' => 0 ) ),
			array( 'GET', 'admin/iframe-url', array( 'which' => 'widgets-list' ) ),
			array( 'GET', 'admin/submenu-page-url', array( 'which' => 'Widgets' ) ),
			array(
				'POST',
				'admin/site-status/update',
				array(
					'publisher_id' => 'pub-own',
					'site_id'      => 'site-1',
					'checked'      => 'true',
				),
			),
			array(
				'POST',
				'admin/answer-page',
				array(
					'action'      => 'create',
					'target_url'  => home_url( '/answers' ),
					'embed_token' => 'mock-embed-uuid',
					'token_hash'  => self::valid_token_hash(),
				),
			),
		);
	}

	/**
	 * Tests that every route rejects users who aren't administrators, and logged-out requests.
	 *
	 * @return void
	 */
	public function testEveryRouteRequiresAnAdministrator(): void {

		$this->connect_and_link();

		foreach ( array( 0, 'editor', 'subscriber' ) as $role ) {

			if ( 0 === $role ) {
				wp_set_current_user( 0 );
			} else {
				$this->log_in_as( $role );
			}

			foreach ( self::every_route() as [ $method, $route, $params ] ) {
				$this->assertContains( $this->rest( $method, $route, $params )->get_status(), array( 401, 403 ), "$method $route as " . ( $role ? $role : 'a logged-out visitor' ) );
			}
		}
	}

	/**
	 * Tests the site statuses route for each crawl state.
	 *
	 * @return void
	 */
	public function testSiteStatuses(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$cases = array(
			array( 'delta', 'processing', 'delta', 'Ingestion active', true ),
			array( 'full', 'queued', 'full', 'Historical ingestion in progress', true ),
			array( 'delta', 'completed', 'pause', 'Ingestion paused', false ),
			array( 'none', 'processing', 'delta', 'Ingestion active', true ),
		);

		foreach ( $cases as [ $phase, $status, $type, $text, $active ] ) {

			MockGistApi::on(
				'GET',
				'publishers/pub-own/sites',
				200,
				array(
					array(
						'id'            => 'site-1',
						'ingest_status' => array(
							'crawl_phase'    => $phase,
							'crawler_status' => $status,
						),
					),
				)
			);

			self::reset_plugin_state();
			AdminMain::forget_recent_site_status( 'pub-own' );

			$response = $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) );
			$data     = $response->get_data()['data']['pub-own'];

			$this->assertSame( 200, $response->get_status() );
			$this->assertSame( $type, $data->type, "$phase/$status" );
			$this->assertSame( $text, $data->text, "$phase/$status" );
			$this->assertSame( $active, $data->active, "$phase/$status" );
			$this->assertSame( 'site-1', $data->site_id );
		}
	}

	/**
	 * Tests that a website with an error from the API still says whether any of its sites are being ingested.
	 *
	 * @return void
	 */
	public function testSiteStatusErrorsSayWhetherAnySiteIsActive(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		MockGistApi::on(
			'GET',
			'publisher_groups/[^/]+/messages',
			200,
			array(
				'errors'   => array(
					array(
						'publisher_id' => 'pub-own',
						'message'      => 'This feed is not accessible',
					),
				),
				'messages' => array(),
			)
		);

		$cases = array(
			'processing' => true,
			'completed'  => false,
		);

		foreach ( $cases as $second_status => $active ) {

			MockGistApi::on(
				'GET',
				'publishers/pub-own/sites',
				200,
				array(
					array(
						'id'            => 'site-1',
						'ingest_status' => array(
							'crawl_phase'    => 'delta',
							'crawler_status' => 'completed',
						),
					),
					array(
						'id'            => 'site-2',
						'ingest_status' => array(
							'crawl_phase'    => 'delta',
							'crawler_status' => $second_status,
						),
					),
				)
			);

			self::reset_plugin_state();
			AdminMain::forget_recent_site_status( 'pub-own' );

			$data = $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) )->get_data()['data']['pub-own'];

			$this->assertSame( 'error', $data->type );
			$this->assertSame( 'This feed is not accessible', $data->text );
			$this->assertSame( $active, $data->active, $second_status );
			$this->assertSame( array( 'site-1', 'site-2' ), $data->site_ids );
		}
	}

	/**
	 * Tests that a website's messages from the API are returned as plain text, with a separate error label.
	 *
	 * @return void
	 */
	public function testSiteStatusMessagesArePlainText(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		MockGistApi::on(
			'GET',
			'publisher_groups/[^/]+/messages',
			200,
			array(
				'errors'   => array(
					array(
						'publisher_id' => 'pub-own',
						'message'      => 'Crawl failed <img src=x onerror=alert(1)>',
					),
				),
				'messages' => array(),
			)
		);

		$data = $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) )->get_data()['data']['pub-own'];

		$this->assertSame( 'error', $data->type );
		$this->assertSame( 'Error', $data->label );
		$this->assertSame( 'Crawl failed', $data->text );
	}

	/**
	 * Tests that the site statuses route reports an API failure.
	 *
	 * @return void
	 */
	public function testSiteStatusesReportsApiFailures(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		MockGistApi::on( 'GET', 'publishers/pub-own/sites', 503, array( 'error' => 'Unavailable' ) );

		$response = $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) );

		$this->assertSame( 503, $response->get_status() );
		$this->assertSame( 'error', $response->get_data()['status'] );
	}

	/**
	 * Tests that a publisher listed many times is authorized and fetched once, that its status is reused briefly, and
	 * that starting or stopping its ingestion fetches it again.
	 *
	 * @return void
	 */
	public function testSiteStatusesFetchEachPublisherOnce(): void {

		$this->connect_and_link();
		$this->log_in_as( 'administrator' );

		MockGistApi::$requests = array();

		$response = $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array_fill( 0, 25, 'pub-own' ) ) );

		$this->assertSame( 200, $response->get_status() );
		$this->assertSame( array( 'pub-own' ), array_keys( $response->get_data()['data'] ) );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-own/sites' ) );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups/[^/]+/messages' ) );

		$this->assertSame( 200, $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) )->get_status() );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-own/sites' ), 'a repeated request reuses the status' );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups/[^/]+/messages' ) );

		$this->rest(
			'POST',
			'admin/site-status/update',
			array(
				'publisher_id' => 'pub-own',
				'site_id'      => 'site-1',
				'checked'      => 'true',
			)
		);
		$this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) );

		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publishers/pub-own/sites' ), 'fetched again once ingestion is started' );
	}

	/**
	 * Tests that a refresh fetches a publisher's status again, unless it was fetched in the last few seconds.
	 *
	 * @return void
	 */
	public function testSiteStatusesRefreshFetchesAgain(): void {

		$this->connect_and_link();
		$this->log_in_as( 'administrator' );

		MockGistApi::$requests = array();

		$this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-own/sites' ) );

		$this->rest(
			'GET',
			'admin/site-statuses',
			array(
				'publisher_ids' => array( 'pub-own' ),
				'refresh'       => '1',
			)
		);
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-own/sites' ), 'a refresh reuses a status fetched seconds ago' );

		// Make the status ten seconds old: still reused by a page load, but not by a refresh.
		$transient_name = 'gist_answers_site_status_' . md5( 'pub-own' );
		$cached         = is_multisite() ? get_site_transient( $transient_name ) : get_transient( $transient_name );

		$cached['fetched_at'] -= 10;

		if ( is_multisite() ) {
			set_site_transient( $transient_name, $cached, 30 );
		} else {
			set_transient( $transient_name, $cached, 30 );
		}

		MockGistApi::on(
			'GET',
			'publishers/pub-own/sites',
			200,
			array(
				array(
					'id'            => 'site-1',
					'ingest_status' => array(
						'crawl_phase'    => 'delta',
						'crawler_status' => 'completed',
					),
				),
			)
		);

		$this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-own' ) ) );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-own/sites' ), 'a page load reuses the status' );

		$response = $this->rest(
			'GET',
			'admin/site-statuses',
			array(
				'publisher_ids' => array( 'pub-own' ),
				'refresh'       => '1',
			)
		);
		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publishers/pub-own/sites' ), 'a refresh fetches the status again' );
		$this->assertSame( 'pause', $response->get_data()['data']['pub-own']->type, 'the refreshed status is returned' );
	}

	/**
	 * Tests that a longer list of publishers than a page of the network hub shows is rejected before any API request.
	 *
	 * @return void
	 */
	public function testSiteStatusesRejectOversizedLists(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		MockGistApi::$requests = array();

		$publisher_ids = array_map( fn ( $i ) => "pub-$i", range( 1, 101 ) );

		$this->assertSame( 400, $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => $publisher_ids ) )->get_status() );
		$this->assertSame( 200, $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array_slice( $publisher_ids, 0, 100 ) ) )->get_status() );
		$this->assertSame( 400, $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( array( 'pub-1' ) ) ) )->get_status(), 'IDs must be strings' );
		$this->assertCount( 100, MockGistApi::requests( 'GET', 'publishers/[^/]+/sites' ) );
	}

	/**
	 * Tests that a site statuses request stops calling the API once its time budget is used up, says it's incomplete,
	 * and that asking again fetches the rest; and that it stops at the first failure.
	 *
	 * @return void
	 */
	public function testSiteStatusesRespectATimeBudget(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		add_filter( 'gist_answers_site_statuses_time_budget', '__return_zero' );

		MockGistApi::$requests = array();

		$publisher_ids = array( 'pub-a', 'pub-b', 'pub-c' );

		$first  = $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => $publisher_ids ) )->get_data();
		$second = $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => $publisher_ids ) )->get_data();

		$this->assertSame( array( 'pub-a' ), array_keys( $first['data'] ) );
		$this->assertTrue( $first['incomplete'] );
		$this->assertSame( array( 'pub-a', 'pub-b' ), array_keys( $second['data'] ) );
		$this->assertCount( 2, MockGistApi::requests( 'GET', 'publishers/[^/]+/sites' ) );

		remove_filter( 'gist_answers_site_statuses_time_budget', '__return_zero' );

		$third = $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => $publisher_ids ) )->get_data();

		$this->assertArrayNotHasKey( 'incomplete', $third );
		$this->assertCount( 3, $third['data'] );

		MockGistApi::on( 'GET', 'publishers/[^/]+/sites', 503, array( 'error' => 'Unavailable' ) );
		MockGistApi::$requests = array();

		$this->assertSame( 503, $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'pub-d', 'pub-e', 'pub-f' ) ) )->get_status() );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/[^/]+/sites' ), 'the rest aren\'t fetched once one fails' );
	}

	/**
	 * Tests that site statuses are cached, without autoloading, and that the cache is capped.
	 *
	 * @return void
	 */
	public function testSiteStatusCacheIsCapped(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$statuses = array();

		for ( $i = 0; $i < 1005; $i++ ) {
			$statuses[ "pub-$i" ] = (object) array( 'type' => 'pause' );
		}

		self::call_method( new AdminMain(), 'update_cached_site_statuses', $statuses );

		$cached = AdminMain::get_cached_site_statuses();

		$this->assertCount( 1000, $cached );
		$this->assertArrayHasKey( 'pub-1004', $cached, 'the most recent are kept' );
		$this->assertArrayNotHasKey( 'pub-0', $cached );

		if ( ! is_multisite() ) {
			$this->assertArrayNotHasKey( 'gist_answers_site_statuses', wp_load_alloptions(), 'not autoloaded' );
		}
	}

	/**
	 * Tests that toggling ingestion starts or stops the site's crawl.
	 *
	 * @return void
	 */
	public function testSiteStatusUpdateStartsAndStopsTheCrawl(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$started = $this->rest(
			'POST',
			'admin/site-status/update',
			array(
				'publisher_id' => 'pub-own',
				'site_id'      => 'site-1',
				'checked'      => 'true',
			)
		);
		$stopped = $this->rest(
			'POST',
			'admin/site-status/update',
			array(
				'publisher_id' => 'pub-own',
				'site_id'      => 'site-1',
				'checked'      => 'false',
			)
		);

		$this->assertSame( 200, $started->get_status() );
		$this->assertSame( 200, $stopped->get_status() );
		$this->assertCount( 1, MockGistApi::requests( 'PUT', 'publishers/pub-own/crawl' ) );
		$this->assertCount( 1, MockGistApi::requests( 'DELETE', 'publishers/pub-own/crawl' ) );
		$this->assertSame( 'pause', AdminMain::get_cached_site_statuses()['pub-own']->type );
	}

	/**
	 * Tests that a site status update without a site, or with an unknown state, is rejected.
	 *
	 * @return void
	 */
	public function testSiteStatusUpdateValidation(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$this->assertSame(
			424,
			$this->rest(
				'POST',
				'admin/site-status/update',
				array(
					'publisher_id' => 'pub-own',
					'checked'      => 'true',
				)
			)->get_status()
		);
		$this->assertSame(
			424,
			$this->rest(
				'POST',
				'admin/site-status/update',
				array(
					'publisher_id' => 'pub-own',
					'site_id'      => 'site-1',
					'checked'      => 'maybe',
				)
			)->get_status()
		);
		$this->assertCount( 0, MockGistApi::requests( '*', 'publishers/.+/crawl' ) );
	}

	/**
	 * Tests the publisher matches route.
	 *
	 * @return void
	 */
	public function testPublisherMatches(): void {

		$this->connect();
		$this->log_in_as_super_admin();

		MockGistApi::set_publishers( array( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), 'example.org' ) ) );

		$data = (array) $this->rest( 'GET', 'admin/publisher-matches', array( 'blog_id' => 0 ) )->get_data();

		$this->assertSame( 'pub-own', $data['match_id'] );
		$this->assertFalse( $data['is_preproduction'] );
		$this->assertCount( 1, $data['publishers'] );
	}

	/**
	 * Tests the CMS iframe URL route.
	 *
	 * @return void
	 */
	public function testIframeUrl(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$data = $this->rest( 'GET', 'admin/iframe-url', array( 'which' => 'widgets-list' ) )->get_data();

		$this->assertStringContainsString( 'widgets/site/pub-own/your-widgets?embed=', $data['url'] );
		$this->assertTrue( Utilities::token_hash_is_valid( $data['token_hash'], 'mock-embed-uuid' ) );
		$this->assertSame( array( 'publisher_id' => 'pub-own' ), MockGistApi::requests( 'POST', 'embed' )[0]->body );
	}

	/**
	 * Tests that an unknown iframe is rejected, and that no token hash is ever returned without a URL.
	 *
	 * @return void
	 */
	public function testIframeUrlRejectsUnknownIframes(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$this->assertSame( 400, $this->rest( 'GET', 'admin/iframe-url', array( 'which' => 'bogus' ) )->get_status() );

		MockGistApi::on( 'POST', 'embed', 500, array( 'error' => 'Unavailable' ) );

		$response = $this->rest( 'GET', 'admin/iframe-url', array( 'which' => 'widgets-list' ) );

		$this->assertSame( 424, $response->get_status() );
		$this->assertSame( '', $response->get_data()['token_hash'] );
	}

	/**
	 * Tests the submenu page URL route.
	 *
	 * @return void
	 */
	public function testSubmenuPageUrl(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$url = $this->rest( 'GET', 'admin/submenu-page-url', array( 'which' => 'Widgets' ) )->get_data()['url'];

		$this->assertStringContainsString( 'gist-answers-widgets', $url );
		$this->assertStringNotContainsString( 'gist-answers-dashboard', $url );
	}

	/**
	 * Make an answer-page request with a valid embed token.
	 *
	 * @param array<mixed> $params The request parameters (besides the embed token).
	 *
	 * @return WP_REST_Response The response.
	 */
	private function answer_page( array $params ): WP_REST_Response {
		return $this->rest(
			'POST',
			'admin/answer-page',
			array_merge(
				array(
					'embed_token' => 'mock-embed-uuid',
					'token_hash'  => self::valid_token_hash(),
				),
				$params
			)
		);
	}

	/**
	 * Tests creating an answer page.
	 *
	 * @return void
	 */
	public function testAnswerPageIsCreated(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$response = $this->answer_page(
			array(
				'action'     => 'create',
				'target_url' => home_url( '/answers' ),
			)
		);

		$this->assertSame( 200, $response->get_status() );

		$page = get_page_by_path( 'answers' );

		$this->assertInstanceOf( WP_Post::class, $page );
		$this->assertSame( '<!-- wp:gist-answers/answer /-->', $page->post_content );
		$this->assertSame( 'publish', $page->post_status );
	}

	/**
	 * Tests that a nested answer page is created under its parent page, rather than as a flattened slug.
	 *
	 * @return void
	 */
	public function testNestedAnswerPageIsCreatedUnderItsParent(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$parent_id = self::factory()->post->create(
			array(
				'post_type' => 'page',
				'post_name' => 'help',
			)
		);

		$this->assertSame(
			200,
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => home_url( '/help/answers/' ),
				)
			)->get_status()
		);

		$page = get_page_by_path( 'help/answers' );

		$this->assertInstanceOf( WP_Post::class, $page );
		$this->assertSame( 'answers', $page->post_name );
		$this->assertSame( $parent_id, $page->post_parent );
		$this->assertNull( get_page_by_path( 'helpanswers' ) );
	}

	/**
	 * Tests the answer page creation errors.
	 *
	 * @return void
	 */
	public function testAnswerPageCreationErrors(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		self::factory()->post->create(
			array(
				'post_type' => 'page',
				'post_name' => 'taken',
			)
		);

		$this->assertSame(
			400,
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => home_url( '/taken' ),
				)
			)->get_status(),
			'page exists'
		);
		$this->assertSame(
			400,
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => home_url( '/no-parent/answers' ),
				)
			)->get_status(),
			'missing parent'
		);
		$this->assertSame(
			400,
			$this->answer_page(
				array(
					'action'     => 'delete',
					'target_url' => home_url( '/answers' ),
				)
			)->get_status(),
			'invalid action'
		);
		$this->assertContains(
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => '',
				)
			)->get_status(),
			array( 400, 403 ),
			'no target'
		);
		$this->assertContains(
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => home_url( '/' ),
				)
			)->get_status(),
			array( 400, 403 ),
			'the home page'
		);
	}

	/**
	 * Tests updating (moving) an answer page.
	 *
	 * @return void
	 */
	public function testAnswerPageIsUpdated(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$page_id = self::factory()->post->create(
			array(
				'post_type'    => 'page',
				'post_name'    => 'old-answers',
				'post_content' => '<!-- wp:gist-answers/answer /-->',
			)
		);

		$response = $this->answer_page(
			array(
				'action'          => 'update',
				'target_url'      => home_url( '/new-answers' ),
				'prev_target_url' => home_url( '/old-answers' ),
			)
		);

		$this->assertSame( 200, $response->get_status() );
		$this->assertSame( 'new-answers', get_post( $page_id )->post_name );
	}

	/**
	 * Tests that an answer page created through the CMS iframe can be moved, even once its widget has been removed.
	 *
	 * @return void
	 */
	public function testCreatedAnswerPageCanBeMoved(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$this->answer_page(
			array(
				'action'     => 'create',
				'target_url' => home_url( '/answers' ),
			)
		);

		$page_id = get_page_by_path( 'answers' )->ID;

		wp_update_post(
			array(
				'ID'           => $page_id,
				'post_content' => 'No widget here any more.',
			)
		);

		$response = $this->answer_page(
			array(
				'action'          => 'update',
				'target_url'      => home_url( '/moved-answers' ),
				'prev_target_url' => home_url( '/answers' ),
			)
		);

		$this->assertSame( 200, $response->get_status() );
		$this->assertSame( 'moved-answers', get_post( $page_id )->post_name );
	}

	/**
	 * Tests that a page that isn't an answer page is never moved (the reported "ordinary page moved" case).
	 *
	 * @return void
	 */
	public function testOrdinaryPageIsNotMoved(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$page_id = self::factory()->post->create(
			array(
				'post_type'    => 'page',
				'post_name'    => 'privacy-policy',
				'post_content' => 'Our privacy policy.',
			)
		);

		$response = $this->answer_page(
			array(
				'action'          => 'update',
				'target_url'      => home_url( '/moved-policy' ),
				'prev_target_url' => home_url( '/privacy-policy' ),
			)
		);

		$this->assertSame( 403, $response->get_status() );
		$this->assertSame( 'privacy-policy', get_post( $page_id )->post_name );
	}

	/**
	 * Tests that a user who can manage the plugin's settings, but not pages, can't create or move answer pages.
	 *
	 * @return void
	 */
	public function testAnswerPageRequiresContentCapabilities(): void {

		$this->connect_and_link();

		$page_id = self::factory()->post->create(
			array(
				'post_type'    => 'page',
				'post_name'    => 'old-answers',
				'post_content' => '<!-- wp:gist-answers/answer /-->',
			)
		);

		$user_id = $this->log_in_as( 'subscriber' );

		// A custom role with settings access only: the user can manage options, but not edit or publish pages.
		add_filter(
			'user_has_cap',
			fn ( $allcaps, $caps, $args, $user ) => $user_id === $user->ID ? array_merge( $allcaps, array( 'manage_options' => true ) ) : $allcaps,
			10,
			4
		);

		$create = $this->answer_page(
			array(
				'action'     => 'create',
				'target_url' => home_url( '/answers' ),
			)
		);

		$update = $this->answer_page(
			array(
				'action'          => 'update',
				'target_url'      => home_url( '/new-answers' ),
				'prev_target_url' => home_url( '/old-answers' ),
			)
		);

		$this->assertSame( 403, $create->get_status() );
		$this->assertNull( get_page_by_path( 'answers' ) );
		$this->assertSame( 403, $update->get_status() );
		$this->assertSame( 'old-answers', get_post( $page_id )->post_name );
	}

	/**
	 * Tests that, on single-site, an answer page URL on another host is rejected rather than read as a local path.
	 *
	 * @return void
	 */
	public function testAnswerPageOnAnotherHostIsRejected(): void {

		$this->require_single_site();

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$this->assertSame(
			403,
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => 'https://unrelated.invalid/answers',
				)
			)->get_status()
		);
		$this->assertNull( get_page_by_path( 'answers' ) );

		$www_url = str_replace( '://', '://www.', home_url( '/answers' ) );

		$this->assertSame(
			200,
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => $www_url,
				)
			)->get_status(),
			'the site\'s own domain with `www.` is still the site'
		);
	}

	/**
	 * Tests that the token hash only works for the user it was issued to, while it hasn't expired.
	 *
	 * @return void
	 */
	public function testAnswerPageGrantIsBoundToTheUserAndExpires(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$params = array(
			'action'      => 'create',
			'target_url'  => home_url( '/answers' ),
			'embed_token' => 'mock-embed-uuid',
		);

		$other_users_hash = self::valid_token_hash();

		$this->log_in_as_super_admin();

		$this->assertSame( 403, $this->rest( 'POST', 'admin/answer-page', array_merge( $params, array( 'token_hash' => $other_users_hash ) ) )->get_status(), 'another user' );
		$this->assertSame( 403, $this->rest( 'POST', 'admin/answer-page', array_merge( $params, array( 'token_hash' => Utilities::get_token_hash_from_embed_uuid( 'mock-embed-uuid', 0, time() - 1 ) ) ) )->get_status(), 'expired' );
		$this->assertNull( get_page_by_path( 'answers' ) );
	}

	/**
	 * Tests that updating an answer page never renames or moves a post of another type with the previous page's slug.
	 *
	 * @return void
	 */
	public function testAnswerPageUpdateOnlyMovesPages(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$post_id = self::factory()->post->create(
			array(
				'post_name'    => 'old-answers',
				'post_content' => '<!-- wp:gist-answers/answer /-->',
			)
		);

		$response = $this->answer_page(
			array(
				'action'          => 'update',
				'target_url'      => home_url( '/new-answers' ),
				'prev_target_url' => home_url( '/old-answers' ),
			)
		);

		$this->assertSame( 400, $response->get_status() );
		$this->assertSame( 'old-answers', get_post( $post_id )->post_name );
	}

	/**
	 * Tests the answer page update errors.
	 *
	 * @return void
	 */
	public function testAnswerPageUpdateErrors(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$this->assertSame(
			400,
			$this->answer_page(
				array(
					'action'          => 'update',
					'target_url'      => home_url( '/new' ),
					'prev_target_url' => home_url( '/missing' ),
				)
			)->get_status(),
			'previous page missing'
		);
		$this->assertSame(
			403,
			$this->answer_page(
				array(
					'action'          => 'update',
					'target_url'      => home_url( '/new' ),
					'prev_target_url' => 'https://elsewhere.example/old',
				)
			)->get_status(),
			'different domain'
		);
	}

	/**
	 * Tests that the answer page route can't be used without a real embed token (the reported token-hash bypass).
	 *
	 * @return void
	 */
	public function testAnswerPageRequiresARealEmbedToken(): void {

		$this->connect_and_link();
		$this->log_in_as_super_admin();

		$forged = array(
			'action'     => 'create',
			'target_url' => home_url( '/answers' ),
		);

		$this->assertSame(
			403,
			$this->rest(
				'POST',
				'admin/answer-page',
				array_merge(
					$forged,
					array(
						'embed_token' => '',
						'token_hash'  => wp_hash( '', 'auth', 'sha256' ),
					)
				)
			)->get_status()
		);
		$this->assertSame(
			403,
			$this->rest(
				'POST',
				'admin/answer-page',
				array_merge(
					$forged,
					array(
						'embed_token' => 'mock-embed-uuid',
						'token_hash'  => 'wrong',
					)
				)
			)->get_status()
		);
		$this->assertSame( 403, $this->rest( 'POST', 'admin/answer-page', array_merge( $forged, array( 'embed_token' => 'mock-embed-uuid' ) ) )->get_status() );
		$this->assertNull( get_page_by_path( 'answers' ) );
	}

	/**
	 * Set up a network with two subsites, and log in as an administrator of the first only.
	 *
	 * @return array<int> The IDs of the two subsites.
	 */
	private function log_in_as_subsite_admin(): array {

		$this->require_multisite();

		$site_a = self::factory()->blog->create( array( 'path' => '/site-a/' ) );
		$site_b = self::factory()->blog->create( array( 'path' => '/site-b/' ) );

		$user_id = self::factory()->user->create( array( 'role' => 'subscriber' ) );

		add_user_to_blog( $site_a, $user_id, 'administrator' );

		wp_set_current_user( $user_id );

		switch_to_blog( $site_a );

		return array( $site_a, $site_b );
	}

	/**
	 * Tests that a subsite administrator can only act on their own site.
	 *
	 * @return void
	 */
	public function testSubsiteAdministratorCannotActOnOtherSites(): void {

		[ $site_a, $site_b ] = $this->log_in_as_subsite_admin();

		$this->connect();

		$this->assertSame(
			403,
			$this->rest(
				'GET',
				'admin/iframe-url',
				array(
					'which'   => 'widgets-list',
					'blog_id' => $site_b,
				)
			)->get_status()
		);
		$this->assertSame( 403, $this->rest( 'GET', 'admin/publisher-matches', array( 'blog_id' => $site_b ) )->get_status() );
		$this->assertSame( 403, $this->rest( 'GET', 'admin/submenu-page-url', array( 'blog_id' => $site_b ) )->get_status() );
		$this->assertSame( 403, $this->rest( 'GET', 'admin/site-statuses', array( 'publisher_ids' => array( 'someone-else' ) ) )->get_status() );
		$this->assertSame(
			403,
			$this->rest(
				'POST',
				'admin/site-status/update',
				array(
					'publisher_id' => 'someone-else',
					'site_id'      => 'x',
					'checked'      => 'false',
				)
			)->get_status()
		);

		$this->assertSame(
			400,
			$this->rest(
				'GET',
				'admin/iframe-url',
				array(
					'which'   => 'bogus',
					'blog_id' => $site_a,
				)
			)->get_status(),
			'own site: allowed, then rejected as an invalid iframe'
		);
		$this->assertSame( 200, $this->rest( 'GET', 'admin/publisher-matches', array( 'blog_id' => $site_a ) )->get_status() );
	}

	/**
	 * Tests that a subsite administrator can't link their own site to another site's publisher (and so take control
	 * of it), nor to a publisher that doesn't match their site.
	 *
	 * @return void
	 */
	public function testSubsiteAdministratorCannotTakeOverAnotherSitesPublisher(): void {

		[ $site_a, $site_b ] = $this->log_in_as_subsite_admin();

		$this->connect();

		$publisher_b = MockGistApi::publisher( 'pub-b', 'Site B', 'b.example' );

		$this->link_publisher( $publisher_b, $site_b );

		MockGistApi::set_publishers( array( $publisher_b, MockGistApi::publisher( 'pub-unrelated', 'Unrelated', 'unrelated.example' ) ) );
		self::reset_plugin_state();

		$matches = (object) $this->rest( 'GET', 'admin/publisher-matches', array( 'blog_id' => $site_a ) )->get_data();

		$this->assertSame( array(), $matches->publishers, 'neither another site\'s publisher, nor one that doesn\'t match, is offered' );

		foreach ( array( 'pub-b', 'pub-unrelated' ) as $publisher_id ) {

			$outcome = $this->admin_post(
				array( new AdminMain(), 'handle_gist_answers_site_activation' ),
				'gist_answers_site_activation',
				AdminMain::SITE_ACTIVATION_NONCE,
				array(
					'gist_answers_blog_id'         => $site_a,
					'gist_answers_activation_mode' => 'associate',
					'gist_answers_publisher_id'    => $publisher_id,
				)
			);

			$this->assertStringContainsString( 'activated=-1', $outcome, $publisher_id );
			$this->assertSame( '', Credentials::get_stored_publisher_id( $site_a ), $publisher_id );
		}

		$this->assertSame(
			403,
			$this->rest(
				'POST',
				'admin/site-status/update',
				array(
					'publisher_id' => 'pub-b',
					'site_id'      => 'site-1',
					'checked'      => 'false',
				)
			)->get_status()
		);
		$this->assertCount( 0, MockGistApi::requests( 'DELETE', 'publishers/pub-b/crawl' ) );
	}

	/**
	 * Tests that a network administrator can link a site to a publisher that another site is linked to.
	 *
	 * @return void
	 */
	public function testNetworkAdministratorCanShareAPublisher(): void {

		$this->require_multisite();

		$site_a = self::factory()->blog->create( array( 'path' => '/site-a/' ) );
		$site_b = self::factory()->blog->create( array( 'path' => '/site-b/' ) );

		$this->log_in_as_super_admin();
		$this->connect();

		$publisher_b = MockGistApi::publisher( 'pub-b', 'Site B', 'b.example' );

		$this->link_publisher( $publisher_b, $site_b );
		self::reset_plugin_state();

		$matches = (object) $this->rest( 'GET', 'admin/publisher-matches', array( 'blog_id' => $site_a ) )->get_data();

		$this->assertSame( array( 'pub-b' ), array_map( fn ( $publisher ) => $publisher->id, $matches->publishers ) );

		$outcome = $this->admin_post(
			array( new AdminMain(), 'handle_gist_answers_site_activation' ),
			'gist_answers_site_activation',
			AdminMain::SITE_ACTIVATION_NONCE,
			array(
				'gist_answers_blog_id'         => $site_a,
				'gist_answers_activation_mode' => 'associate',
				'gist_answers_publisher_id'    => 'pub-b',
			)
		);

		$this->assertStringContainsString( 'activated=1', $outcome );
		$this->assertSame( 'pub-b', Credentials::get_stored_publisher_id( $site_a ) );
		$this->assertSame( 'pub-b', Credentials::get_stored_publisher_id( $site_b ) );
	}

	/**
	 * Tests that a subsite administrator can link their site to a publisher that another site is linked to, when the
	 * publisher lists their site's domain (as for a network's dev, staging and production sites).
	 *
	 * @return void
	 */
	public function testSubsiteAdministratorCanShareAPublisherThatListsTheirDomain(): void {

		$this->require_multisite();

		$site_a = self::factory()->blog->create(
			array(
				'domain' => 'staging.example-news.test',
				'path'   => '/',
				'title'  => 'Example News',
			)
		);
		$site_b = self::factory()->blog->create(
			array(
				'domain' => 'example-news.test',
				'path'   => '/',
				'title'  => 'Example News',
			)
		);

		$user_id = self::factory()->user->create( array( 'role' => 'subscriber' ) );

		add_user_to_blog( $site_a, $user_id, 'administrator' );
		wp_set_current_user( $user_id );
		switch_to_blog( $site_a );

		$this->connect();

		$publisher = MockGistApi::publisher( 'pub-shared', 'Example News', 'example-news.test', array( 'dev' => 'https://staging.example-news.test' ) );

		$this->link_publisher( $publisher, $site_b );
		self::reset_plugin_state();

		$matches = (object) $this->rest( 'GET', 'admin/publisher-matches', array( 'blog_id' => $site_a ) )->get_data();

		$this->assertSame( 'pub-shared', $matches->match_id );
		$this->assertSame( array( 'pub-shared' ), array_map( fn ( $publisher ) => $publisher->id, $matches->publishers ) );

		$outcome = $this->admin_post(
			array( new AdminMain(), 'handle_gist_answers_site_activation' ),
			'gist_answers_site_activation',
			AdminMain::SITE_ACTIVATION_NONCE,
			array(
				'gist_answers_blog_id'         => $site_a,
				'gist_answers_activation_mode' => 'associate',
				'gist_answers_publisher_id'    => 'pub-shared',
			)
		);

		$this->assertStringContainsString( 'activated=1', $outcome );
		$this->assertSame( 'pub-shared', Credentials::get_stored_publisher_id( $site_a ) );
		$this->assertSame( 'pub-shared', Credentials::get_stored_publisher_id( $site_b ) );
	}

	/**
	 * Tests that a subsite administrator can't create or move pages on another site through the answer page route.
	 *
	 * @return void
	 */
	public function testSubsiteAdministratorCannotChangeOtherSitesPages(): void {

		[ , $site_b ] = $this->log_in_as_subsite_admin();

		$this->connect();

		$site_b_url = get_home_url( $site_b );

		switch_to_blog( $site_b );
		$about_id = self::factory()->post->create(
			array(
				'post_type' => 'page',
				'post_name' => 'about',
			)
		);
		restore_current_blog();

		$this->assertSame(
			403,
			$this->answer_page(
				array(
					'action'          => 'update',
					'target_url'      => $site_b_url . '/about-renamed',
					'prev_target_url' => $site_b_url . '/about',
				)
			)->get_status()
		);
		$this->assertSame(
			403,
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => $site_b_url . '/answers',
				)
			)->get_status()
		);

		switch_to_blog( $site_b );
		$this->assertSame( 'about', get_post( $about_id )->post_name );
		$this->assertNull( get_page_by_path( 'answers' ) );
		restore_current_blog();
	}

	/**
	 * Tests that an answer page on a subdirectory site is created on that site, at the right path.
	 *
	 * @return void
	 */
	public function testAnswerPageIsCreatedOnTheTargetSubsite(): void {

		[ $site_a ] = $this->log_in_as_subsite_admin();

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-a', get_bloginfo( 'name' ), 'example.org' ), $site_a );

		$this->assertSame(
			200,
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => get_home_url( $site_a ) . '/answers/',
				)
			)->get_status()
		);

		$this->assertInstanceOf( WP_Post::class, get_page_by_path( 'answers' ), 'created on the subsite' );

		restore_current_blog();

		$this->assertNull( get_page_by_path( 'answers' ), 'not on the main site' );
		$this->assertNull( get_page_by_path( 'site-a/answers' ) );
	}

	/**
	 * Tests that a token hash issued for one site can't be used to create an answer page on another.
	 *
	 * @return void
	 */
	public function testAnswerPageGrantIsBoundToItsSite(): void {

		$this->require_multisite();

		$site_b = self::factory()->blog->create( array( 'path' => '/site-b/' ) );

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), 'example.org' ) );
		$this->link_publisher( MockGistApi::publisher( 'pub-b', 'Site B', 'example.org' ), $site_b );
		$this->log_in_as_super_admin();

		$this->assertSame(
			403,
			$this->answer_page(
				array(
					'action'     => 'create',
					'target_url' => get_home_url( $site_b ) . '/answers/',
				)
			)->get_status()
		);

		$this->assertSame(
			200,
			$this->rest(
				'POST',
				'admin/answer-page',
				array(
					'action'      => 'create',
					'target_url'  => get_home_url( $site_b ) . '/answers/',
					'embed_token' => 'mock-embed-uuid',
					'token_hash'  => Utilities::get_token_hash_from_embed_uuid( 'mock-embed-uuid', $site_b ),
				)
			)->get_status(),
			'a hash issued for that site works'
		);
	}

	/**
	 * Tests that a super admin can act on any site.
	 *
	 * @return void
	 */
	public function testSuperAdminCanActOnAnySite(): void {

		$this->require_multisite();

		$site_b = self::factory()->blog->create( array( 'path' => '/site-b/' ) );

		$this->connect();
		$this->log_in_as_super_admin();

		$this->assertSame(
			400,
			$this->rest(
				'GET',
				'admin/iframe-url',
				array(
					'which'   => 'bogus',
					'blog_id' => $site_b,
				)
			)->get_status()
		);
		$this->assertSame( 200, $this->rest( 'GET', 'admin/publisher-matches', array( 'blog_id' => $site_b ) )->get_status() );
		$this->assertTrue( AdminMain::current_user_can_manage_site( $site_b ) );
		$this->assertTrue( AdminMain::current_user_can_manage_network() );
	}

	/**
	 * Tests the capability helpers for a site that doesn't exist.
	 *
	 * @return void
	 */
	public function testCapabilityHelpersRejectMissingSites(): void {

		$this->require_multisite();

		$this->log_in_as_super_admin();

		$this->assertFalse( AdminMain::current_user_can_manage_site( 999999 ) );
	}
}
