<?php
/**
 * Class for testing the Gist Answers plugin functionality.
 *
 * @package GistAnswers
 */

use GistAnswers\Admin\MenuItems;

use PHPUnit\Framework\TestCase;

/**
 * Class for testing the Gist Answers admin functionality.
 */
final class AdminTest extends TestCase {

	/**
	 * Tests that the admin menu items are valid.
	 *
	 * @return void
	 */
	public function testAdminMenuItemsAreValid(): void {
		$this->assertTrue( MenuItems::are_valid() );
	}

	/**
	 * Tests that the admin menu templates are available.
	 *
	 * @return void
	 */
	public function testAdminMenuTemplatesExist(): void {
		$this->assertTrue( MenuItems::templates_exist() );
	}

	/**
	 * Tests that the network menu template is available.
	 *
	 * @return void
	 */
	public function testNetworkMenuTemplateExists(): void {
		$this->assertFileExists( GIST_ANSWERS_PLUGIN_DIR . 'templates/network-menu.php' );
	}
}
