<?php
/**
 * Tests for what happens when content is saved: ingestion, and flagging pages with answer widgets.
 *
 * @package GistAnswers
 */

use GistAnswers\Admin\AdminMain;
use GistAnswers\Plugin\CommonMain;
use GistAnswers\Plugin\Deactivate;
use GistAnswers\Plugin\Uninstall;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for what happens when content is saved: ingestion, and flagging pages with answer widgets.
 */
final class SavePostTest extends TestCase {

	private const INGEST_AFTER_META_KEY = 'gist_answers_ingest_after';
	private const FLAG_META_KEY         = 'gist_answers_answer_widget_flag';
	private const UNFLAG_META_KEY       = 'gist_answers_answer_widget_unflag';

	/**
	 * Connect and link the site, and log in as an editor.
	 *
	 * @return void
	 */
	protected function setUp(): void {

		parent::setUp();

		$this->connect();
		$this->link_publisher( MockGistApi::publisher( 'pub-own', get_bloginfo( 'name' ), 'example.org' ) );

		// Pretty permalinks, so pages have slugs (as answer pages need).
		global $wp_rewrite;
		$wp_rewrite->set_permalink_structure( '/%postname%/' );

		// As if the saves below were new requests.
		self::reset_plugin_state();
		MockGistApi::$requests = array();
		wp_clear_scheduled_hook( AdminMain::INGEST_CRON_HOOK );

		$this->log_in_as( 'editor' );
	}

	/**
	 * Run the plugin's `admin_init` bookkeeping tasks, as an admin page load would.
	 *
	 * @return void
	 */
	private function run_admin_bookkeeping(): void {

		foreach ( array( 'posts_requiring_ingestion', 'flagged_answer_widget_posts', 'unflagged_answer_widget_posts' ) as $task ) {
			delete_transient( 'gist_answers_admin_task_' . $task );
		}

		self::run_plugin_admin_init();
	}

	/**
	 * Run only the plugin's own `admin_init` callbacks (not WordPress core's, such as its update checks).
	 *
	 * @return void
	 */
	private static function run_plugin_admin_init(): void {

		global $wp_filter;

		foreach ( $wp_filter['admin_init']->callbacks ?? array() as $callbacks ) {
			foreach ( $callbacks as $callback ) {
				if ( $callback['function'] instanceof Closure && AdminMain::class === ( new ReflectionFunction( $callback['function'] ) )->getClosureScopeClass()?->getName() ) {
					( $callback['function'] )();
				}
			}
		}
	}

	/**
	 * Run the plugin's ingestion WP-Cron event, as WP-Cron would: with no user, and with the event already unscheduled.
	 *
	 * @return void
	 */
	private static function run_ingest_cron(): void {

		$user_id = get_current_user_id();

		wp_set_current_user( 0 );
		wp_clear_scheduled_hook( AdminMain::INGEST_CRON_HOOK );

		add_filter( 'wp_doing_cron', '__return_true' );
		do_action( AdminMain::INGEST_CRON_HOOK );
		remove_filter( 'wp_doing_cron', '__return_true' );

		wp_set_current_user( $user_id );
	}

	/**
	 * Create a page, as saved from the editor.
	 *
	 * @param string $content The page content.
	 * @param string $slug    Optional page slug. Defaults to `answers`.
	 *
	 * @return int The page ID.
	 */
	private function create_page( string $content, string $slug = 'answers' ): int {
		return self::factory()->post->create(
			array(
				'post_type'    => 'page',
				'post_name'    => $slug,
				'post_content' => $content,
			)
		);
	}

	/**
	 * Tests that a published post is queued for ingestion, shortly after it's saved.
	 *
	 * @return void
	 */
	public function testPublishedPostIsQueuedForIngestion(): void {

		$fired = 0;
		add_action(
			AdminMain::ACTION_API_POST_ENQUEUED,
			function () use ( &$fired ) {
				++$fired;
			}
		);

		$post_id = self::factory()->post->create();

		$ingest_after = intval( get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );

		$this->assertGreaterThan( time(), $ingest_after );
		$this->assertLessThanOrEqual( time() + 5, $ingest_after );
		$this->assertSame( 1, $fired );
	}

	/**
	 * Tests that a scheduled post isn't queued while it's scheduled, but is when WP-Cron publishes it.
	 *
	 * @return void
	 */
	public function testScheduledPostIsQueuedWhenPublishedByCron(): void {

		$post_id = self::factory()->post->create(
			array(
				'post_status' => 'future',
				'post_date'   => wp_date( 'Y-m-d H:i:s', time() + DAY_IN_SECONDS ),
			)
		);

		$this->assertSame( 'future', get_post_status( $post_id ) );
		$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );

		// WP-Cron publishes scheduled posts with no current user.
		wp_set_current_user( 0 );

		add_filter( 'wp_doing_cron', '__return_true' );
		wp_publish_post( $post_id );
		remove_filter( 'wp_doing_cron', '__return_true' );

		$this->assertSame( 'publish', get_post_status( $post_id ) );
		$this->assertNotSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
	}

	/**
	 * Tests that a scheduled post published by an editor is queued once, not by both of the hooks that queue posts.
	 *
	 * @return void
	 */
	public function testScheduledPostPublishedByAnEditorIsQueuedOnce(): void {

		$post_id = self::factory()->post->create(
			array(
				'post_status' => 'future',
				'post_date'   => wp_date( 'Y-m-d H:i:s', time() + DAY_IN_SECONDS ),
			)
		);

		$fired = 0;
		add_action(
			AdminMain::ACTION_API_POST_ENQUEUED,
			function () use ( &$fired ) {
				++$fired;
			}
		);

		wp_publish_post( $post_id );

		$this->assertNotSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertSame( 1, $fired );
	}

	/**
	 * Tests that other saves made by WP-Cron jobs (with no user) aren't queued: only scheduled posts being published are.
	 *
	 * @return void
	 */
	public function testOtherCronSavesAreNotQueued(): void {

		$post_id = self::factory()->post->create();
		delete_post_meta( $post_id, self::INGEST_AFTER_META_KEY );

		wp_set_current_user( 0 );

		add_filter( 'wp_doing_cron', '__return_true' );
		wp_update_post(
			array(
				'ID'         => $post_id,
				'post_title' => 'Refreshed by a WP-Cron job',
			)
		);
		remove_filter( 'wp_doing_cron', '__return_true' );

		$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
	}

	/**
	 * Tests that the ingestion hooks are registered by CommonMain, which every request loads, and not by AdminMain:
	 * WP-Cron run from WP-CLI (as on WordPress VIP) loads the plugin's front-end side.
	 *
	 * @return void
	 */
	public function testIngestionHooksAreRegisteredOnEveryRequest(): void {

		remove_all_actions( AdminMain::INGEST_CRON_HOOK );
		remove_all_actions( 'future_to_publish' );

		new AdminMain();

		$this->assertFalse( has_action( AdminMain::INGEST_CRON_HOOK ) );
		$this->assertFalse( has_action( 'future_to_publish' ) );

		new CommonMain();

		$this->assertTrue( has_action( AdminMain::INGEST_CRON_HOOK ) );
		$this->assertTrue( has_action( 'future_to_publish' ) );
	}

	/**
	 * Tests that nothing is queued, or scheduled, for a site that isn't linked to a publisher, and that the save
	 * doesn't search the API for one.
	 *
	 * @return void
	 */
	public function testNothingIsQueuedWithoutAPublisher(): void {

		delete_option( 'gist_answers_publisher' );
		self::reset_plugin_state();

		$post_id = self::factory()->post->create();

		$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );
		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publishers(/[^/]+)?' ), 'no publisher lookup during the save' );
	}

	/**
	 * Tests that an admin page load schedules WP-Cron for posts that were queued without it (as by an earlier version
	 * of the plugin, or before it was deactivated).
	 *
	 * @return void
	 */
	public function testAdminPageLoadSchedulesTheQueue(): void {

		$post_id = self::factory()->post->create();
		update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() + 600 );
		wp_clear_scheduled_hook( AdminMain::INGEST_CRON_HOOK );

		$this->run_admin_bookkeeping();

		$this->assertSame( intval( get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) ), wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );
	}

	/**
	 * Tests that queueing a post moves a later WP-Cron event forward, rather than leaving the post to wait for it.
	 *
	 * @return void
	 */
	public function testQueueingAPostMovesALaterEventForward(): void {

		wp_schedule_single_event( time() + 600, AdminMain::INGEST_CRON_HOOK );

		$post_id = self::factory()->post->create();

		$this->assertSame( intval( get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) ), wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );
	}

	/**
	 * Tests that queueing a post schedules the WP-Cron event that sends it, for when it's due.
	 *
	 * @return void
	 */
	public function testQueueingAPostSchedulesItsIngestion(): void {

		$this->assertFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );

		$post_id = self::factory()->post->create();

		$this->assertSame( intval( get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) ), wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );
	}

	/**
	 * Tests that WP-Cron sends the queued posts that are due, then runs again when the next one is due.
	 *
	 * @return void
	 */
	public function testCronSendsQueuedPosts(): void {

		$due    = self::factory()->post->create();
		$future = self::factory()->post->create();

		update_post_meta( $due, self::INGEST_AFTER_META_KEY, time() - 10 );
		update_post_meta( $future, self::INGEST_AFTER_META_KEY, time() + 600 );

		self::run_ingest_cron();

		$requests = MockGistApi::requests( 'POST', 'publishers/pub-own/ingest' );

		$this->assertCount( 1, $requests );
		$this->assertSame( get_permalink( $due ), $requests[0]->body['url'] );
		$this->assertSame( '', get_post_meta( $due, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertSame( intval( get_post_meta( $future, self::INGEST_AFTER_META_KEY, true ) ), wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );

		delete_post_meta( $future, self::INGEST_AFTER_META_KEY );

		self::run_ingest_cron();

		$this->assertFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 'not rescheduled once nothing is queued' );
	}

	/**
	 * Tests that when more posts are due than one run sends, WP-Cron sends the rest a minute later.
	 *
	 * @return void
	 */
	public function testCronSendsTheRestOfALargeQueueAMinuteLater(): void {

		add_filter( 'gist_answers_max_posts_for_ingestion', fn () => 1 );

		foreach ( self::factory()->post->create_many( 2 ) as $post_id ) {
			update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );
		}

		self::run_ingest_cron();

		$this->assertCount( 1, MockGistApi::requests( 'POST', '.+/ingest' ) );
		$this->assertEqualsWithDelta( time() + MINUTE_IN_SECONDS, wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 5 );
	}

	/**
	 * Tests that a post another request has already claimed (as when an admin page load and WP-Cron send the queue at
	 * the same time) isn't sent again.
	 *
	 * @return void
	 */
	public function testPostClaimedByAnotherRequestIsNotSentAgain(): void {

		$post_ids = self::factory()->post->create_many( 2 );

		foreach ( $post_ids as $post_id ) {
			update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );
		}

		// As if another request claimed the other post while this one was sending the first.
		add_action(
			AdminMain::ACTION_API_POST_INGESTED,
			function ( $post_id ) use ( $post_ids ) {
				delete_post_meta( $post_ids[0] === $post_id ? $post_ids[1] : $post_ids[0], self::INGEST_AFTER_META_KEY );
			}
		);

		self::run_ingest_cron();

		$this->assertCount( 1, MockGistApi::requests( 'POST', '.+/ingest' ) );
	}

	/**
	 * Tests that a post saved again while the queue is being sent isn't sent then, but waits for its new delay.
	 *
	 * @return void
	 */
	public function testPostSavedAgainWhileTheQueueIsSentWaitsForItsDelay(): void {

		$post_ids = self::factory()->post->create_many( 2 );

		foreach ( $post_ids as $post_id ) {
			update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );
		}

		$saved_again_after = time() + 300;

		// As if the other post was saved again while this request was sending the first.
		add_action(
			AdminMain::ACTION_API_POST_INGESTED,
			function ( $post_id ) use ( $post_ids, $saved_again_after ) {
				update_post_meta( $post_ids[0] === $post_id ? $post_ids[1] : $post_ids[0], self::INGEST_AFTER_META_KEY, $saved_again_after );
			}
		);

		self::run_ingest_cron();

		$requests = MockGistApi::requests( 'POST', '.+/ingest' );

		$this->assertCount( 1, $requests );

		$saved_again = get_permalink( $post_ids[0] ) === $requests[0]->body['url'] ? $post_ids[1] : $post_ids[0];

		$this->assertSame( strval( $saved_again_after ), get_post_meta( $saved_again, self::INGEST_AFTER_META_KEY, true ) );
	}

	/**
	 * Tests that while the API token can't be confirmed (e.g. the Gist API is briefly unreachable), WP-Cron sends
	 * nothing, but keeps the queue, and tries again a few minutes later.
	 *
	 * @return void
	 */
	public function testCronRetriesWhileTheTokenCantBeConfirmed(): void {

		$post_id = self::factory()->post->create();
		update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );

		if ( is_multisite() ) {
			delete_site_transient( 'gist_answers_api_token_is_valid' );
			set_site_transient( 'gist_answers_api_token_check_failed', true, MINUTE_IN_SECONDS );
		} else {
			delete_transient( 'gist_answers_api_token_is_valid' );
			set_transient( 'gist_answers_api_token_check_failed', true, MINUTE_IN_SECONDS );
		}

		self::reset_plugin_state();

		self::run_ingest_cron();

		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/ingest' ) );
		$this->assertNotSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertEqualsWithDelta( time() + 5 * MINUTE_IN_SECONDS, wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 5 );
	}

	/**
	 * Queue a post that is due now, as if it was saved a while ago.
	 *
	 * @param array<mixed> $args Optional post arguments.
	 *
	 * @return int The post ID.
	 */
	private static function create_due_post( array $args = array() ): int {

		$post_id = self::factory()->post->create( $args );

		update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );

		return $post_id;
	}

	/**
	 * Record the posts the plugin reports as ingested, and as given up on.
	 *
	 * @return object With `ingested` and `failed` arrays of post IDs, filled in as the actions fire.
	 */
	private static function record_ingestion_outcomes(): object {

		$outcomes = (object) array(
			'ingested' => array(),
			'failed'   => array(),
		);

		add_action(
			AdminMain::ACTION_API_POST_INGESTED,
			function ( $post_id ) use ( $outcomes ) {
				$outcomes->ingested[] = $post_id;
			}
		);
		add_action(
			AdminMain::ACTION_API_POST_INGESTION_FAILED,
			function ( $post_id, $response, $attempts ) use ( $outcomes ) {
				$outcomes->failed[] = array( $post_id, $response->code, $attempts );
			},
			10,
			3
		);

		return $outcomes;
	}

	/**
	 * Tests that a post the API couldn't accept (a timeout, or a server error) stays queued, and is sent again after a
	 * backoff, and that the ingested action only fires once the API accepts it.
	 *
	 * @return void
	 */
	public function testFailedIngestionIsRetried(): void {

		$outcomes = self::record_ingestion_outcomes();

		foreach ( array( 503, 'timeout' ) as $failure ) {

			$post_id = self::create_due_post();

			if ( 'timeout' === $failure ) {
				MockGistApi::unreachable( 'POST', '.+/ingest' );
			} else {
				MockGistApi::on( 'POST', '.+/ingest', 503, array( 'error' => 'Unavailable' ) );
			}

			self::run_ingest_cron();

			$retry_at = intval( get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );

			$this->assertGreaterThanOrEqual( time() + 5 * MINUTE_IN_SECONDS - 5, $retry_at, "$failure: retried after a backoff" );
			$this->assertLessThanOrEqual( time() + 5 * MINUTE_IN_SECONDS * 1.25 + 5, $retry_at, "$failure: with some jitter" );
			$this->assertSame( '1', get_post_meta( $post_id, 'gist_answers_ingest_attempts', true ), $failure );
			$this->assertSame( $retry_at, wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), $failure );
			$this->assertSame( array(), $outcomes->ingested, "$failure: not reported as ingested" );
			$this->assertSame( array(), $outcomes->failed, "$failure: not given up on" );

			// Once it's due again, and the API is back.
			MockGistApi::on( 'POST', '.+/ingest', 200, array( 'ok' => true ) );
			update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );

			self::run_ingest_cron();

			$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ), $failure );
			$this->assertSame( '', get_post_meta( $post_id, 'gist_answers_ingest_attempts', true ), $failure );
			$this->assertSame( array( $post_id ), $outcomes->ingested, $failure );

			$outcomes->ingested = array();
		}
	}

	/**
	 * Tests that each retry waits longer, and that a rate-limited post waits as long as the API asks, and holds back
	 * the rest of the queue too.
	 *
	 * @return void
	 */
	public function testRetriesBackOffAndRespectRetryAfter(): void {

		$post_id = self::create_due_post();
		$later   = self::create_due_post();

		// So the first is sent first.
		update_post_meta( $later, self::INGEST_AFTER_META_KEY, time() - 5 );
		update_post_meta( $post_id, 'gist_answers_ingest_attempts', 3 );

		MockGistApi::on( 'POST', '.+/ingest', 503, array( 'error' => 'Unavailable' ) );

		self::run_ingest_cron();

		$this->assertCount( 1, MockGistApi::requests( 'POST', '.+/ingest' ), 'the rest of the queue isn\'t sent once one fails' );

		$retry_at = intval( get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );

		$this->assertGreaterThanOrEqual( time() + 40 * MINUTE_IN_SECONDS - 5, $retry_at, 'the fourth attempt waits 40 minutes' );
		$this->assertLessThanOrEqual( time() + 50 * MINUTE_IN_SECONDS + 5, $retry_at );
		$this->assertLessThanOrEqual( time(), intval( get_post_meta( $later, self::INGEST_AFTER_META_KEY, true ) ), 'the other post is still due' );
		$this->assertGreaterThanOrEqual( time() + 40 * MINUTE_IN_SECONDS - 5, wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 'but waits for the next run' );

		delete_post_meta( $post_id, self::INGEST_AFTER_META_KEY );
		delete_post_meta( $later, self::INGEST_AFTER_META_KEY );

		$rate_limited = self::create_due_post();

		MockGistApi::on( 'POST', '.+/ingest', fn () => array( 429, array( 'error' => 'Slow down' ), array( 'retry-after' => '1800' ) ) );

		self::run_ingest_cron();

		$this->assertGreaterThanOrEqual( time() + 1800 - 5, intval( get_post_meta( $rate_limited, self::INGEST_AFTER_META_KEY, true ) ), 'Retry-After is respected' );
	}

	/**
	 * Tests that a post is given up on (and reported) once the API rejects it, or after the last retry, and is sent
	 * again the next time it's saved.
	 *
	 * @return void
	 */
	public function testIngestionIsGivenUpOn(): void {

		$outcomes = self::record_ingestion_outcomes();

		$rejected = self::create_due_post();

		MockGistApi::on( 'POST', '.+/ingest', 422, array( 'error' => 'Invalid URL' ) );

		self::run_ingest_cron();

		$this->assertSame( '', get_post_meta( $rejected, self::INGEST_AFTER_META_KEY, true ), 'a rejected post isn\'t retried' );
		$this->assertSame( array( array( $rejected, 422, 1 ) ), $outcomes->failed );

		$exhausted = self::create_due_post();
		update_post_meta( $exhausted, 'gist_answers_ingest_attempts', 7 );

		MockGistApi::on( 'POST', '.+/ingest', 503, array( 'error' => 'Unavailable' ) );

		self::run_ingest_cron();

		$this->assertSame( '', get_post_meta( $exhausted, self::INGEST_AFTER_META_KEY, true ), 'given up on after the last attempt' );
		$this->assertSame( '', get_post_meta( $exhausted, 'gist_answers_ingest_attempts', true ) );
		$this->assertSame( array( $exhausted, 503, 8 ), $outcomes->failed[1] );
		$this->assertSame( array(), $outcomes->ingested );

		wp_update_post(
			array(
				'ID'         => $exhausted,
				'post_title' => 'Edited',
			)
		);

		$this->assertNotSame( '', get_post_meta( $exhausted, self::INGEST_AFTER_META_KEY, true ), 'queued again when saved' );
	}

	/**
	 * Tests that a post sent with a rejected API token stays queued without using up an attempt, and that nothing
	 * more is sent in that run.
	 *
	 * @return void
	 */
	public function testRejectedTokenKeepsThePostQueued(): void {

		$post_ids = array( self::create_due_post(), self::create_due_post() );

		MockGistApi::on( 'POST', '.+/ingest', 401, array( 'error' => 'Unauthorized' ) );

		self::run_ingest_cron();

		$this->assertCount( 1, MockGistApi::requests( 'POST', '.+/ingest' ) );

		foreach ( $post_ids as $post_id ) {
			$this->assertNotSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
			$this->assertContains( get_post_meta( $post_id, 'gist_answers_ingest_attempts', true ), array( '', '0' ) );
		}

		$this->assertEqualsWithDelta( time() + 5 * MINUTE_IN_SECONDS, wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 5 );
	}

	/**
	 * Tests that a post whose sending request dies after claiming it stays queued, and is sent once its lease runs out.
	 *
	 * @return void
	 */
	public function testInterruptedIngestionIsRecovered(): void {

		$post_id = self::create_due_post();

		MockGistApi::on(
			'POST',
			'.+/ingest',
			function () {
				throw new RuntimeException( 'The PHP process died.' );
			}
		);

		$user_id = get_current_user_id();

		try {
			self::run_ingest_cron();
		} catch ( RuntimeException $e ) {
			remove_filter( 'wp_doing_cron', '__return_true' );
			wp_set_current_user( $user_id );
		}

		$lease = intval( get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );

		$this->assertEqualsWithDelta( time() + 10 * MINUTE_IN_SECONDS, $lease, 5, 'still queued, until its lease runs out' );

		// Once the lease has run out.
		MockGistApi::on( 'POST', '.+/ingest', 200, array( 'ok' => true ) );
		update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 1 );

		self::run_ingest_cron();

		$this->assertCount( 2, MockGistApi::requests( 'POST', '.+/ingest' ) );
		$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
	}

	/**
	 * Tests that a post saved again while it's being sent stays queued for that save, even once the API accepts the
	 * earlier one.
	 *
	 * @return void
	 */
	public function testPostSavedWhileBeingSentIsSentAgain(): void {

		$post_id = self::create_due_post();

		$saved_again_after = time() + 300;

		MockGistApi::on(
			'POST',
			'.+/ingest',
			function () use ( $post_id, $saved_again_after ) {

				update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, $saved_again_after );

				return array( 200, array( 'ok' => true ) );
			}
		);

		self::run_ingest_cron();

		$this->assertSame( strval( $saved_again_after ), get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertSame( $saved_again_after, wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );
	}

	/**
	 * Tests that a queued post that is no longer eligible when it's due (it was made private, a draft or
	 * password-protected, lost its category, or a filter now excludes it) isn't sent, and leaves the queue.
	 *
	 * @return void
	 */
	public function testIneligibleQueuedPostsAreNotSent(): void {

		$news = self::factory()->category->create( array( 'slug' => 'news' ) );

		$post_ids = array(
			'private'   => self::create_due_post( array( 'post_status' => 'private' ) ),
			'draft'     => self::create_due_post( array( 'post_status' => 'draft' ) ),
			'password'  => self::create_due_post( array( 'post_password' => 'secret' ) ),
			'untagged'  => self::create_due_post(),
			'filtered'  => self::create_due_post(),
			'unchanged' => self::create_due_post( array( 'post_category' => array( $news ) ) ),
		);

		add_filter(
			'gist_answers_ingest_tax_query',
			fn () => array(
				array(
					'taxonomy' => 'category',
					'field'    => 'term_id',
					'terms'    => array( $news ),
				),
			)
		);
		add_filter( AdminMain::FILTER_SHOULD_ENQUEUE, fn ( $should_enqueue, $post_id ) => $should_enqueue && $post_ids['filtered'] !== $post_id, 10, 2 );

		self::run_ingest_cron();

		$requests = MockGistApi::requests( 'POST', '.+/ingest' );

		$this->assertSame( array( get_permalink( $post_ids['unchanged'] ) ), array_map( fn ( $request ) => $request->body['url'], $requests ) );

		foreach ( $post_ids as $label => $post_id ) {
			$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ), $label );
		}
	}

	/**
	 * Tests that saving a queued post in a way that makes it ineligible takes it out of the queue straight away.
	 *
	 * @return void
	 */
	public function testPostMadeIneligibleLeavesTheQueue(): void {

		$changes = array(
			'private'  => array( 'post_status' => 'private' ),
			'draft'    => array( 'post_status' => 'draft' ),
			'password' => array( 'post_password' => 'secret' ),
			'trash'    => array( 'post_status' => 'trash' ),
		);

		foreach ( $changes as $label => $change ) {

			$post_id = self::factory()->post->create();

			$this->assertNotSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ), $label );

			wp_update_post( array_merge( array( 'ID' => $post_id ), $change ) );

			$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ), $label );
		}
	}

	/**
	 * Tests that a password-protected post isn't queued, unless the filter allows it.
	 *
	 * @return void
	 */
	public function testPasswordProtectedPostsAreNotQueued(): void {

		$protected = self::factory()->post->create( array( 'post_password' => 'secret' ) );

		$this->assertSame( '', get_post_meta( $protected, self::INGEST_AFTER_META_KEY, true ) );

		add_filter( AdminMain::FILTER_SHOULD_ENQUEUE, '__return_true' );

		$allowed = self::factory()->post->create( array( 'post_password' => 'secret' ) );

		$this->assertNotSame( '', get_post_meta( $allowed, self::INGEST_AFTER_META_KEY, true ) );
	}

	/**
	 * Tests that queued posts of a type excluded from search (which `post_type => any` leaves out) are sent.
	 *
	 * @return void
	 */
	public function testQueuedPostsOfTypesExcludedFromSearchAreSent(): void {

		register_post_type(
			'gist_answers_hidden',
			array(
				'public'              => true,
				'exclude_from_search' => true,
			)
		);
		add_filter( 'gist_answers_ingest_post_types', fn () => array( 'post', 'gist_answers_hidden' ) );

		$post_id = self::factory()->post->create( array( 'post_type' => 'gist_answers_hidden' ) );
		update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );

		self::run_ingest_cron();

		unregister_post_type( 'gist_answers_hidden' );

		$this->assertCount( 1, MockGistApi::requests( 'POST', '.+/ingest' ) );
	}

	/**
	 * Tests that a network deactivation unschedules the ingestion event on every site, and a site's own deactivation
	 * only on that site.
	 *
	 * @return void
	 */
	public function testDeactivationUnschedulesIngestionOnEverySite(): void {

		$this->require_multisite();

		$blog_ids = array( get_current_blog_id(), self::factory()->blog->create( array( 'path' => '/site-a/' ) ) );

		foreach ( $blog_ids as $blog_id ) {
			switch_to_blog( $blog_id );
			wp_schedule_single_event( time() + 60, AdminMain::INGEST_CRON_HOOK );
			restore_current_blog();
		}

		Deactivate::deactivate();

		$this->assertSame( array( false, true ), array_map( array( self::class, 'is_ingestion_scheduled_on' ), $blog_ids ) );

		Deactivate::deactivate( true );

		$this->assertSame( array( false, false ), array_map( array( self::class, 'is_ingestion_scheduled_on' ), $blog_ids ) );
	}

	/**
	 * Tests that uninstalling the plugin unschedules the ingestion event, and deletes the posts' ingestion meta.
	 *
	 * @return void
	 */
	public function testUninstallDeletesTheIngestionQueue(): void {

		$post_id = self::factory()->post->create();
		update_post_meta( $post_id, 'gist_answers_ingest_response', 'response' );

		$this->assertTrue( self::is_ingestion_scheduled_on( get_current_blog_id() ) );

		Uninstall::uninstall();

		$this->assertFalse( self::is_ingestion_scheduled_on( get_current_blog_id() ) );
		$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertSame( '', get_post_meta( $post_id, 'gist_answers_ingest_response', true ) );
	}

	/**
	 * Determine whether the ingestion WP-Cron event is scheduled on the given site.
	 *
	 * @param int $blog_id The site ID.
	 *
	 * @return bool True if the event is scheduled, false otherwise.
	 */
	private static function is_ingestion_scheduled_on( int $blog_id ): bool {

		if ( is_multisite() ) {
			switch_to_blog( $blog_id );
		}

		$is_scheduled = false !== wp_next_scheduled( AdminMain::INGEST_CRON_HOOK );

		if ( is_multisite() ) {
			restore_current_blog();
		}

		return $is_scheduled;
	}

	/**
	 * Tests that WP-Cron sends nothing, and isn't rescheduled, for a site without a linked publisher.
	 *
	 * @return void
	 */
	public function testCronDoesNothingWithoutAPublisher(): void {

		delete_option( 'gist_answers_publisher' );
		set_transient( 'gist_answers_publisher_lookup_attempted', true, HOUR_IN_SECONDS );
		self::reset_plugin_state();

		$post_id = self::factory()->post->create();
		update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );

		self::run_ingest_cron();

		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/ingest' ) );
		$this->assertFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );
	}

	/**
	 * Tests the posts that aren't queued for ingestion.
	 *
	 * @return void
	 */
	public function testIneligiblePostsAreNotQueued(): void {

		$draft = self::factory()->post->create( array( 'post_status' => 'draft' ) );
		$page  = self::factory()->post->create( array( 'post_type' => 'page' ) );

		add_filter( AdminMain::FILTER_SHOULD_ENQUEUE, '__return_false' );
		$filtered = self::factory()->post->create();
		remove_filter( AdminMain::FILTER_SHOULD_ENQUEUE, '__return_false' );

		wp_set_current_user( 0 );
		$anonymous = self::factory()->post->create();

		foreach ( compact( 'draft', 'page', 'filtered', 'anonymous' ) as $label => $post_id ) {
			$this->assertSame( '', get_post_meta( $post_id, self::INGEST_AFTER_META_KEY, true ), $label );
		}
	}

	/**
	 * Tests that the ingestion post types, statuses, and taxonomy query can be filtered.
	 *
	 * @return void
	 */
	public function testIngestionCanBeLimitedByFilters(): void {

		$news = self::factory()->category->create( array( 'slug' => 'news' ) );

		add_filter(
			'gist_answers_ingest_tax_query',
			fn () => array(
				array(
					'taxonomy' => 'category',
					'field'    => 'term_id',
					'terms'    => array( $news ),
				),
			)
		);
		add_filter( 'gist_answers_ingest_post_types', fn () => array( 'post', 'page' ) );

		$in_news  = self::factory()->post->create( array( 'post_category' => array( $news ) ) );
		$no_terms = self::factory()->post->create();

		$this->assertNotSame( '', get_post_meta( $in_news, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertSame( '', get_post_meta( $no_terms, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertSame( array( 'post', 'page' ), AdminMain::get_ingest_post_types() );
	}

	/**
	 * Tests that queued posts are sent for ingestion from WP-Cron once their delay has passed, and that an admin page
	 * load only schedules WP-Cron for them, rather than sending them itself.
	 *
	 * @return void
	 */
	public function testQueuedPostsAreIngested(): void {

		$due    = self::factory()->post->create();
		$future = self::factory()->post->create();

		update_post_meta( $due, self::INGEST_AFTER_META_KEY, time() - 10 );
		update_post_meta( $future, self::INGEST_AFTER_META_KEY, time() + 600 );

		wp_clear_scheduled_hook( AdminMain::INGEST_CRON_HOOK );

		$this->run_admin_bookkeeping();

		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/ingest' ), 'nothing is sent during an admin page load' );
		$this->assertLessThanOrEqual( time(), wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 'WP-Cron is scheduled for the due post' );

		self::run_ingest_cron();

		$requests = MockGistApi::requests( 'POST', 'publishers/pub-own/ingest' );

		$this->assertCount( 1, $requests );
		$this->assertSame( get_permalink( $due ), $requests[0]->body['url'] );
		$this->assertSame( '', get_post_meta( $due, self::INGEST_AFTER_META_KEY, true ) );
		$this->assertNotSame( '', get_post_meta( $due, 'gist_answers_ingest_response', true ) );
		$this->assertNotSame( '', get_post_meta( $future, self::INGEST_AFTER_META_KEY, true ) );
	}

	/**
	 * Tests that the bookkeeping only runs for logged-in users, not on AJAX requests or admin-post.php form
	 * submissions, and at most once a minute.
	 *
	 * @return void
	 */
	public function testBookkeepingIsThrottled(): void {

		global $pagenow;

		$post_id = self::factory()->post->create();
		update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );
		wp_clear_scheduled_hook( AdminMain::INGEST_CRON_HOOK );

		add_filter( 'wp_doing_ajax', '__return_true' );
		self::run_plugin_admin_init();
		remove_filter( 'wp_doing_ajax', '__return_true' );

		$user_id = get_current_user_id();
		wp_set_current_user( 0 );
		self::run_plugin_admin_init();
		wp_set_current_user( $user_id );

		$previous_pagenow = $pagenow;
		$pagenow          = 'admin-post.php'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Simulating a form submission to admin-post.php.
		self::run_plugin_admin_init();
		$pagenow = $previous_pagenow; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Restoring the global.

		$this->assertFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 'not on AJAX requests, admin-post.php, or for logged-out users' );

		self::run_plugin_admin_init();

		$this->assertNotFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ) );

		wp_clear_scheduled_hook( AdminMain::INGEST_CRON_HOOK );
		self::run_plugin_admin_init();

		$this->assertFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 'not again within a minute' );
		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/ingest' ), 'nothing is sent during an admin page load' );
	}

	/**
	 * Tests that nothing is ingested for a site without a linked publisher.
	 *
	 * @return void
	 */
	public function testNothingIsIngestedWithoutAPublisher(): void {

		delete_option( 'gist_answers_publisher' );
		set_transient( 'gist_answers_publisher_lookup_attempted', true, HOUR_IN_SECONDS );
		self::reset_plugin_state();

		$post_id = self::factory()->post->create();
		update_post_meta( $post_id, self::INGEST_AFTER_META_KEY, time() - 10 );
		wp_clear_scheduled_hook( AdminMain::INGEST_CRON_HOOK );

		$this->run_admin_bookkeeping();

		$this->assertFalse( wp_next_scheduled( AdminMain::INGEST_CRON_HOOK ), 'WP-Cron isn\'t scheduled for a site without a publisher' );

		self::run_ingest_cron();

		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/ingest' ) );
	}

	/**
	 * Ways an answer widget can appear in content.
	 *
	 * @return array<array<string>> The content.
	 */
	public static function answerWidgetContent(): array {
		return array(
			'block'           => array( '<!-- wp:gist-answers/answer /-->', 'block' ),
			'shortcode'       => array( '[gist_answers_render_widget type="answer"]', 'shortcode' ),
			'shortcode alias' => array( 'Intro. [gist_answers_render_widget type="chat" id="x"] More.', 'shortcode' ),
			'widget HTML'     => array( '<gist-chat-widget  api-key="k"></gist-chat-widget>', 'html' ),
		);
	}

	/**
	 * Tests that a page with an answer widget is flagged, and gets an answer widget created for it.
	 *
	 * @param string $content The page content.
	 * @param string $source  The expected source of the widget.
	 *
	 * @return void
	 */
	#[\PHPUnit\Framework\Attributes\DataProvider( 'answerWidgetContent' )]
	public function testPageWithAnAnswerWidgetIsFlagged( string $content, string $source ): void {

		// Only users allowed unfiltered HTML (super admins, on multisite) can save the widget's custom element;
		// WordPress strips it from anyone else's content.
		if ( 'html' === $source ) {
			$this->log_in_as_super_admin();
		}

		$page_id = $this->create_page( $content );

		$this->assertSame( '1', get_post_meta( $page_id, self::FLAG_META_KEY, true ) );

		$requests = MockGistApi::requests( 'POST', 'publishers/pub-own/widgets/chat' );

		$this->assertCount( 1, $requests );
		$this->assertSame( get_permalink( $page_id ), $requests[0]->body['targetUrl'] );
		$this->assertSame( $source, AdminMain::get_flagged_post_source( $page_id ) );

		$this->run_admin_bookkeeping();

		$this->assertContains( $page_id, AdminMain::get_flagged_post_ids() );
		$this->assertSame( '', get_post_meta( $page_id, self::FLAG_META_KEY, true ), 'the flag is cleared once processed' );
	}

	/**
	 * Tests that content that only mentions a widget, or uses a question widget, isn't flagged.
	 *
	 * @return void
	 */
	public function testPageWithoutAnAnswerWidgetIsNotFlagged(): void {

		$question = $this->create_page( '[gist_answers_render_widget type="question" id="q"] <!-- wp:gist-answers/question /-->', 'questions' );
		$plain    = $this->create_page( 'Just text.', 'plain' );

		$this->assertSame( '', get_post_meta( $question, self::FLAG_META_KEY, true ) );
		$this->assertSame( '', get_post_meta( $plain, self::FLAG_META_KEY, true ) );
		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/widgets/chat' ) );
	}

	/**
	 * Tests that an answer widget is only created once per page, and that the stored widgets are only refreshed
	 * when one is.
	 *
	 * @return void
	 */
	public function testAnswerWidgetIsCreatedOnce(): void {

		$page_id = $this->create_page( '<!-- wp:gist-answers/answer /-->' );

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers(/[^/]+)?' ), 'refreshed after creating the widget' );

		$this->run_admin_bookkeeping();
		MockGistApi::$requests = array();

		wp_update_post(
			array(
				'ID'         => $page_id,
				'post_title' => 'Updated',
			)
		);

		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/widgets/chat' ) );
		$this->assertCount( 0, MockGistApi::requests( 'GET', 'publishers(/[^/]+)?' ), 'not refreshed on an ordinary save' );
	}

	/**
	 * Tests that no answer widget is created for a page that already has one in Gist.
	 *
	 * @return void
	 */
	public function testNoAnswerWidgetIsCreatedWhenOneExists(): void {

		$this->link_publisher(
			MockGistApi::publisher(
				'pub-own',
				get_bloginfo( 'name' ),
				'example.org',
				array( 'widgets' => array( 'chat-widgets' => array( 'chat-widget-1' => array( 'targetUrl' => home_url( '/answers/' ) ) ) ) )
			)
		);
		MockGistApi::$requests = array();

		$this->create_page( '<!-- wp:gist-answers/answer /-->' );

		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/widgets/chat' ) );
	}

	/**
	 * Tests that saving a page with an answer widget on a site without a publisher doesn't fail.
	 *
	 * @return void
	 */
	public function testSavingWithoutAPublisherDoesNotFail(): void {

		delete_option( 'gist_answers_publisher' );
		set_transient( 'gist_answers_publisher_lookup_attempted', true, HOUR_IN_SECONDS );
		self::reset_plugin_state();

		$page_id = $this->create_page( '<!-- wp:gist-answers/answer /-->' );

		$this->assertGreaterThan( 0, $page_id );
		$this->assertCount( 0, MockGistApi::requests( 'POST', '.+/widgets/chat' ) );
	}

	/**
	 * Tests that removing a page's answer widget unflags it.
	 *
	 * @return void
	 */
	public function testRemovingTheWidgetUnflagsThePage(): void {

		$page_id = $this->create_page( '<!-- wp:gist-answers/answer /-->' );
		$this->run_admin_bookkeeping();

		wp_update_post(
			array(
				'ID'           => $page_id,
				'post_content' => 'No widget any more.',
			)
		);

		$this->assertSame( '1', get_post_meta( $page_id, self::UNFLAG_META_KEY, true ) );

		$this->run_admin_bookkeeping();

		$this->assertNotContains( $page_id, AdminMain::get_flagged_post_ids() );
		$this->assertSame( '', get_post_meta( $page_id, self::UNFLAG_META_KEY, true ) );
	}

	/**
	 * Tests the reported race: removing a page's widget and adding it back before the bookkeeping runs must leave
	 * the page flagged (not stuck out of the list with both meta keys set).
	 *
	 * @return void
	 */
	public function testRemovingAndReAddingTheWidgetKeepsThePageFlagged(): void {

		$page_id = $this->create_page( '<!-- wp:gist-answers/answer /-->' );
		$this->run_admin_bookkeeping();

		wp_update_post(
			array(
				'ID'           => $page_id,
				'post_content' => 'Removed.',
			)
		);
		wp_update_post(
			array(
				'ID'           => $page_id,
				'post_content' => '<!-- wp:gist-answers/answer /-->',
			)
		);

		$this->assertSame( '', get_post_meta( $page_id, self::UNFLAG_META_KEY, true ), 'the later save cancels the unflag' );

		$this->run_admin_bookkeeping();

		$this->assertContains( $page_id, AdminMain::get_flagged_post_ids() );
		$this->assertSame( '', get_post_meta( $page_id, self::FLAG_META_KEY, true ) );
		$this->assertSame( '', get_post_meta( $page_id, self::UNFLAG_META_KEY, true ) );

		// And the other way round: removed after the page was unflagged, then added back.
		wp_update_post(
			array(
				'ID'           => $page_id,
				'post_content' => 'Removed again.',
			)
		);
		$this->run_admin_bookkeeping();
		$this->assertNotContains( $page_id, AdminMain::get_flagged_post_ids() );

		wp_update_post(
			array(
				'ID'           => $page_id,
				'post_content' => '<!-- wp:gist-answers/answer /-->',
			)
		);
		$this->run_admin_bookkeeping();

		$this->assertContains( $page_id, AdminMain::get_flagged_post_ids() );
	}

	/**
	 * Tests that revisions and autosaves are ignored.
	 *
	 * @return void
	 */
	public function testRevisionsAreIgnored(): void {

		$page_id = $this->create_page( 'Draft text.' );

		$revision_id = wp_save_post_revision( $page_id );

		if ( $revision_id ) {
			$this->assertSame( '', get_post_meta( $revision_id, self::FLAG_META_KEY, true ) );
			$this->assertSame( '', get_post_meta( $revision_id, self::INGEST_AFTER_META_KEY, true ) );
		} else {
			$this->assertNull( $revision_id );
		}
	}
}
