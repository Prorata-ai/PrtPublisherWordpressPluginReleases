<?php
/**
 * Tests that render the admin screens and the network hub in each connection state.
 *
 * @package GistAnswers
 */

use GistAnswers\Admin\MenuItems\Answers;
use GistAnswers\Admin\MenuItems\ContentUsage;
use GistAnswers\Admin\MenuItems\Dashboard;
use GistAnswers\Admin\MenuItems\MenuSubitem;
use GistAnswers\Admin\MenuItems\Questions;
use GistAnswers\Admin\MenuItems\Revenue;
use GistAnswers\Admin\MenuItems\ToolsOptions;
use GistAnswers\Admin\MenuItems\WebsiteSettings;
use GistAnswers\Admin\MenuItems\Widgets;
use GistAnswers\Admin\NetworkMenu;
use GistAnswers\Model\GistSite;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests that render the admin screens and the network hub in each connection state.
 */
final class AdminScreensTest extends TestCase {

	/**
	 * Set up each test: log in as an administrator (a super admin on multisite), and fail on any PHP warning or
	 * notice raised by the plugin's own code while rendering.
	 *
	 * @return void
	 */
	protected function setUp(): void {

		parent::setUp();

		if ( is_multisite() ) {
			$this->log_in_as_super_admin();
		} else {
			$this->log_in_as( 'administrator' );
		}

		set_error_handler( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_set_error_handler -- Surfacing the plugin's own PHP warnings as test failures.
			function ( int $level, string $message, string $file, int $line ): bool {

				if ( str_starts_with( $file, GIST_ANSWERS_PLUGIN_DIR ) && ! str_contains( $file, '/vendor/' ) ) {
					throw new ErrorException( esc_html( $message ), 0, intval( $level ), esc_html( $file ), intval( $line ) );
				}

				return false;
			}
		);
	}

	/**
	 * Tear down each test.
	 *
	 * @return void
	 */
	protected function tearDown(): void {

		restore_error_handler();

		parent::tearDown();
	}

	/**
	 * Render an admin screen.
	 *
	 * @param MenuSubitem|NetworkMenu $screen The screen.
	 * @param array<string, string>   $query  The query string arguments.
	 *
	 * @return string The rendered HTML.
	 */
	private function render( MenuSubitem|NetworkMenu $screen, array $query = array() ): string {

		$_GET = $query;

		ob_start();

		if ( $screen instanceof NetworkMenu ) {
			$screen->render_network_menu();
		} else {
			$screen->render_submenu_page();
		}

		return strval( ob_get_clean() );
	}

	/**
	 * Get the visible text of the given element classes in the rendered HTML.
	 *
	 * @param string $html  The rendered HTML.
	 * @param string $xpath The XPath query.
	 *
	 * @return array<string> The trimmed text of each matching element.
	 */
	private static function texts( string $html, string $xpath ): array {

		$document = new DOMDocument();

		libxml_use_internal_errors( true );
		$document->loadHTML( '<?xml encoding="utf-8"?>' . $html );
		libxml_clear_errors();

		$texts = array();

		foreach ( ( new DOMXPath( $document ) )->query( $xpath ) as $node ) {
			$texts[] = trim( preg_replace( '/\s+/', ' ', $node->textContent ) ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOMNode property.
		}

		return $texts;
	}

	/**
	 * Link the current site to a publisher, optionally with a widget.
	 *
	 * @param bool $with_widget Whether the publisher has a widget.
	 * @param int  $blog_id     Optional blog ID.
	 *
	 * @return void
	 */
	private function activate( bool $with_widget = false, int $blog_id = 0 ): void {

		$config = $with_widget ? array( 'widgets' => array( 'question-bar-widgets' => array( 'question-bar-widget-1' => array( 'name' => 'Bar' ) ) ) ) : array();

		$name = $blog_id ? get_blog_option( $blog_id, 'blogname' ) : get_bloginfo( 'name' );

		$this->link_publisher( MockGistApi::publisher( 'pub-' . ( $blog_id ? $blog_id : 'own' ), $name, 'example.org', $config ), $blog_id );
	}

	/**
	 * Every screen that embeds a CMS page.
	 *
	 * @return array<string, array<string>>
	 */
	public static function iframeScreens(): array {
		return array(
			'Answers'          => array( Answers::class, 'gistanswers/channel' ),
			'Content Usage'    => array( ContentUsage::class, 'analytics/publicationdetails' ),
			'Questions'        => array( Questions::class, 'suggested-questions/pub-own' ),
			'Revenue'          => array( Revenue::class, 'revenue/partnersummary' ),
			'Website Settings' => array( WebsiteSettings::class, 'website_settings' ),
			'Widgets'          => array( Widgets::class, 'widgets/site/pub-own' ),
		);
	}

	/**
	 * Tests the dashboard before connecting: the welcome title and the token form.
	 *
	 * @return void
	 */
	public function testDashboardBeforeConnecting(): void {

		$this->require_single_site();

		$html = $this->render( new Dashboard( false ) );

		$this->assertContains( 'Welcome to Gist Answers', self::texts( $html, '//h1|//h2' ) );
		$this->assertStringContainsString( 'name="action" value="gist_answers_connect"', $html );
		$this->assertStringContainsString( 'data-show-wizard="1"', $html );
		$this->assertStringContainsString( 'id="gist-answers-activation-modal"', $html );
	}

	/**
	 * Tests the dashboard's site card in each activation state.
	 *
	 * @return void
	 */
	public function testDashboardSiteCard(): void {

		$this->require_single_site();

		$this->connect();

		$html = $this->render( new Dashboard( false ) );

		$this->assertContains( 'Dashboard', self::texts( $html, '//h1|//h2' ) );
		$this->assertSame( array( 'Test Blog' ), self::texts( $html, '//tr[contains(@class, "gist-answers-admin-site-card")]//a' ) );
		$this->assertSame( array( 'Activate website' ), self::texts( $html, '//button[contains(@class, "gist-answers-admin-site-card-button")]' ) );
		$this->assertStringContainsString( 'gist-answers-button-with-submission-animation', $html );
		$this->assertStringContainsString( 'data-show-wizard="0"', $html, 'the connection wizard is hidden once connected' );
		$this->assertStringNotContainsString( 'type="checkbox"', $html, 'there is no ingestion toggle before activation' );
		$this->assertStringNotContainsString( 'gist-answers-network-hub-refresh', $html, 'there is no status to refresh before activation' );

		$this->activate();
		self::reset_plugin_state();

		$html = $this->render( new Dashboard( false ) );

		$this->assertSame( array( 'Set up widgets' ), self::texts( $html, '//button[contains(@class, "gist-answers-admin-site-card-button")]' ) );
		$this->assertStringContainsString( 'openWidgetsPopupIframe(event, &#039;list&#039;)', $html, 'the button opens the widgets list tab' );
		$this->assertStringContainsString( 'data-publisher-id="pub-own"', $html );
		$this->assertStringContainsString( 'type="checkbox"', $html );
		$this->assertSame( array( '' ), self::texts( $html, '//div[contains(@class, "gist-answers-single-site-list-controls")]/button[contains(@class, "gist-answers-network-hub-refresh")]' ), 'the refresh button is in the controls above the site card, as on the network hub' );

		$this->activate( true );
		self::reset_plugin_state();

		$html = $this->render( new Dashboard( false ) );

		$this->assertSame( array( 'View widgets' ), self::texts( $html, '//button[contains(@class, "gist-answers-admin-site-card-button")]' ) );
	}

	/**
	 * Tests that a failed activation shows its error once.
	 *
	 * @return void
	 */
	public function testDashboardActivationError(): void {

		$this->require_single_site();

		$this->connect();

		GistSite::store_site_activation_errors( array( 'That name is <b>taken</b>.' ), (object) array() );

		$html = $this->render( new Dashboard( false ), array( 'activated' => '-1' ) );

		$this->assertSame( array( 'That name is taken.' ), self::texts( $html, '//div[contains(@class, "gist-answers-connection-wizard-error")]/span' ) );

		$html = $this->render( new Dashboard( false ), array( 'activated' => '-1' ) );

		$this->assertStringNotContainsString( 'That name is', $html );
	}

	/**
	 * Tests that an embedded CMS screen shows the CMS page once activated.
	 *
	 * @param string $class_name The screen's class.
	 * @param string $subpath    The CMS page's path.
	 *
	 * @return void
	 */
	#[\PHPUnit\Framework\Attributes\DataProvider( 'iframeScreens' )]
	public function testIframeScreenOnceActivated( string $class_name, string $subpath ): void {

		$this->connect();
		$this->activate();

		$html = $this->render( new $class_name( true ) );

		$sources = self::texts( $html, '//iframe[contains(@class, "gist-answers-admin-menu-iframe")]/@src' );

		$this->assertCount( 1, $sources );
		$this->assertStringContainsString( '/' . $subpath . '?embed=', $sources[0] );
		$this->assertStringNotContainsString( 'gist-answers-connection-wizard"', $html );
	}

	/**
	 * Tests that an embedded CMS screen points to the dashboard before activation, without requesting an embed ticket.
	 *
	 * @param string $class_name The screen's class.
	 *
	 * @return void
	 */
	#[\PHPUnit\Framework\Attributes\DataProvider( 'iframeScreens' )]
	public function testIframeScreenBeforeActivation( string $class_name ): void {

		$this->connect();

		$html = $this->render( new $class_name( true ) );

		$this->assertStringNotContainsString( '<iframe class="gist-answers-admin-menu-iframe"', $html );
		$this->assertStringContainsString( 'has not been activated', $html );
		$this->assertSame( array(), MockGistApi::requests( 'POST', '.*embed' ) );
	}

	/**
	 * Tests that the Tools & Options screen renders, with the Danger Zone.
	 *
	 * @return void
	 */
	public function testToolsOptionsScreen(): void {

		$this->connect();

		$html = $this->render( new ToolsOptions( true ) );

		$this->assertStringContainsString( 'name="action" value="gist_answers_save_danger_zone_options"', $html );
	}

	/**
	 * Create subsites that the current user belongs to.
	 *
	 * @param array<string> $names The sites' names.
	 *
	 * @return array<string, int> The blog IDs, by name.
	 */
	private function create_sites( array $names ): array {

		$blog_ids = array();

		foreach ( $names as $index => $name ) {

			$blog_id = self::factory()->blog->create(
				array(
					'domain' => "site{$index}.example.org",
					'title'  => $name,
				)
			);

			add_user_to_blog( $blog_id, get_current_user_id(), 'administrator' );

			$blog_ids[ $name ] = $blog_id;
		}

		return $blog_ids;
	}

	/**
	 * Tests the network hub before connecting.
	 *
	 * @return void
	 */
	public function testNetworkHubBeforeConnecting(): void {

		$this->require_multisite();

		$html = $this->render( new NetworkMenu() );

		$this->assertContains( 'Welcome to Gist Answers', self::texts( $html, '//h1|//h2' ) );
		$this->assertStringContainsString( 'name="action" value="gist_answers_connect"', $html );
	}

	/**
	 * Tests the network hub's site list: sorted by title, without status headers until a site is activated.
	 *
	 * @return void
	 */
	public function testNetworkHubSiteList(): void {

		$this->require_multisite();

		$this->connect();

		$this->create_sites( array( 'charlie', 'Alpha', 'Bravo' ) );

		$html = $this->render( new NetworkMenu() );

		$this->assertContains( 'Network Dashboard', self::texts( $html, '//h1|//h2' ) );
		$this->assertSame( array( 'Alpha', 'Bravo', 'charlie', 'Test Blog' ), self::texts( $html, '//tr[contains(@class, "gist-answers-admin-site-card")]//a' ) );
		$this->assertSame( array( 'Site title', '', '', '' ), self::texts( $html, '//table[contains(@class, "gist-answers-network-hub-list")]//th' ) );
		$this->assertStringContainsString( 'target="_blank"', $html, 'sites open in a new tab from the network hub' );
		$this->assertStringNotContainsString( 'gist-answers-network-hub-refresh', $html, 'there are no statuses to refresh' );

		$html = $this->render( new NetworkMenu(), array( 'sort-column' => 'title-desc' ) );

		$this->assertSame( array( 'Test Blog', 'charlie', 'Bravo', 'Alpha' ), self::texts( $html, '//tr[contains(@class, "gist-answers-admin-site-card")]//a' ) );
		$this->assertStringContainsString( 'gist-answers-network-hub-sortable-selected-inverted', $html );
	}

	/**
	 * Tests that the status and ingestion headers appear once any listed site is activated.
	 *
	 * @return void
	 */
	public function testNetworkHubHeadersWithActivatedSite(): void {

		$this->require_multisite();

		$this->connect();

		$blog_ids = $this->create_sites( array( 'Alpha' ) );

		$this->activate( false, $blog_ids['Alpha'] );

		$html = $this->render( new NetworkMenu() );

		$headers = self::texts( $html, '//table[contains(@class, "gist-answers-network-hub-list")]//th' );

		$this->assertSame( array( 'Site title', 'Status' ), array_slice( $headers, 0, 2 ) );
		$this->assertStringStartsWith( 'Content ingestion', $headers[2] );
		$this->assertSame( '', $headers[3] );
		$this->assertSame( array( '' ), self::texts( $html, '//div[contains(@class, "gist-answers-network-hub-list-controls")]/button[contains(@class, "gist-answers-network-hub-refresh")]' ), 'the refresh button is in the list controls' );
		$this->assertSame( array( '' ), self::texts( $html, '//button[contains(@class, "gist-answers-network-hub-refresh")]' ), 'the site cards have no refresh buttons of their own' );
	}

	/**
	 * Tests searching the network hub's site list by title.
	 *
	 * @return void
	 */
	public function testNetworkHubSearch(): void {

		$this->require_multisite();

		$this->connect();

		$this->create_sites( array( 'News Daily', 'Sports Weekly', 'The News-Times' ) );

		$html = $this->render( new NetworkMenu(), array( 'title-contains' => 'news' ) );

		$this->assertSame( array( 'News Daily', 'The News-Times' ), self::texts( $html, '//tr[contains(@class, "gist-answers-admin-site-card")]//a' ) );

		$html = $this->render( new NetworkMenu(), array( 'title-contains' => 'nothing like it' ) );

		$this->assertStringContainsString( 'No sites were found matching your search criteria.', $html );
	}

	/**
	 * Tests paginating the network hub's site list, which only loads the sites on the page shown.
	 *
	 * @return void
	 */
	public function testNetworkHubPagination(): void {

		$this->require_multisite();

		$this->connect();

		$blog_ids = $this->create_sites( array( 'A1', 'A2', 'A3', 'A4', 'A5' ) );

		add_filter( 'gist_answers_network_sites_per_page', fn () => 2 );

		self::reset_plugin_state();

		$html = $this->render( new NetworkMenu(), array( 'current-page' => '2' ) );

		$this->assertSame( array( 'A3', 'A4' ), self::texts( $html, '//tr[contains(@class, "gist-answers-admin-site-card")]//a' ) );
		$this->assertStringContainsString( 'gist-answers-network-hub-pagination', $html );

		$loaded = array_keys( self::get_static( GistSite::class, 'cached_sites' ) );

		$this->assertContains( $blog_ids['A3'], $loaded );
		$this->assertNotContains( $blog_ids['A1'], $loaded, 'sites on other pages are not loaded' );
		$this->assertNotContains( $blog_ids['A5'], $loaded );

		$html = $this->render( new NetworkMenu(), array( 'current-page' => '99' ) );

		$this->assertSame( array( 'A5', 'Test Blog' ), self::texts( $html, '//tr[contains(@class, "gist-answers-admin-site-card")]//a' ), 'a page past the end shows the last page' );
	}

	/**
	 * Tests the network hub for a user without any sites.
	 *
	 * @return void
	 */
	public function testNetworkHubWithoutSites(): void {

		$this->require_multisite();

		$this->connect();

		remove_user_from_blog( get_current_user_id(), get_current_blog_id() );

		$html = $this->render( new NetworkMenu() );

		$this->assertStringContainsString( 'You do not have access to any public sites on this network.', $html );
		$this->assertStringNotContainsString( 'gist-answers-network-hub-list"', $html );
	}
}
