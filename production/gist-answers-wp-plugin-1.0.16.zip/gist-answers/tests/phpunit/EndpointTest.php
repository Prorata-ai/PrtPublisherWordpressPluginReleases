<?php
/**
 * Tests for the Gist Answers API request layer (Endpoint and its subclasses), against the mock API.
 *
 * @package GistAnswers
 */

use GistAnswers\API\Delete\Publishers\Crawl as StopCrawl;
use GistAnswers\API\Credentials;
use GistAnswers\API\Endpoint;
use GistAnswers\API\Get\Categories;
use GistAnswers\API\Get\PublisherGroups;
use GistAnswers\API\Get\Publishers;
use GistAnswers\API\Get\Publishers\Sites;
use GistAnswers\API\Get\Publishers\Widgets\HTML;
use GistAnswers\API\Post\Embed;
use GistAnswers\API\Post\Publishers as CreatePublisher;
use GistAnswers\API\Post\Publishers\Ingest;
use GistAnswers\API\Post\Publishers\Widgets\Chat;
use GistAnswers\API\Put\Publishers\Crawl as StartCrawl;
use GistAnswers\Tests\MockGistApi;
use GistAnswers\Tests\TestCase;

/**
 * Tests for the Gist Answers API request layer (Endpoint and its subclasses), against the mock API.
 */
final class EndpointTest extends TestCase {

	/**
	 * Store an API token, as requests are only sent with one.
	 *
	 * @return void
	 */
	protected function setUp(): void {

		parent::setUp();

		Credentials::store_api_token( self::TOKEN );
	}

	/**
	 * Tests that without an API token, a request isn't sent, and is reported as rejected.
	 *
	 * @return void
	 */
	public function testRequestsAreNotSentWithoutAToken(): void {

		Credentials::delete_api_token();

		$response = ( new Categories() )->response();

		$this->assertSame( 401, $response->code );
		$this->assertCount( 0, MockGistApi::requests() );
	}

	/**
	 * Tests that a GET request sends its parameters in the query string.
	 *
	 * @return void
	 */
	public function testGetRequestSendsParametersInTheQueryString(): void {

		new Publishers( '', 10, 20, 'news' );

		$request = MockGistApi::requests( 'GET', 'publishers' )[0];

		$this->assertSame(
			array(
				'offset' => '10',
				'limit'  => '20',
				'search' => 'news',
			),
			$request->query
		);
		$this->assertNull( $request->body );
	}

	/**
	 * Tests that the route with the most matching placeholders is used, with the placeholders filled in.
	 *
	 * @return void
	 */
	public function testPlaceholdersAreFilledIntoTheMostSpecificRoute(): void {

		new Sites( 'pub-1' );
		new Sites( 'pub-1', 'site-2' );
		new PublisherGroups( 'pg-1' );

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-1/sites' ) );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-1/sites/site-2' ) );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publisher_groups/pg-1' ) );

		$this->assertSame( array(), MockGistApi::requests( 'GET', 'publishers/pub-1/sites' )[0]->query, 'placeholders are not repeated in the query string' );
	}

	/**
	 * Tests that a POST request sends its parameters as a JSON body.
	 *
	 * @return void
	 */
	public function testPostRequestSendsAJsonBody(): void {

		new Ingest( 'pub-1', 'https://example.org/a-post/' );

		$request = MockGistApi::requests( 'POST', 'publishers/pub-1/ingest' )[0];

		$this->assertSame( array( 'url' => 'https://example.org/a-post/' ), $request->body );
		$this->assertSame( 'application/json', $request->headers['Content-Type'] ?? null );
	}

	/**
	 * Tests the request each endpoint class makes.
	 *
	 * @return void
	 */
	public function testEachEndpointUsesItsRoute(): void {

		new Categories();
		new Embed( array( 'publisher_id' => 'pub-1' ) );
		new HTML( 'pub-1', 'widget-1' );
		new Chat( 'pub-1', 'https://example.org/answers/' );
		new StartCrawl( 'pub-1' );
		new StopCrawl( 'pub-1' );

		$this->assertCount( 1, MockGistApi::requests( 'GET', 'categories' ) );
		$this->assertCount( 1, MockGistApi::requests( 'POST', 'embed' ) );
		$this->assertCount( 1, MockGistApi::requests( 'GET', 'publishers/pub-1/widgets/widget-1/html' ) );
		$this->assertCount( 1, MockGistApi::requests( 'POST', 'publishers/pub-1/widgets/chat' ) );
		$this->assertCount( 1, MockGistApi::requests( 'PUT', 'publishers/pub-1/crawl' ) );
		$this->assertCount( 1, MockGistApi::requests( 'DELETE', 'publishers/pub-1/crawl' ) );

		$this->assertSame( array( 'targetUrl' => 'https://example.org/answers/' ), MockGistApi::requests( 'POST', 'publishers/pub-1/widgets/chat' )[0]->body );
	}

	/**
	 * Tests the body sent when a publisher (website) is created.
	 *
	 * @return void
	 */
	public function testCreatingAPublisherSendsItsDetails(): void {

		new CreatePublisher( 'Site', 'Tagline', 'example.org', 'Unknown', 'cat-news', 'https://example.org/wp-json/wp/v2/posts', 'WPV2', 'https://example.org/', 'https://staging.example.org/' );

		$body = MockGistApi::requests( 'POST', 'publishers' )[0]->body;

		$this->assertSame( 'Site', $body['publisher']['name'] );
		$this->assertSame( 'example.org', $body['publisher']['config']['domain'] );
		$this->assertSame( 'https://example.org/', $body['publisher']['config']['home_page_url'] );
		$this->assertSame( 'https://staging.example.org/', $body['publisher']['config']['dev'] );
		$this->assertSame( 'https://example.org/wp-json/wp/v2/posts', $body['site']['url'] );
		$this->assertSame( 'WPV2', $body['site']['type'] );
	}

	/**
	 * Tests that the optional home page and dev URLs are left out when empty.
	 *
	 * @return void
	 */
	public function testCreatingAPublisherLeavesOutEmptyOptionalUrls(): void {

		new CreatePublisher( 'Site', 'Tagline', 'example.org', 'Unknown', 'cat-news', 'https://example.org/wp-json/wp/v2/posts', 'WPV2' );

		$config = MockGistApi::requests( 'POST', 'publishers' )[0]->body['publisher']['config'];

		$this->assertArrayNotHasKey( 'home_page_url', $config );
		$this->assertArrayNotHasKey( 'dev', $config );
	}

	/**
	 * Tests that every request identifies the site and carries the API token.
	 *
	 * @return void
	 */
	public function testRequestsCarryTheTokenAndOrigin(): void {

		$this->connect();

		new Categories();

		$headers = MockGistApi::requests( 'GET', 'categories' )[0]->headers;

		$this->assertSame( self::TOKEN, $headers['X-API-Token'] ?? null );
		$this->assertSame( get_home_url(), $headers['X-CMS-Origin'] ?? null );
	}

	/**
	 * Tests that requests have a short explicit timeout, which can be filtered.
	 *
	 * @return void
	 */
	public function testRequestsHaveAFilterableTimeout(): void {

		new Categories();

		$this->assertSame( 2, MockGistApi::requests()[0]->timeout, 'front-end requests time out after 2 seconds' );

		add_filter( 'gist_answers_api_timeout', fn () => 7 );

		new Categories();

		$this->assertSame( 3, MockGistApi::requests()[1]->timeout, 'a front-end request may not wait longer than the request budget' );

		add_filter( 'gist_answers_front_end_request_budget', fn () => 10 );

		new Categories();

		$this->assertSame( 7, MockGistApi::requests()[2]->timeout );
	}

	/**
	 * Tests that once a front-end page has used up its request budget, further requests fail without being sent.
	 *
	 * @return void
	 */
	public function testFrontEndRequestBudgetIsEnforced(): void {

		$this->connect();

		add_filter( 'gist_answers_front_end_request_budget', fn () => 0 );

		$response = ( new Categories() )->response();

		$this->assertSame( 999, $response->code );
		$this->assertStringContainsString( 'used up', $response->data->error );
		$this->assertCount( 0, MockGistApi::requests() );
	}

	/**
	 * Tests that requests, which carry the API token, never follow redirects and refuse unsafe destinations.
	 *
	 * @return void
	 */
	public function testRequestsDoNotFollowRedirects(): void {

		$this->connect();

		MockGistApi::on( 'GET', 'categories', 302, '' );

		$response = ( new Categories() )->response();

		$args = MockGistApi::requests( 'GET', 'categories' )[0]->args;

		$this->assertSame( 0, $args['redirection'] ?? null );
		$this->assertTrue( $args['reject_unsafe_urls'] ?? null );
		$this->assertSame( 302, $response->code, 'a redirect is a failed request' );
		$this->assertCount( 1, MockGistApi::requests(), 'and is not followed' );
	}

	/**
	 * Tests that a response larger than the endpoint's limit is rejected, and that the limit reaches the transport.
	 *
	 * @return void
	 */
	public function testOversizedResponsesAreRejected(): void {

		$this->connect();

		MockGistApi::on( 'GET', 'categories', 200, str_repeat( ' ', MB_IN_BYTES + 1 ) );

		$response = ( new Categories() )->response();

		$this->assertSame( 999, $response->code );
		$this->assertStringContainsString( 'larger than', $response->data->error );
		$this->assertSame( MB_IN_BYTES + 1, MockGistApi::requests( 'GET', 'categories' )[0]->args['limit_response_size'] ?? null );
	}

	/**
	 * Tests that the response is decoded.
	 *
	 * @return void
	 */
	public function testResponseIsDecoded(): void {

		MockGistApi::on( 'GET', 'categories', 200, array( array( 'id' => 'cat-1' ) ) );

		$response = ( new Categories() )->response();

		$this->assertSame( 200, $response->code );
		$this->assertSame( 'cat-1', $response->data[0]->id );
		$this->assertGreaterThan( 0, $response->time );
	}

	/**
	 * Tests that a request that couldn't reach the API is reported with code 999 and a JSON error.
	 *
	 * @return void
	 */
	public function testUnreachableApiIsReportedAsCode999(): void {

		MockGistApi::unreachable( 'GET', 'categories' );

		$response = ( new Categories() )->response();

		$this->assertSame( 999, $response->code );
		$this->assertStringContainsString( 'timed out', $response->data->error );
	}

	/**
	 * Tests that the last response is kept for later inspection, and can be reset.
	 *
	 * @return void
	 */
	public function testLastResponseIsKept(): void {

		$this->assertSame( 0, Endpoint::get_last_response()->code );

		MockGistApi::on( 'GET', 'categories', 503, array( 'error' => 'Down' ) );
		new Categories();

		$this->assertSame( 503, Endpoint::get_last_response()->code );

		Endpoint::reset_last_response_if_valid();
		$this->assertSame( 503, Endpoint::get_last_response()->code, 'an error response is kept' );

		Endpoint::reset_last_response();
		$this->assertSame( 0, Endpoint::get_last_response()->code );
	}

	/**
	 * Tests that a `Retry-After` header is read, in seconds or as an HTTP date, and capped at a day.
	 *
	 * @return void
	 */
	public function testRetryAfterIsRead(): void {

		$http_date = gmdate( 'D, d M Y H:i:s', time() + 600 ) . ' GMT';

		$cases = array(
			array( '120', 120 ),
			array( $http_date, 600 ),
			array( '999999', DAY_IN_SECONDS ),
			array( 'soon', 0 ),
			array( '', 0 ),
		);

		foreach ( $cases as [ $header, $expected ] ) {

			MockGistApi::on( 'GET', 'categories', fn () => array( 429, array( 'error' => 'Slow down' ), array( 'retry-after' => $header ) ) );

			$this->assertEqualsWithDelta( $expected, ( new Categories() )->response()->retry_after, 2, $header );
		}
	}

	/**
	 * Tests that a token is valid only if the API returns a publisher group for it.
	 *
	 * @return void
	 */
	public function testTokenValidation(): void {

		$this->assertTrue( Endpoint::validate_api_token( self::TOKEN ) );
		$this->assertSame( self::TOKEN, MockGistApi::requests( 'GET', 'publisher_groups' )[0]->headers['X-API-Token'] );

		MockGistApi::on( 'GET', 'publisher_groups', 401, array( 'error' => 'Unauthorized' ) );

		$this->assertFalse( Endpoint::validate_api_token( 'sk_wrong' ) );
	}

	/**
	 * Tests that an invalid HTTP method, a missing parameter, or an unknown parameter are rejected before any request.
	 *
	 * @return void
	 */
	public function testInvalidRequestsAreRejected(): void {

		$cases = array(
			'missing parameter' => fn () => new class( 'GET', 'categories', array() ) extends Endpoint {
				/**
				 * Required parameters.
				 *
				 * @var array<mixed>
				 */
				protected array $required_params = array( 'id' );
			},
			'unknown parameter' => fn () => new class( 'GET', 'categories', array( 'surprise' => 1 ) ) extends Endpoint {
			},
			'empty parameter'   => fn () => new class( 'GET', 'categories', array( 'id' => '' ) ) extends Endpoint {
				/**
				 * Required parameters.
				 *
				 * @var array<mixed>
				 */
				protected array $required_params = array( 'id' );
			},
			'invalid method'    => fn () => new class( 'FETCH', 'categories', array() ) extends Endpoint {
			},
		);

		foreach ( $cases as $label => $make_request ) {
			try {
				$make_request();
				$this->fail( "No exception for: $label" );
			} catch ( InvalidArgumentException $e ) {
				$this->assertNotEmpty( $e->getMessage(), $label );
			}
		}

		$this->assertCount( 0, MockGistApi::requests() );
	}

	/**
	 * Tests that, when response logging is on, responses go to the PHP error log with credentials redacted.
	 *
	 * @return void
	 */
	public function testLoggedResponsesHaveCredentialsRedacted(): void {

		$this->set_network_option( 'gist_answers_log_api_responses', true );

		$logged = array();

		add_filter(
			'gist_answers_error_log',
			function ( $message ) use ( &$logged ) {
				$logged[] = $message;
				return $message;
			}
		);

		require_once ABSPATH . 'wp-admin/includes/file.php';

		$log_file = wp_tempnam( 'gist-answers-log' );
		$previous = ini_set( 'error_log', $log_file ); // phpcs:ignore WordPress.PHP.IniSet.Risky -- Capturing the PHP error log for this test.

		try {
			MockGistApi::on(
				'POST',
				'embed',
				200,
				array(
					'ticket'       => 'secret-ticket-value',
					'access_token' => 'secret-token-value',
					'embed_ticket' => 'secret-embed-"quoted"-value',
					'iframe_url'   => 'https://cms.example.test/pages/widgets?embed=secret-embed-in-url&theme=dark',
					'name'         => 'Visible',
				)
			);

			new Embed( array( 'publisher_id' => 'pub-1' ) );
		} finally {
			ini_set( 'error_log', $previous ); // phpcs:ignore WordPress.PHP.IniSet.Risky -- Restoring the PHP error log.
		}

		$this->assertCount( 1, $logged );
		$this->assertStringContainsString( 'Visible', $logged[0] );
		$this->assertStringContainsString( '[redacted]', $logged[0] );
		$this->assertStringNotContainsString( 'secret-ticket-value', $logged[0] );
		$this->assertStringNotContainsString( 'secret-token-value', $logged[0] );
		$this->assertStringNotContainsString( 'quoted', $logged[0], 'a value with escaped quotes is redacted whole' );
		$this->assertStringNotContainsString( 'secret-embed-in-url', $logged[0], 'an embed ticket in a URL is redacted' );
		$this->assertStringContainsString( 'theme=dark', $logged[0] );

		$this->assertStringContainsString( 'Gist Answers API response', (string) file_get_contents( $log_file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- Reading the local test log file.
		$this->assertFileDoesNotExist( GIST_ANSWERS_PLUGIN_DIR . 'api-responses.log', 'nothing is written into the plugin folder' );

		wp_delete_file( $log_file );
	}

	/**
	 * Tests that nothing is logged when response logging is off (the default).
	 *
	 * @return void
	 */
	public function testNothingIsLoggedByDefault(): void {

		$logged = 0;

		add_filter(
			'gist_answers_error_log',
			function ( $message ) use ( &$logged ) {
				++$logged;
				return $message;
			}
		);

		new Categories();

		$this->assertSame( 0, $logged );
	}

	/**
	 * Tests that each endpoint fires its action with the response, so callers can hook it.
	 *
	 * @return void
	 */
	public function testEndpointsFireTheirActions(): void {

		$fired = array();

		foreach ( array( 'gist_answers_get_categories', 'gist_answers_post_publishers_ingest', 'gist_answers_get_publishers_sites' ) as $action ) {
			add_action(
				$action,
				function () use ( $action, &$fired ) {
					$fired[] = $action;
				}
			);
		}

		new Categories();
		new Ingest( 'pub-1', 'https://example.org/p/' );
		new Sites( 'pub-1' );

		$this->assertSame( array( 'gist_answers_get_categories', 'gist_answers_post_publishers_ingest', 'gist_answers_get_publishers_sites' ), $fired );
	}
}
