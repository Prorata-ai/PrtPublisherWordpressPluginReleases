<?php
/**
 * Class for testing the WordPress VIP runtime config handling.
 *
 * @package GistAnswers
 */

use GistAnswers\API\Credentials;
use GistAnswers\Plugin\Config;

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\PreserveGlobalState;
use PHPUnit\Framework\Attributes\RunInSeparateProcess;
use GistAnswers\Tests\TestCase;

/**
 * Class for testing the WordPress VIP runtime config handling.
 *
 * The base test case rolls back each test's database writes, including the tokens stored by the tests that run in
 * their own process (which would otherwise persist and leak into later tests).
 */
final class ConfigTest extends TestCase {

	private const MOCK_VIP_TOKEN = 'mock-vip-token';

	/**
	 * Tests that a complete config is ready and exposes its values.
	 *
	 * @return void
	 */
	public function testValidConfigIsReady(): void {

		$config = new Config( array( 'api_token' => self::MOCK_VIP_TOKEN ) );

		$this->assertTrue( $config->is_available() );
		$this->assertTrue( $config->is_ready() );
		$this->assertSame( array(), $config->missing_fields() );
		$this->assertSame( self::MOCK_VIP_TOKEN, $config->get( 'api_token' ) );
		$this->assertSame( 'fallback', $config->get( 'not_a_field', 'fallback' ) );
	}

	/**
	 * Configs that are arrays but lack a usable api_token.
	 *
	 * @return array<string, array<mixed>>
	 */
	public static function incompleteConfigs(): array {
		return array(
			'missing api_token'    => array( array() ),
			'empty api_token'      => array( array( 'api_token' => '' ) ),
			'whitespace api_token' => array( array( 'api_token' => "  \t" ) ),
			'non-string api_token' => array( array( 'api_token' => 12345 ) ),
			'false api_token'      => array( array( 'api_token' => false ) ),
		);
	}

	/**
	 * Tests that an incomplete config is available but not ready, and names the missing field.
	 *
	 * @param array<mixed> $raw The raw config value.
	 *
	 * @return void
	 */
	#[DataProvider( 'incompleteConfigs' )]
	public function testIncompleteConfigIsNotReady( array $raw ): void {

		$config = new Config( $raw );

		$this->assertTrue( $config->is_available() );
		$this->assertFalse( $config->is_ready() );
		$this->assertSame( array( 'api_token' ), $config->missing_fields() );
	}

	/**
	 * Constant values that are not arrays, and so mean "no config".
	 *
	 * @return array<string, array<mixed>>
	 */
	public static function invalidConfigs(): array {
		return array(
			'undefined constant' => array( null ),
			'string'             => array( 'this-is-not-an-array' ),
			'integer'            => array( 42 ),
			'boolean'            => array( true ),
		);
	}

	/**
	 * Tests that a non-array config is treated as no config at all, without erroring.
	 *
	 * @param mixed $raw The raw config value.
	 *
	 * @return void
	 */
	#[DataProvider( 'invalidConfigs' )]
	public function testInvalidConfigIsUnavailable( mixed $raw ): void {

		$config = new Config( $raw );

		$this->assertFalse( $config->is_available() );
		$this->assertFalse( $config->is_ready() );
		$this->assertNull( $config->get( 'api_token' ) );
	}

	/**
	 * Tests that the VIP config token wins over the environment variable and the stored token.
	 *
	 * @return void
	 */
	#[RunInSeparateProcess]
	#[PreserveGlobalState( false )]
	public function testVipConfigTokenTakesPrecedence(): void {

		Credentials::store_api_token( 'stored-database-token' );
		putenv( 'GIST_ANSWERS_API_KEY=environment-token' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.runtime_configuration_putenv -- Sets up the competing token source under test; this test runs in its own process.

		define( 'VIP_GIST_ANSWERS_CONFIG', array( 'api_token' => ' ' . self::MOCK_VIP_TOKEN . ' ' ) );

		$this->assertSame( self::MOCK_VIP_TOKEN, Credentials::get_api_token() );
		$this->assertSame( 'vip', Credentials::get_api_token_source() );
		$this->assertTrue( Credentials::has_stored_api_token() );
	}

	/**
	 * Tests that an incomplete VIP config leaves the site disconnected instead of falling back to another token.
	 *
	 * @return void
	 */
	#[RunInSeparateProcess]
	#[PreserveGlobalState( false )]
	public function testIncompleteVipConfigDoesNotFallBack(): void {

		Credentials::store_api_token( 'stored-database-token' );

		define( 'VIP_GIST_ANSWERS_CONFIG', array( 'api_token' => '' ) );

		$this->assertSame( '', Credentials::get_api_token() );
		$this->assertSame( 'vip', Credentials::get_api_token_source() );
		$this->assertFalse( Credentials::has_stored_api_token() );
	}

	/**
	 * Tests that a non-array VIP config is ignored and the other token sources still work.
	 *
	 * @return void
	 */
	#[RunInSeparateProcess]
	#[PreserveGlobalState( false )]
	public function testInvalidVipConfigFallsBackToOtherSources(): void {

		Credentials::store_api_token( 'stored-database-token' );

		define( 'VIP_GIST_ANSWERS_CONFIG', 'this-is-not-an-array' );

		$this->assertSame( 'stored-database-token', Credentials::get_api_token() );
		$this->assertSame( 'database', Credentials::get_api_token_source() );
		$this->assertTrue( Credentials::has_stored_api_token() );
	}
}
