<?php
/**
 * Plugin Name: Gist Answers E2E Mock API
 * Description: End-to-end test fixture only. Answers the Gist Answers plugin's API requests from stored test data,
 *              and lets the Playwright specs set up scenarios. Inert unless GIST_ANSWERS_E2E_MOCK_API is defined.
 *
 * Mount this folder as wp-content/mu-plugins on a throwaway test site and define `GIST_ANSWERS_E2E_MOCK_API` as
 * true in wp-config.php. It never loads as part of the plugin itself.
 *
 * @package GistAnswers
 */

use GistAnswers\API\Credentials;
use GistAnswers\Model\GistSite;
use GistAnswers\Plugin\GistURLs;
use GistAnswers\Plugin\Utilities;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'GIST_ANSWERS_E2E_MOCK_API' ) || ! GIST_ANSWERS_E2E_MOCK_API ) {
	return;
}

/**
 * Mock Gist Answers API for the end-to-end tests.
 */
final class Gist_Answers_E2E_Mock_API {

	/**
	 * The option holding the mock API's state. (Not prefixed `gist_answers_`, so the plugin's own cleanup leaves it.)
	 *
	 * @var string
	 */
	private const STATE_OPTION = 'e2e_gist_answers_mock_state';

	/**
	 * The API token the mock API accepts.
	 *
	 * @var string
	 */
	public const VALID_TOKEN = 'sk_e2e0123456789abcdef0123456789abcdef';

	/**
	 * The question widget ID given to an activated site.
	 *
	 * @var string
	 */
	private const QUESTION_WIDGET_ID = 'question-bar-widget-e2e-0000-0000-0000-000000000001';

	/**
	 * The answer widget ID given to an activated site.
	 *
	 * @var string
	 */
	private const ANSWER_WIDGET_ID = 'chat-widget-e2e-0000-0000-0000-000000000002';

	/**
	 * The slug of the page with widgets created for an activated site.
	 *
	 * @var string
	 */
	private const WIDGETS_PAGE_SLUG = 'e2e-gist-widgets';

	/**
	 * Register the hooks.
	 *
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'pre_http_request', array( self::class, 'handle_request' ), 10, 3 );
		add_action( 'admin_post_gist_answers_e2e_scenario', array( self::class, 'handle_scenario' ) );
		add_action( 'admin_post_nopriv_gist_answers_e2e_scenario', array( self::class, 'handle_logged_out_scenario' ) );
		add_filter( 'gist_answers_widget_script_origins', array( self::class, 'allow_widget_script_origin' ) );
	}

	/**
	 * Get the mock API's state.
	 *
	 * @return array<string, mixed> The state.
	 */
	private static function get_state(): array {

		$state = get_option( self::STATE_OPTION );

		return is_array( $state ) ? $state : self::default_state();
	}

	/**
	 * Save the mock API's state.
	 *
	 * @param array<string, mixed> $state The state.
	 *
	 * @return void
	 */
	private static function save_state( array $state ): void {
		update_option( self::STATE_OPTION, $state, false );
	}

	/**
	 * Change the mock API's state, holding a database lock so that concurrent requests (e.g., the dashboard's status
	 * requests and a crawl toggle) can't overwrite each other's changes with a stale copy.
	 *
	 * @param callable $change Receives the state by reference, changes it, and returns a result.
	 *
	 * @return mixed The result of $change.
	 */
	private static function update_state( callable $change ): mixed {

		global $wpdb;

		$locked = '1' === strval( $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK( %s, 10 )', self::STATE_OPTION ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A named lock, not a table query.

		try {

			// Read the state as stored now, not as cached earlier in this request.
			wp_cache_delete( self::STATE_OPTION, 'options' );

			$state  = self::get_state();
			$result = $change( $state );

			self::save_state( $state );

			return $result;

		} finally {
			if ( $locked ) {
				$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK( %s )', self::STATE_OPTION ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A named lock, not a table query.
			}
		}
	}

	/**
	 * The state of a fresh account: no websites, ingestion active, and no requests yet.
	 *
	 * @return array<string, mixed> The state.
	 */
	private static function default_state(): array {
		return array(
			'publishers' => array(),
			'crawling'   => true,
			'requests'   => array(),
		);
	}

	/**
	 * Build a publisher (website), as the API returns it.
	 *
	 * @param string               $id      The publisher ID.
	 * @param string               $name    The website name.
	 * @param string               $domain  The website domain.
	 * @param array<string, mixed> $widgets The publisher's widgets config.
	 *
	 * @return array<string, mixed> The publisher.
	 */
	private static function publisher( string $id, string $name, string $domain, array $widgets = array() ): array {
		return array(
			'id'          => $id,
			'name'        => $name,
			'description' => $name,
			'enabled'     => true,
			'category_id' => 'cat-news',
			'config'      => array(
				'domain'  => $domain,
				'widgets' => (object) $widgets,
			),
		);
	}

	/**
	 * The widgets config for an activated site: one question widget, and one answer widget on the answers page.
	 *
	 * @return array<string, mixed> The widgets config.
	 */
	private static function widgets(): array {
		return array(
			'question-bar-widgets' => array(
				self::QUESTION_WIDGET_ID => array( 'name' => 'E2E Question Bar' ),
			),
			'chat-widgets'         => array(
				self::ANSWER_WIDGET_ID => array(
					'name'      => 'E2E Answers',
					'targetUrl' => home_url( '/answers/' ),
				),
			),
		);
	}

	/**
	 * The `pre_http_request` filter: answer requests to the Gist Answers API.
	 *
	 * @param false|array|WP_Error $response    The response so far (false to make the request).
	 * @param array<string, mixed> $parsed_args The request arguments.
	 * @param string               $url         The request URL.
	 *
	 * @return false|array|WP_Error The mock response, or the response so far for other requests.
	 */
	public static function handle_request( $response, array $parsed_args, string $url ) {

		// The plugin may be inactive (or not loaded yet), in which case there's no API to mock.
		if ( ! class_exists( GistURLs::class ) ) {
			return $response;
		}

		$api_base = trailingslashit( GistURLs::get_api_base_url() );

		if ( ! str_starts_with( $url, $api_base ) ) {
			return $response;
		}

		$method = strtoupper( strval( $parsed_args['method'] ?? 'GET' ) );
		$path   = trim( strval( wp_parse_url( substr( $url, strlen( $api_base ) - 1 ), PHP_URL_PATH ) ), '/' );
		$body   = is_string( $parsed_args['body'] ?? null ) ? json_decode( $parsed_args['body'], true ) : null;
		$token  = strval( $parsed_args['headers']['X-API-Token'] ?? '' );

		[ $code, $data ] = self::update_state(
			function ( array &$state ) use ( $method, $path, $body, $token ) {

				$state['requests'][] = "$method $path";

				return self::route( $method, $path, is_array( $body ) ? $body : array(), $token, $state );
			}
		);

		return array(
			'headers'  => array( 'content-type' => 'application/json' ),
			'body'     => wp_json_encode( $data ),
			'response' => array(
				'code'    => $code,
				'message' => get_status_header_desc( $code ),
			),
			'cookies'  => array(),
			'filename' => null,
		);
	}

	/**
	 * Answer one API request.
	 *
	 * @param string               $method The HTTP method.
	 * @param string               $path   The path below the API base URL.
	 * @param array<string, mixed> $body   The decoded request body.
	 * @param string               $token  The API token sent.
	 * @param array<string, mixed> $state  The mock API's state (updated in place).
	 *
	 * @return array<mixed> The status code and the response data.
	 */
	private static function route( string $method, string $path, array $body, string $token, array &$state ): array {

		if ( self::VALID_TOKEN !== $token ) {
			return array( 401, array( 'error' => 'Unauthorized' ) );
		}

		$group = array(
			'id'          => 'pg-e2e',
			'name'        => 'E2E Partner',
			'description' => 'E2E Partner',
		);

		$route = "$method $path";

		switch ( true ) {

			case 'GET publisher_groups' === $route:
			case 1 === preg_match( '#^GET publisher_groups/[^/]+$#', $route ):
				return array( 200, $group );

			case 1 === preg_match( '#^GET publisher_groups/[^/]+/messages$#', $route ):
				return array(
					200,
					array(
						'errors'   => array(),
						'messages' => array(),
					),
				);

			case 'GET categories' === $route:
				return array(
					200,
					array(
						array(
							'id'   => 'cat-news',
							'name' => 'News',
						),
					),
				);

			case 'GET publishers' === $route:
				return array( 200, array( 'publishers' => array_values( $state['publishers'] ) ) );

			case 'POST publishers' === $route:
				$publisher = self::publisher( 'pub-e2e-new', strval( $body['publisher']['name'] ?? '' ), strval( $body['publisher']['config']['domain'] ?? '' ) );

				$state['publishers'][ $publisher['id'] ] = $publisher;

				return array( 200, array( 'publisher' => $publisher ) );

			case 1 === preg_match( '#^GET publishers/[^/]+/sites$#', $route ):
				return array(
					200,
					array(
						array(
							'id'            => 'site-e2e',
							'ingest_status' => array(
								'crawl_phase'    => 'delta',
								'crawler_status' => $state['crawling'] ? 'processing' : 'completed',
							),
						),
					),
				);

			case 1 === preg_match( '#^(PUT|DELETE) publishers/[^/]+/crawl$#', $route ):
				$state['crawling'] = 'PUT' === $method;

				return array( 200, array( 'ok' => true ) );

			case 'POST embed' === $route:
				// An unsigned JWT whose payload carries the embed UUID, like the CMS's tickets.
				return array( 200, array( 'ticket' => 'eyJhbGciOiJub25lIn0.' . rtrim( strtr( base64_encode( '{"uuid":"e2e-embed-uuid"}' ), '+/', '-_' ), '=' ) . '.signature' ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Building a mock JWT.

			case 1 === preg_match( '#^GET publishers/[^/]+/widgets/([^/]+)/html$#', $route, $matches ):
				return array(
					200,
					array(
						'header_snippet' => '<script type="module" src="' . esc_url( WPMU_PLUGIN_URL . '/gist-answers-e2e-widget.js' ) . '"></script>', // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- A mock API response; the plugin enqueues the script.
						'body_snippet'   => '<div class="gist-answers-e2e-widget"><gist-search-widget id="' . esc_attr( $matches[1] ) . '">E2E widget</gist-search-widget></div>',
					),
				);

			case 1 === preg_match( '#^POST publishers/[^/]+/(ingest|widgets/chat)$#', $route ):
				return array( 200, array( 'ok' => true ) );
		}

		return array( 404, array( 'error' => "No mock for $route" ) );
	}

	/**
	 * Allow the widget script the mock API serves (from this mu-plugin's folder) to be loaded.
	 *
	 * @param array<string> $origins The allowed origins.
	 *
	 * @return array<string> The allowed origins, with this site's.
	 */
	public static function allow_widget_script_origin( array $origins ): array {

		$url_parts = wp_parse_url( WPMU_PLUGIN_URL );

		$origins[] = $url_parts['scheme'] . '://' . $url_parts['host'] . ( isset( $url_parts['port'] ) ? ':' . $url_parts['port'] : '' );

		return $origins;
	}

	/**
	 * Answer a scenario request from a logged-out visitor, so the specs can tell an expired login (401) apart from a
	 * site without the mock API (where admin-post.php answers 400).
	 *
	 * @return void
	 */
	public static function handle_logged_out_scenario(): void {
		wp_send_json( array( 'error' => 'Not logged in' ), 401 );
	}

	/**
	 * Handle a scenario request from the specs: `admin-post.php?action=gist_answers_e2e_scenario&scenario=...`.
	 *
	 * Scenarios: `fresh` (disconnected, no websites), `connected` (a valid token, not activated), `activated` (linked
	 * to a website with widgets, and a published page using them), and `state` (just report the state). Add
	 * `websites=1` for an account that already has another website. Responds with the state as JSON.
	 *
	 * @return void
	 */
	public static function handle_scenario(): void {

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Test fixture, only active when GIST_ANSWERS_E2E_MOCK_API is defined on a throwaway test site.
		$scenario     = sanitize_key( wp_unslash( $_GET['scenario'] ?? 'state' ) );
		$has_websites = ! empty( $_GET['websites'] );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( 'state' !== $scenario ) {
			self::reset( $has_websites );
		}

		if ( in_array( $scenario, array( 'connected', 'activated' ), true ) ) {
			Credentials::store_api_token( self::VALID_TOKEN );
		}

		if ( 'activated' === $scenario ) {
			self::activate();
		}

		$page = get_page_by_path( self::WIDGETS_PAGE_SLUG );

		wp_send_json(
			array(
				'token'     => self::VALID_TOKEN,
				'state'     => self::get_state(),
				'page_url'  => $page ? get_permalink( $page ) : '',
				'site_name' => get_bloginfo( 'name' ),
			)
		);
	}

	/**
	 * Reset the plugin and the mock API.
	 *
	 * @param bool $has_websites Whether the account already has another website.
	 *
	 * @return void
	 */
	private static function reset( bool $has_websites ): void {

		Utilities::delete_api_key_from_database();
		Utilities::delete_all_database_options();

		$page = get_page_by_path( self::WIDGETS_PAGE_SLUG );

		if ( $page ) {
			wp_delete_post( $page->ID, true );
		}

		self::update_state(
			function ( array &$state ) use ( $has_websites ) {

				$state = self::default_state();

				if ( $has_websites ) {
					$state['publishers']['pub-e2e-production'] = self::publisher( 'pub-e2e-production', 'E2E Production Site', 'production.example.com' );
				}
			}
		);
	}

	/**
	 * Link this site to a website with widgets, and publish a page using them.
	 *
	 * @return void
	 */
	private static function activate(): void {

		$publisher = self::publisher( 'pub-e2e-site', get_bloginfo( 'name' ), strval( wp_parse_url( home_url(), PHP_URL_HOST ) ), self::widgets() );

		self::update_state(
			function ( array &$state ) use ( $publisher ) {
				$state['publishers'][ $publisher['id'] ] = $publisher;
			}
		);

		// The plugin may have fetched the publishers list (without this website) earlier in this request, e.g. while
		// handling `admin_init`, so make it fetch the list again.
		Credentials::clear_publishers_list_cache();
		GistSite::forget();

		Credentials::update_publisher( 0, $publisher['id'] );

		wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_name'    => self::WIDGETS_PAGE_SLUG,
				'post_title'   => 'E2E Gist Widgets',
				'post_content' => '[gist_answers_render_widget type="question" id="' . self::QUESTION_WIDGET_ID . '"]',
			)
		);
	}
}

Gist_Answers_E2E_Mock_API::register();
