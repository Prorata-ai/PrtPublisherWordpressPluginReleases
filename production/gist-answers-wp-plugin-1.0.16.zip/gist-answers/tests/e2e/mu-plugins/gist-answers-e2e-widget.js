// Stands in for a Gist widget's script in the end-to-end tests: marks the page so a spec can tell it ran.
document.documentElement.dataset.gistAnswersE2eWidget = 'loaded';
