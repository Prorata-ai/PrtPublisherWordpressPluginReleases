import { expect, test, type Page } from '@playwright/test';

/**
 * The state the mock API mu-plugin (tests/e2e/mu-plugins) reports after setting up a scenario.
 */
export interface MockApiState {
    token: string;
    page_url: string;
    site_name: string;
    state: {
        publishers: Record<string, { id: string; name: string }>;
        crawling: boolean;
        requests: string[];
    };
}

/**
 * Scenarios the mock API can set up:
 *
 * - `fresh`: disconnected, with no websites in the account.
 * - `connected`: a valid API token, but the site isn't activated.
 * - `activated`: linked to a website with a question and an answer widget, plus a published page using the
 *   question widget.
 * - `state`: change nothing, just report the state.
 */
export type Scenario = 'fresh' | 'connected' | 'activated' | 'state';

/**
 * Set up a scenario in the mock API, skipping the test if the site under test doesn't have the mock API installed.
 */
export async function scenario(page: Page, name: Scenario, options: { websites?: boolean } = {}): Promise<MockApiState> {
    const params = new URLSearchParams({ action: 'gist_answers_e2e_scenario', scenario: name });

    if (options.websites) {
        params.set('websites', '1');
    }

    const response = await page.request.get(`./wp-admin/admin-post.php?${params}`);
    const isJson = (response.headers()['content-type'] ?? '').includes('application/json');

    // admin-post.php answers 400, without JSON, when no handler is registered for the action: the site doesn't have
    // the mock API. Anything else that isn't the mock's JSON (a 401 for an expired login, a 403 for a non-admin, a
    // PHP fatal error) is a real failure, so it fails the test rather than skipping it.
    test.skip(
        response.status() === 400 && !isJson,
        'The site under test does not have the Gist Answers e2e mock API installed (see tests/e2e/mu-plugins).',
    );

    expect(response.status(), `Setting up the "${name}" scenario failed: ${await response.text()}`).toBe(200);
    expect(isJson, 'The mock API did not answer with JSON').toBe(true);

    return (await response.json()) as MockApiState;
}

/**
 * Stub the Gist CMS pages embedded in the admin screens, so tests never depend on (or load) the real CMS.
 */
export async function stubCmsPages(page: Page): Promise<void> {
    await page.route(/\/pages\/.*[?&]embed=/u, (route) =>
        route.fulfill({ contentType: 'text/html', body: '<!doctype html><title>CMS</title><p>Gist CMS stub</p>' }),
    );
}
