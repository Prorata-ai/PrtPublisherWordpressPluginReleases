import { expect, type Page } from '@playwright/test';

/**
 * Text WordPress prints when PHP errors reach the page, either as raw PHP
 * output (with display_errors on) or as the fatal-error handler's notice.
 */
const PHP_ERROR_PATTERN = /(Fatal error|Parse error|Warning|Notice|Deprecated):\s[\s\S]*?\son line\s\d+/u;
const CRITICAL_ERROR_TEXT = 'There has been a critical error on this website.';

/**
 * Assert that the current page rendered without PHP errors.
 */
export async function expectNoPhpErrors(page: Page): Promise<void> {
    const html = await page.content();

    expect(html, 'page shows the WordPress critical-error screen').not.toContain(CRITICAL_ERROR_TEXT);
    expect(html.match(PHP_ERROR_PATTERN)?.[0] ?? null, 'page contains PHP error output').toBeNull();
}
