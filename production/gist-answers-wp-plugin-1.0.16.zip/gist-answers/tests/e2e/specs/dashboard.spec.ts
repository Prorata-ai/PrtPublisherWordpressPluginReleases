import { expect, test } from '@playwright/test';
import { expectNoPhpErrors } from '../lib/php-errors';

test.describe('Dashboard screen', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('./wp-admin/admin.php?page=gist-answers-dashboard');
    });

    test('renders the plugin header and site card', async ({ page }) => {
        await expect(page.locator('.gist-answers-admin-menu-wrap')).toBeVisible();
        await expect(page.locator('.gist-answers-admin-menu-main-heading')).toBeVisible();
        await expect(page.locator('.gist-answers-admin-site-card')).toBeVisible();
    });

    test('renders without PHP errors', async ({ page }) => {
        await expectNoPhpErrors(page);
    });
});
