import { expect, test, type Page } from '@playwright/test';
import { scenario } from '../lib/mock-api';

/**
 * Open the block editor for a new post, with the welcome guide dismissed.
 */
async function openNewPost(page: Page): Promise<void> {
    await page.goto('./wp-admin/post-new.php');
    await page.waitForFunction(() => Boolean((window as any).wp?.data?.select('core/block-editor')));
    await page.evaluate(() => {
        const wp = (window as any).wp;
        wp.data.dispatch('core/preferences').set('core/edit-post', 'welcomeGuide', false);
    });
}

/**
 * Search the block inserter for the given text.
 */
async function searchInserter(page: Page, text: string): Promise<void> {
    await page.getByRole('button', { name: /^(Block Inserter|Toggle block inserter|Add block)$/u }).first().click();
    await page.getByRole('searchbox').first().fill(text);
}

test.describe('Block editor', () => {
    test.beforeEach(async ({ page }) => {
        await scenario(page, 'activated');
        await openNewPost(page);
    });

    test('lists the question widget before the answer widget', async ({ page }) => {
        await searchInserter(page, 'Gist');

        const options = page.getByRole('option', { name: /Gist (Question|Answer) Widget/u });

        await expect(options).toHaveCount(2);
        await expect(options.first()).toHaveAccessibleName(/Gist Question Widget/u);
        await expect(options.last()).toHaveAccessibleName(/Gist Answer Widget/u);
    });

    test('previews the question widget in the inserter', async ({ page }) => {
        await searchInserter(page, 'Gist Question');
        await page.getByRole('option', { name: 'Gist Question Widget' }).hover();

        await expect(page.locator('.block-editor-inserter__preview-container')).toBeVisible();
    });

    test('inserts the question widget and offers the site\'s widgets', async ({ page }) => {
        await searchInserter(page, 'Gist Question');
        await page.getByRole('option', { name: 'Gist Question Widget' }).click();

        const canvas = page.frameLocator('iframe[name="editor-canvas"]');

        await expect(canvas.getByText('Gist Question Widget (placeholder)')).toBeVisible();

        const widget = page.getByLabel('Widget', { exact: true });

        await expect(widget.locator('option')).toHaveText(['Select a widget ...', 'E2E Question Bar']);
    });
});
