import { expect, test } from '@playwright/test';
import { scenario } from '../lib/mock-api';
import { expectNoPhpErrors } from '../lib/php-errors';

const DASHBOARD = './wp-admin/admin.php?page=gist-answers-dashboard';

test.describe('Connecting to Gist Answers', () => {
    test('only accepts well-formed API tokens', async ({ page }) => {
        await scenario(page, 'fresh');
        await page.goto(DASHBOARD);

        const input = page.locator('input[name="gist_answers_api_token"]');
        const submit = page.locator('#gist-answers-connection-wizard-form [type="submit"]');

        await expect(page.locator('.gist-answers-admin-menu-main-heading')).toHaveText('Welcome to Gist Answers');
        await expect(submit).toBeDisabled();

        await input.fill('not-a-token');
        await expect(input).toHaveClass(/gist-answers-api-key-invalid/u);
        await expect(submit).toBeDisabled();

        await input.fill(`sk_${'0'.repeat(32)}`);
        await expect(input).not.toHaveClass(/gist-answers-api-key-invalid/u);
        await expect(submit).toBeEnabled();
    });

    test('rejects an API token the API refuses', async ({ page }) => {
        await scenario(page, 'fresh');
        await page.goto(DASHBOARD);

        await page.locator('input[name="gist_answers_api_token"]').fill(`sk_${'0'.repeat(40)}`);
        await page.locator('#gist-answers-connection-wizard-form [type="submit"]').click();

        await expect(page.locator('.gist-answers-connection-wizard-error')).toContainText('The API token you entered is not valid.');
        await expectNoPhpErrors(page);
    });

    test('connects with a valid API token', async ({ page }) => {
        const { token } = await scenario(page, 'fresh');

        await page.goto(DASHBOARD);
        await page.locator('input[name="gist_answers_api_token"]').fill(token);
        await page.locator('#gist-answers-connection-wizard-form [type="submit"]').click();

        await expect(page.locator('.gist-answers-admin-menu-main-heading')).toHaveText('Dashboard');
        await expect(page.locator('.gist-answers-admin-site-card-button-activate-site')).toHaveText('Activate website');
        await expectNoPhpErrors(page);
    });
});
