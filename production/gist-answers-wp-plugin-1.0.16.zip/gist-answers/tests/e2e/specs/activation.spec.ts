import { expect, test } from '@playwright/test';
import { scenario } from '../lib/mock-api';
import { expectNoPhpErrors } from '../lib/php-errors';

const DASHBOARD = './wp-admin/admin.php?page=gist-answers-dashboard';

test.describe('Activating a website', () => {
    test('activates a new website when the account has none', async ({ page, baseURL }) => {
        await scenario(page, 'connected');
        await page.goto(DASHBOARD);

        await page.locator('.gist-answers-admin-site-card-button-activate-site').click();

        const modal = page.locator('#gist-answers-activation-modal');
        const newWebsite = modal.locator('.gist-answers-activation-modal-new-input');
        const submit = modal.locator('.gist-answers-activation-modal-continue');

        await expect(modal.getByRole('dialog')).toBeVisible();
        await expect(modal.locator('.gist-answers-activation-modal-choice-preproduction')).toBeHidden();
        await expect(newWebsite).toHaveAttribute('type', 'checkbox');
        await expect(modal.locator('.gist-answers-activation-modal-site-url')).toContainText(new URL(baseURL ?? '').hostname);
        await expect(submit).toBeDisabled();

        await newWebsite.check();
        await expect(submit).toBeEnabled();
        await submit.click();

        await expect(page.locator('.gist-answers-admin-site-card-button-set-up-widgets')).toHaveText('Set up widgets');
        await expect(page.locator('.gist-answers-connection-wizard-error')).toHaveCount(0);

        const { state } = await scenario(page, 'state');

        expect(state.requests).toContain('POST publishers');
        await expectNoPhpErrors(page);
    });

    test('links a test website to an existing production website', async ({ page }) => {
        await scenario(page, 'connected', { websites: true });
        await page.goto(DASHBOARD);

        await page.locator('.gist-answers-admin-site-card-button-activate-site').click();

        const modal = page.locator('#gist-answers-activation-modal');
        const production = modal.locator('.gist-answers-activation-modal-publisher');
        const submit = modal.locator('.gist-answers-activation-modal-continue');

        await expect(modal.locator('.gist-answers-activation-modal-choice-preproduction')).toBeVisible();
        await expect(modal.locator('input[value="preproduction"]')).toBeChecked();
        await expect(modal.locator('.gist-answers-activation-modal-new-input')).toHaveAttribute('type', 'radio');
        await expect(production.locator('option[value=""]')).toBeDisabled();
        await expect(submit).toBeDisabled();

        await production.selectOption('pub-e2e-production');
        await expect(submit).toBeEnabled();
        await submit.click();

        await expect(page.locator('.gist-answers-admin-site-card-button-set-up-widgets')).toBeVisible();
        await expect(page.locator('.gist-answers-admin-site-card')).toHaveAttribute('data-publisher-id', 'pub-e2e-production');

        const { state } = await scenario(page, 'state');

        expect(state.requests).not.toContain('POST publishers');
    });

    test('can be cancelled', async ({ page }) => {
        await scenario(page, 'connected', { websites: true });
        await page.goto(DASHBOARD);

        await page.locator('.gist-answers-admin-site-card-button-activate-site').click();

        const modal = page.locator('#gist-answers-activation-modal');

        await expect(modal).toHaveCSS('opacity', '1');
        await modal.getByRole('button', { name: 'Cancel' }).click();
        await expect(modal).toHaveCSS('opacity', '0');
        await expect(page.locator('.gist-answers-admin-site-card-button-activate-site')).toBeEnabled();
    });
});
