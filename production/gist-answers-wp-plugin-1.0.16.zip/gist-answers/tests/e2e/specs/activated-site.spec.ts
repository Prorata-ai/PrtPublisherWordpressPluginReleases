import { expect, test } from '@playwright/test';
import { scenario, stubCmsPages } from '../lib/mock-api';
import { expectNoPhpErrors } from '../lib/php-errors';

const DASHBOARD = './wp-admin/admin.php?page=gist-answers-dashboard';

test.describe('An activated website', () => {
    test.beforeEach(async ({ page }) => {
        await stubCmsPages(page);
        await scenario(page, 'activated');
    });

    test('pauses and resumes content ingestion', async ({ page }) => {
        await page.goto(DASHBOARD);

        const card = page.locator('.gist-answers-admin-site-card');
        const toggle = card.locator('input[type="checkbox"]');
        const status = card.locator('.gist-answers-admin-site-card-status');

        await expect(status).toHaveText('Ingestion active');
        await expect(toggle).toBeEnabled();
        await expect(toggle).toBeChecked();

        const paused = page.waitForResponse((response) => response.url().includes('site-status') && response.request().method() === 'POST');
        await toggle.uncheck();
        expect((await paused).status()).toBe(200);
        await expect(status).toHaveText('Ingestion paused');

        await page.reload();
        await expect(status).toHaveText('Ingestion paused');
        await expect(toggle).not.toBeChecked();

        const resumed = page.waitForResponse((response) => response.url().includes('site-status') && response.request().method() === 'POST');
        await toggle.check();
        expect((await resumed).status()).toBe(200);

        const { state } = await scenario(page, 'state');

        expect(state.crawling).toBe(true);
        expect(state.requests).toEqual(expect.arrayContaining(['DELETE publishers/pub-e2e-site/crawl', 'PUT publishers/pub-e2e-site/crawl']));
    });

    test('opens the widgets list from "View widgets"', async ({ page }) => {
        await page.goto(DASHBOARD);

        await page.locator('.gist-answers-admin-site-card-button-view-widgets').click();

        const popup = page.locator('#gist-answers-popup-iframe-outer iframe');

        await expect(popup).toHaveAttribute('src', /\/widgets\/site\/pub-e2e-site\/your-widgets\?embed=/u);
        await expect(page.frameLocator('#gist-answers-popup-iframe-outer iframe').getByText('Gist CMS stub')).toBeVisible();
    });

    test('embeds the CMS on the Answers screen', async ({ page }) => {
        await page.goto('./wp-admin/admin.php?page=gist-answers-answers');

        await expect(page.locator('.gist-answers-admin-menu-fixed-container iframe')).toHaveAttribute('src', /\/gistanswers\/channel\?embed=/u);
        await expectNoPhpErrors(page);
    });

    test('renders its question widget on the front end', async ({ page }) => {
        const { page_url: pageUrl } = await scenario(page, 'state');

        await page.goto(pageUrl);

        await expect(page.locator('.gist-answers-e2e-widget gist-search-widget')).toHaveAttribute('id', /^question-bar-widget-e2e-/u);
        await expect(page.locator('html')).toHaveAttribute('data-gist-answers-e2e-widget', 'loaded');
        await expectNoPhpErrors(page);
    });
});
