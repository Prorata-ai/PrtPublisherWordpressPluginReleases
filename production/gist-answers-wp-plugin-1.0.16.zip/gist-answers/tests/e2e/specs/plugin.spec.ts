import { expect, test } from '@playwright/test';
import { expectNoPhpErrors } from '../lib/php-errors';

test.describe('Plugin', () => {
    test('is active', async ({ page }) => {
        await page.goto('./wp-admin/plugins.php');

        await expect(page.locator('tr[data-slug="gist-answers"]')).toHaveClass(/\bactive\b/u);
        await expectNoPhpErrors(page);
    });

    test('adds the Gist Answers admin menu', async ({ page }) => {
        await page.goto('./wp-admin/');

        const menu = page.locator('#toplevel_page_gist-answers');

        await expect(menu).toBeVisible();
        await expect(menu.locator('.wp-submenu a[href$="admin.php?page=gist-answers-dashboard"]')).toHaveCount(1);
    });

    test('front end renders without PHP errors', async ({ page }) => {
        const response = await page.goto('./');

        expect(response?.status()).toBeLessThan(500);
        await expectNoPhpErrors(page);
    });
});
