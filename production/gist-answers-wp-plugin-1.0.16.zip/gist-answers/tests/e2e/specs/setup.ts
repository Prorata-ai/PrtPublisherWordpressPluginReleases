import { mkdir } from 'node:fs/promises';
import { dirname } from 'node:path';
import { expect, test as setup } from '@playwright/test';
import { STORAGE_STATE } from '../../../playwright.config';

setup('log in as an administrator', async ({ page }) => {
    await page.goto('./wp-login.php');
    await page.locator('#user_login').fill(process.env.E2E_USER ?? 'vipgo');
    await page.locator('#user_pass').fill(process.env.E2E_PASSWORD ?? 'password');
    await page.locator('#wp-submit').click();

    await expect(page).toHaveURL(/\/wp-admin\//u);

    await mkdir(dirname(STORAGE_STATE), { recursive: true });
    await page.context().storageState({ path: STORAGE_STATE });
});
