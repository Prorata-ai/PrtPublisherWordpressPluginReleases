<?php
/**
 * "Admin Loader" partial template for the Gist Answers plugin.
 *
 * @package GistAnswers
 */

namespace GistAnswers;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="gist-answers-admin-loader">
	<div class="gist-answers-admin-loader-ring"></div>
</div><!-- #gist-answers-admin-loader -->
